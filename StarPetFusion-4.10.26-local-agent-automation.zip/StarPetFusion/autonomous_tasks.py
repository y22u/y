"""Permissioned local automation queue for StarPetFusion.

Only registered task types execute. No arbitrary shell command API exists. Code patches
are staged and require explicit approval; writes are backed up and restricted to safe
text files inside the project tree. Persistent state is stored in SQLite.
"""
from __future__ import annotations
import hashlib, json, logging, os, shutil, sqlite3, subprocess, sys, threading, time, uuid, zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data" / "automation"
DB_PATH = DATA_DIR / "tasks.sqlite3"
LOG_PATH = DATA_DIR / "automation.log"
ARTIFACT_DIR = DATA_DIR / "artifacts"
BACKUP_DIR = DATA_DIR / "backups"
MAX_TASKS = 500
MAX_PATCH_BYTES = 200_000
ALLOWED_PATCH_SUFFIXES = {".py", ".js", ".css", ".html", ".json", ".md", ".txt", ".yml", ".yaml", ".toml"}
FORBIDDEN_PARTS = {".git", ".venv", "venv", "__pycache__", ".pytest_cache", "node_modules", "secrets", "credentials"}

DATA_DIR.mkdir(parents=True, exist_ok=True)
logger = logging.getLogger("starpetfusion.automation")
if not logger.handlers:
    handler = logging.FileHandler(LOG_PATH, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

_lock = threading.RLock()
_runner_thread: threading.Thread | None = None
_runner_stop = threading.Event()
_runner_enabled = False
_last_scheduled_audit = 0.0

TASK_TYPES = {
    "health_check": {"label": "服务与硬件巡检", "requires_approval": False},
    "ollama_inventory": {"label": "Ollama 模型盘点", "requires_approval": False},
    "voice_sample": {"label": "角色音色试听生成与质检", "requires_approval": False},
    "release_check": {"label": "代码测试与打包", "requires_approval": False},
    "code_patch": {"label": "代码变更（需审批）", "requires_approval": True},
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=10000")
    return con


def _init_db() -> None:
    with _connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS tasks (
          id TEXT PRIMARY KEY, task_type TEXT NOT NULL, title TEXT NOT NULL,
          payload_json TEXT NOT NULL, status TEXT NOT NULL, requires_approval INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL, started_at TEXT, finished_at TEXT,
          attempts INTEGER NOT NULL DEFAULT 0, result_json TEXT, error TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_tasks_status_created ON tasks(status, created_at);
        CREATE TABLE IF NOT EXISTS events (
          id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, created_at TEXT NOT NULL,
          level TEXT NOT NULL, message TEXT NOT NULL, details_json TEXT
        );
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        # A process killed mid-task must not leave a task permanently stuck.
        con.execute("UPDATE tasks SET status='queued', updated_at=?, error='上次进程中断，已安全重新排队' WHERE status='running'", (_now(),))


def _event(task_id: str | None, level: str, message: str, details: Any = None) -> None:
    safe_message = str(message)[:1000]
    with _connect() as con:
        con.execute("INSERT INTO events(task_id,created_at,level,message,details_json) VALUES(?,?,?,?,?)",
                    (task_id, _now(), level, safe_message, json.dumps(details, ensure_ascii=False, default=str)[:20000] if details is not None else None))
    getattr(logger, level.lower() if level.lower() in {"debug", "info", "warning", "error"} else "info")("%s %s", task_id or "system", safe_message)


def _decode(row: sqlite3.Row) -> dict[str, Any]:
    out = dict(row)
    out["requires_approval"] = bool(out["requires_approval"])
    for key in ("payload_json", "result_json"):
        raw = out.pop(key, None)
        out["payload" if key == "payload_json" else "result"] = json.loads(raw) if raw else None
    return out


def create_task(task_type: str, payload: dict[str, Any] | None = None, title: str = "") -> dict[str, Any]:
    if task_type not in TASK_TYPES:
        raise ValueError("任务类型未注册；仅允许已定义的安全任务类型。")
    payload = payload or {}
    if not isinstance(payload, dict): raise ValueError("任务参数必须是 JSON 对象。")
    payload = _validate_payload(task_type, payload)
    requires = bool(TASK_TYPES[task_type]["requires_approval"])
    status = "needs_approval" if requires else "queued"
    task_id = uuid.uuid4().hex
    now = _now()
    task_title = (str(title).strip() or TASK_TYPES[task_type]["label"])[:120]
    with _connect() as con:
        count = con.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('queued','running','needs_approval')").fetchone()[0]
        if count >= MAX_TASKS: raise ValueError("待处理任务过多，请先清理或完成现有任务。")
        con.execute("INSERT INTO tasks(id,task_type,title,payload_json,status,requires_approval,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                    (task_id, task_type, task_title, json.dumps(payload, ensure_ascii=False), status, int(requires), now, now))
    _event(task_id, "info", "任务已创建", {"type": task_type, "status": status})
    return get_task(task_id) or {}


def _validate_payload(task_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    if task_type in {"health_check", "ollama_inventory", "release_check"}:
        if task_type == "ollama_inventory":
            base = str(payload.get("base_url", "http://127.0.0.1:11434")).strip().rstrip("/")
            if not base.startswith(("http://127.0.0.1", "http://localhost", "http://[::1]")):
                raise ValueError("为防止访问外部服务，Ollama 管理任务只允许本机 loopback 地址。")
            return {"base_url": base}
        return {}
    if task_type == "voice_sample":
        ids = payload.get("character_ids")
        text = str(payload.get("text", "")).strip()
        provider = str(payload.get("provider", "indextts"))
        if not isinstance(ids, list) or not 1 <= len(ids) <= 5 or any(not isinstance(x, str) for x in ids):
            raise ValueError("角色音色任务需选择 1–5 个角色 ID。")
        if not text or len(text) > 300: raise ValueError("试听文本不能为空且不能超过 300 字符。")
        if provider not in {"indextts", "qwen3"}: raise ValueError("语音引擎只允许 indextts 或 qwen3。")
        return {"character_ids": list(dict.fromkeys(ids)), "text": text, "provider": provider}
    if task_type == "code_patch":
        rel = str(payload.get("relative_path", "")).replace("\\", "/").strip()
        content = payload.get("content")
        if not rel or rel.startswith("/") or ".." in Path(rel).parts: raise ValueError("代码变更路径必须是项目内相对路径。")
        path = (ROOT / rel).resolve()
        try: path.relative_to(ROOT.resolve())
        except ValueError as exc: raise ValueError("代码变更目标超出项目目录。") from exc
        parts = {p.lower() for p in Path(rel).parts}
        if parts & FORBIDDEN_PARTS or Path(rel).suffix.lower() not in ALLOWED_PATCH_SUFFIXES:
            raise ValueError("目标路径属于受保护目录或文件类型不在允许清单内。")
        if Path(rel).name.lower() in {".env", ".env.local", ".env.production", "credentials.json"} or Path(rel).suffix.lower() in {".key", ".pem", ".pfx", ".db", ".sqlite", ".sqlite3"}:
            raise ValueError("禁止自动修改凭据、数据库或密钥文件。")
        if not isinstance(content, str) or len(content.encode("utf-8")) > MAX_PATCH_BYTES:
            raise ValueError("变更内容必须是文本且不超过 200 KB。")
        if not content.strip(): raise ValueError("变更内容不能为空。")
        return {"relative_path": rel, "content": content}
    raise ValueError("未实现该任务类型。")


def get_task(task_id: str) -> dict[str, Any] | None:
    with _connect() as con:
        row = con.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    return _decode(row) if row else None


def list_tasks(limit: int = 50) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 200))
    with _connect() as con:
        rows = con.execute("SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [_decode(r) for r in rows]


def list_events(limit: int = 100) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 300))
    with _connect() as con:
        rows = con.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) | {"details": json.loads(r["details_json"]) if r["details_json"] else None} for r in rows]


def approve_task(task_id: str, approved: bool) -> dict[str, Any]:
    task = get_task(task_id)
    if not task: raise KeyError("任务不存在")
    if task["task_type"] != "code_patch" or task["status"] != "needs_approval":
        raise ValueError("只有等待审批的代码变更任务可以审批。")
    if not approved:
        with _connect() as con:
            con.execute("UPDATE tasks SET status='cancelled', updated_at=?, finished_at=? WHERE id=?", (_now(), _now(), task_id))
        _event(task_id, "warning", "用户拒绝代码变更")
        return get_task(task_id) or {}
    with _connect() as con:
        con.execute("UPDATE tasks SET status='queued', requires_approval=0, updated_at=? WHERE id=?", (_now(), task_id))
    _event(task_id, "info", "代码变更已获用户审批并排队执行")
    return get_task(task_id) or {}


def runner_status() -> dict[str, Any]:
    with _connect() as con:
        enabled = con.execute("SELECT value FROM settings WHERE key='periodic_audit' ").fetchone()
        queued = con.execute("SELECT COUNT(*) FROM tasks WHERE status='queued'").fetchone()[0]
        pending = con.execute("SELECT COUNT(*) FROM tasks WHERE status='needs_approval'").fetchone()[0]
        running = con.execute("SELECT COUNT(*) FROM tasks WHERE status='running'").fetchone()[0]
    try: database_display = str(DB_PATH.relative_to(ROOT))
    except ValueError: database_display = "temporary test database"
    try: log_display = str(LOG_PATH.relative_to(ROOT))
    except ValueError: log_display = "local automation log"
    return {"running": bool(_runner_thread and _runner_thread.is_alive() and not _runner_stop.is_set()),
            "periodic_audit": bool(enabled and enabled[0] == "true"), "audit_interval_seconds": 1800,
            "queued": queued, "needs_approval": pending, "running_tasks": running,
            "database": database_display, "log": log_display}


def start_runner(periodic_audit: bool | None = None) -> dict[str, Any]:
    global _runner_thread, _runner_enabled
    with _lock:
        if periodic_audit is not None:
            with _connect() as con:
                con.execute("INSERT INTO settings(key,value) VALUES('periodic_audit',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", ("true" if periodic_audit else "false",))
        with _connect() as con:
            row = con.execute("SELECT value FROM settings WHERE key='periodic_audit'").fetchone()
        _runner_enabled = bool(row and row[0] == "true")
        if not (_runner_thread and _runner_thread.is_alive()):
            _runner_stop.clear()
            _runner_thread = threading.Thread(target=_worker_loop, name="starpetfusion-task-runner", daemon=True)
            _runner_thread.start()
            _event(None, "info", "自动任务执行器已启动", {"periodic_audit": _runner_enabled})
    return runner_status()


def stop_runner() -> dict[str, Any]:
    global _runner_thread
    _runner_stop.set()
    with _lock:
        thread = _runner_thread
    if thread and thread.is_alive(): thread.join(timeout=2)
    _event(None, "info", "自动任务执行器已请求停止")
    return runner_status()


def _worker_loop() -> None:
    global _last_scheduled_audit
    while not _runner_stop.wait(1.0):
        try:
            with _connect() as con:
                row = con.execute("SELECT value FROM settings WHERE key='periodic_audit'").fetchone()
            if row and row[0] == "true" and time.monotonic() - _last_scheduled_audit >= 1800:
                with _connect() as con:
                    active = con.execute("SELECT 1 FROM tasks WHERE task_type='health_check' AND status IN ('queued','running') LIMIT 1").fetchone()
                if not active:
                    create_task("health_check", {}, "定时服务与硬件巡检")
                    _last_scheduled_audit = time.monotonic()
            with _connect() as con:
                row = con.execute("SELECT * FROM tasks WHERE status='queued' ORDER BY created_at LIMIT 1").fetchone()
                if row:
                    con.execute("UPDATE tasks SET status='running', started_at=?, updated_at=?, attempts=attempts+1 WHERE id=? AND status='queued'", (_now(), _now(), row["id"]))
            if row:
                try:
                    result = _execute(row["task_type"], json.loads(row["payload_json"]))
                    status = "completed" if result.get("ok", True) else "failed"
                    with _connect() as con:
                        con.execute("UPDATE tasks SET status=?, result_json=?, error=?, updated_at=?, finished_at=? WHERE id=?",
                            (status, json.dumps(result, ensure_ascii=False, default=str)[:500000], str(result.get("error", ""))[:1000], _now(), _now(), row["id"]))
                    _event(row["id"], "info" if status == "completed" else "error", "任务执行结束", {"status": status})
                except Exception as exc:
                    retryable = row["task_type"] in {"health_check", "ollama_inventory", "voice_sample"} and int(row["attempts"] or 0) < 2
                    if retryable:
                        with _connect() as con:
                            con.execute("UPDATE tasks SET status='queued', error=?, updated_at=? WHERE id=?",
                                (f"临时错误，准备有限重试：{type(exc).__name__}: {str(exc)[:300]}", _now(), row["id"]))
                        _event(row["id"], "warning", "任务遇到临时错误，已重新排队（最多 3 次尝试）", {"exception": type(exc).__name__, "attempt": int(row["attempts"] or 0) + 1})
                    else:
                        with _connect() as con:
                            con.execute("UPDATE tasks SET status='failed', error=?, updated_at=?, finished_at=? WHERE id=?",
                                (f"{type(exc).__name__}: {str(exc)[:500]}", _now(), _now(), row["id"]))
                        _event(row["id"], "error", "任务执行异常；未执行未授权的恢复动作", {"exception": type(exc).__name__})
        except Exception as exc:
            _event(None, "error", "任务执行器循环异常", {"exception": type(exc).__name__})


def _execute(task_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    if task_type == "health_check": return _health_check()
    if task_type == "ollama_inventory": return _ollama_inventory(payload.get("base_url", "http://127.0.0.1:11434"))
    if task_type == "voice_sample": return _voice_sample(payload)
    if task_type == "release_check": return _release_check()
    if task_type == "code_patch": return _apply_patch(payload)
    raise ValueError("拒绝执行未注册的任务类型。")


def _health_check() -> dict[str, Any]:
    import requests
    from resource_monitor import resource_snapshot
    checks = []
    for name, url in [("gateway", "http://127.0.0.1:8765/api/v1/health"), ("ollama", "http://127.0.0.1:11434/api/tags"),
                      ("indextts", os.environ.get("STAR_PET_INDEXTTS_ENDPOINT", "http://127.0.0.1:8767").rstrip("/") + "/health"),
                      ("qwen3_tts", os.environ.get("STAR_PET_QWEN3_TTS_ENDPOINT", "http://127.0.0.1:8766").rstrip("/") + "/health")]:
        try:
            r = requests.get(url, timeout=(0.5, 1.5))
            checks.append({"name": name, "ready": r.ok, "status_code": r.status_code})
        except requests.RequestException as exc:
            checks.append({"name": name, "ready": False, "error": type(exc).__name__})
    resources = resource_snapshot()
    return {"ok": True, "checks": checks, "resources": resources,
            "summary": {"ready": sum(1 for x in checks if x["ready"]), "total": len(checks),
                        "unavailable": [x["name"] for x in checks if not x["ready"]]},
            "recovery": "未自动重启外部服务；仅检测并记录。外部服务启动/停止需单独配置受限白名单。"}


def _ollama_inventory(base_url: str) -> dict[str, Any]:
    from ollama_manager import OllamaManager
    manager = OllamaManager(base_url, timeout=4)
    models = manager.list_models()
    running = manager.list_running_models()
    return {"ok": True, "version": manager.version(), "installed_count": len(models), "running_count": len(running),
            "models": [{"name": x.get("name"), "size": x.get("size"), "details": x.get("details", {})} for x in models],
            "running": [{"name": x.get("name"), "size": x.get("size"), "size_vram": x.get("size_vram"), "context_length": x.get("context_length")} for x in running]}


def _voice_sample(payload: dict[str, Any]) -> dict[str, Any]:
    from backend.app.main import CharacterVoiceSampleRequest, character_voice_generate_samples
    req = CharacterVoiceSampleRequest(**payload)
    result = character_voice_generate_samples(req)
    return {"ok": result.get("failed", 0) == 0, **result}


def _release_check() -> dict[str, Any]:
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    backup = _backup_project()
    report_path = ARTIFACT_DIR / f"quality-report-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    cmd = [sys.executable, "quality_gate.py"]
    try:
        proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=300, shell=False)
        stdout = proc.stdout[-20000:]
        stderr = proc.stderr[-8000:]
        try: report = json.loads(stdout)
        except ValueError: report = {"stdout": stdout, "stderr": stderr}
        report["returncode"] = proc.returncode
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        if proc.returncode != 0:
            return {"ok": False, "error": "质量门禁未通过，未生成发布 ZIP。", "backup": backup, "report": str(report_path.relative_to(ROOT)), "quality": report}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "质量门禁运行超过 300 秒；未生成发布 ZIP。", "backup": backup, "report": str(report_path.relative_to(ROOT))}
    package = ARTIFACT_DIR / f"StarPetFusion-auto-release-{datetime.now().strftime('%Y%m%d-%H%M%S')}.zip"
    excluded_dirs = set(FORBIDDEN_PARTS) | {"character_voice_references", "character_voice_samples", "artifacts", "backups", "logs", "automation"}
    excluded_names = {"tasks.sqlite3", "automation.log", ".env", ".env.local"}
    with zipfile.ZipFile(package, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for path in ROOT.rglob("*"):
            if not path.is_file(): continue
            rel = path.relative_to(ROOT)
            if any(part.lower() in excluded_dirs for part in rel.parts) or path.name.lower() in excluded_names or path.suffix.lower() in {".pyc", ".pyo", ".db", ".sqlite", ".sqlite3"}: continue
            try: zf.write(path, Path("StarPetFusion") / rel)
            except OSError: continue
    digest = hashlib.sha256(package.read_bytes()).hexdigest()
    checksum = package.with_suffix(package.suffix + ".sha256")
    checksum.write_text(f"{digest}  {package.name}\n", encoding="ascii")
    return {"ok": True, "backup": backup, "report": str(report_path.relative_to(ROOT)), "package": str(package.relative_to(ROOT)),
            "checksum": str(checksum.relative_to(ROOT)), "sha256": digest, "bytes": package.stat().st_size}


def _backup_project() -> dict[str, Any]:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    target = BACKUP_DIR / f"project-backup-{datetime.now().strftime('%Y%m%d-%H%M%S')}.zip"
    excluded = set(FORBIDDEN_PARTS) | {"character_voice_references", "character_voice_samples", "artifacts", "backups", "logs", "automation"}
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as zf:
        for path in ROOT.rglob("*"):
            if not path.is_file(): continue
            rel = path.relative_to(ROOT)
            if any(part.lower() in excluded for part in rel.parts) or path.name.lower() in {"tasks.sqlite3", "automation.log", ".env", ".env.local", "model_hub_assignments.json"} or path.suffix.lower() in {".pyc", ".pyo", ".db", ".sqlite", ".sqlite3"}: continue
            try: zf.write(path, rel)
            except OSError: continue
    return {"path": str(target.relative_to(ROOT)), "bytes": target.stat().st_size, "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}


def _apply_patch(payload: dict[str, Any]) -> dict[str, Any]:
    rel = payload["relative_path"]
    target = (ROOT / rel).resolve()
    try: target.relative_to(ROOT.resolve())
    except ValueError as exc: raise ValueError("目标路径超出项目目录。") from exc
    if target.exists() and not target.is_file(): raise ValueError("目标必须是普通文件。")
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    backup = None
    if target.exists():
        backup_path = BACKUP_DIR / f"{datetime.now().strftime('%Y%m%d-%H%M%S')}-{target.name}.bak"
        shutil.copy2(target, backup_path)
        backup = {"path": str(backup_path.relative_to(ROOT)), "sha256": hashlib.sha256(backup_path.read_bytes()).hexdigest()}
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(target.name + ".starpet-tmp")
    temp.write_text(payload["content"], encoding="utf-8")
    os.replace(temp, target)
    return {"ok": True, "path": rel, "bytes": target.stat().st_size, "backup": backup,
            "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "note": "已应用审批后的文本变更；请运行 release_check 验收。"}


_init_db()
