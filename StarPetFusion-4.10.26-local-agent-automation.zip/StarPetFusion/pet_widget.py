from __future__ import annotations

import math
import random
from pathlib import Path

from PySide6.QtCore import QPoint, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QPixmap, QMovie
from PySide6.QtWidgets import QWidget


class PetWidget(QWidget):
    petClicked = Signal()
    petDoubleClicked = Signal()
    petDropped = Signal()
    modeChanged = Signal(str)

    def __init__(self, config: dict, parent=None) -> None:
        flags = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if config.get("topmost", True):
            flags |= Qt.WindowType.WindowStaysOnTopHint
        super().__init__(parent, flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle("星穹桌宠")
        self.setMinimumSize(110, 130)
        self.pet_size = max(100, min(int(config.get("size", 190)), 320))
        self.bubble = ""
        self.bubble_until = 0
        self.mode = config.get("mode", "wander") if config.get("mode") in ("wander", "follow", "still") else "wander"
        self.passthrough = bool(config.get("passthrough", False))
        self.topmost = bool(config.get("topmost", True))
        self.facing = 1
        self.direction = "down"
        self.dragging = False
        self._drag_offset = QPoint()
        self._drag_start = QPoint()
        self._last_position = self.pos()
        self._suppress_release_click = False
        self._click_timer = QTimer(self)
        self._click_timer.setSingleShot(True)
        self._click_timer.setInterval(260)
        self._click_timer.timeout.connect(self.petClicked.emit)
        self._tick = 0
        self._target = None
        self._rest_ticks = 0
        self.animations_enabled = bool(config.get("animations_enabled", True))
        self.animation_style = str(config.get("animation_style", "gentle"))
        if self.animation_style not in ("gentle", "bouncy", "subtle"):
            self.animation_style = "gentle"
        self.idle_chatter = bool(config.get("idle_chatter", False))
        self.mood = "idle"
        self.mood_until = 0
        self._blink_ticks = random.randint(75, 150)
        self._blink_closed = 0
        self._is_hovered = False
        self._sprites: dict[str, QPixmap] = {}
        self._custom_sprite: QPixmap | None = None
        self._custom_movie: QMovie | None = None
        self.appearance_path = str(config.get("appearance_path", "") or "")
        self._fish_sprite_dir = Path(__file__).resolve().parent / "vendor" / "dafeiyu-pet" / "sprites"
        self._load_sprites(self._fish_sprite_dir)
        if self.appearance_path:
            self.set_appearance(self.appearance_path, announce=False)
        self.setFixedSize(self.pet_size + 30, self.pet_size + 82)
        screen = self.screen().availableGeometry() if self.screen() else None
        x = config.get("x")
        y = config.get("y")
        if screen:
            self.move(int(x if x is not None else screen.right() - self.width() - 40),
                      int(y if y is not None else screen.bottom() - self.height() - 40))
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_tick)
        self.timer.start(35)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)
        if self.passthrough:
            self.set_passthrough(True)

    def _load_sprites(self, directory: Path) -> None:
        mapping = {"front": "正面.png", "side": "侧面.png", "back": "背面.png"}
        for key, filename in mapping.items():
            path = directory / filename
            if path.is_file():
                pix = QPixmap(str(path))
                if not pix.isNull():
                    self._sprites[key] = pix.scaledToHeight(self.pet_size, Qt.TransformationMode.SmoothTransformation)

    def say(self, message: str, duration_ms: int = 4200) -> None:
        self.bubble = (message or "").strip()[:180]
        self.bubble_until = self._tick + max(10, duration_ms // 35)
        self.update()

    def react(self, action: str) -> str:
        """Trigger a lightweight procedural emote without requiring animation assets."""
        reactions = {
            "wave": ("wave", ["哼，注意到我了？", "我在这里。", "有什么新发现吗？"]),
            "dance": ("happy", ["来点节奏！", "今天心情不错。", "看好了——特别表演。"]),
            "think": ("curious", ["让我想想。", "有意思，值得分析。", "先把问题拆开。"]),
            "sleep": ("sleepy", ["休息五分钟……大概。", "安静一会儿也不错。", "我只是在闭目养神。"]),
            "cheer": ("happy", ["不错，继续保持。", "这一步做得很好。", "再接再厉。"]),
        }
        mood, lines = reactions.get(action, reactions["wave"])
        self.mood = mood
        self.mood_until = self._tick + 105
        message = random.choice(lines)
        self.say(message, 3600)
        return message

    def set_animations_enabled(self, enabled: bool) -> None:
        self.animations_enabled = bool(enabled)
        self.update()

    def set_animation_style(self, style: str) -> None:
        """Choose a procedural motion profile; no external animation assets required."""
        if style not in ("gentle", "bouncy", "subtle"):
            return
        self.animation_style = style
        self.update()

    def set_idle_chatter(self, enabled: bool) -> None:
        self.idle_chatter = bool(enabled)
        self.update()

    def set_mode(self, mode: str) -> None:
        if mode not in ("wander", "follow", "still"):
            return
        self.mode = mode
        self._target = None
        self.modeChanged.emit(mode)
        self.update()

    def set_size(self, size: int) -> None:
        self.pet_size = max(100, min(int(size), 320))
        self._load_sprites(self._fish_sprite_dir)
        if self.appearance_path:
            self._load_custom_sprite(self.appearance_path)
        self.setFixedSize(self.pet_size + 30, self.pet_size + 82)
        self.update()

    def _load_custom_sprite(self, image_path: str) -> bool:
        path = Path(image_path).expanduser()
        if not path.is_file():
            self._custom_sprite = None
            if self._custom_movie:
                self._custom_movie.stop()
            self._custom_movie = None
            return False
        if self._custom_movie:
            self._custom_movie.stop()
            self._custom_movie = None
        self._custom_sprite = None
        if path.suffix.lower() in {".gif", ".webp"}:
            # Animated WebP may be supported by the installed Qt image plugins.
            # Sprite atlases are still single images and must be sliced by an importer;
            # QMovie cannot infer a sprite-sheet layout.
            movie = QMovie(str(path))
            movie.setScaledSize(__import__("PySide6.QtCore", fromlist=["QSize"]).QSize(self.pet_size + 10, self.pet_size + 10))
            if movie.isValid() and (path.suffix.lower() == ".gif" or movie.frameCount() > 1):
                self._custom_movie = movie
                movie.frameChanged.connect(lambda _frame: self.update())
                movie.start()
                return True
            movie.stop()
        pix = QPixmap(str(path))
        if pix.isNull():
            return False
        self._custom_sprite = pix.scaled(
            self.pet_size + 10, self.pet_size + 10,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        return True

    def set_appearance(self, image_path: str | None, announce: bool = True) -> bool:
        """Use a custom image, or reset to the original fish when image_path is None."""
        if image_path:
            if not self._load_custom_sprite(image_path):
                return False
            self.appearance_path = str(Path(image_path).expanduser().resolve())
            label = Path(image_path).stem
        else:
            self.appearance_path = ""
            self._custom_sprite = None
            if self._custom_movie:
                self._custom_movie.stop()
            self._custom_movie = None
            label = "大肥鱼"
        self.update()
        if announce:
            self.say(f"桌宠外观已切换：{label}")
        return True

    def set_topmost(self, enabled: bool) -> None:
        self.topmost = bool(enabled)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, self.topmost)
        self.show()

    def set_passthrough(self, enabled: bool) -> None:
        self.passthrough = bool(enabled)
        self.setWindowFlag(Qt.WindowType.WindowTransparentForInput, self.passthrough)
        self.show()

    def _on_tick(self) -> None:
        self._tick += 1
        bubble_expired = bool(self.bubble and self._tick > self.bubble_until)
        if bubble_expired:
            self.bubble = ""
        if self.mood != "idle" and self._tick > self.mood_until:
            self.mood = "idle"
        self._blink_ticks -= 1
        if self._blink_closed > 0:
            self._blink_closed -= 1
        if self._blink_ticks <= 0:
            self._blink_closed = 4
            self._blink_ticks = random.randint(90, 190)
        # Optional, deliberately infrequent idle chatter; disabled by default.
        if self.idle_chatter and not self.bubble and not self.dragging and random.random() < 0.00045:
            self.say(random.choice(["嗯？", "今天也要好好加油。", "有什么新鲜事吗？", "我在听。"]), 2800)
        if self.animations_enabled or bubble_expired:
            self.update()
        if self.dragging or self.mode == "still":
            return
        screen = self.screen().availableGeometry() if self.screen() else None
        if not screen:
            return
        cx, cy = self.x() + self.width() // 2, self.y() + self.height() // 2
        target_x = target_y = None
        if self.mode == "follow":
            from PySide6.QtGui import QCursor
            p = QCursor.pos()
            target_x, target_y = p.x(), p.y()
        else:
            if self._rest_ticks > 0:
                self._rest_ticks -= 1
                return
            if self._target is None or math.hypot(self._target[0] - cx, self._target[1] - cy) < 30:
                if random.random() < 0.025:
                    self._rest_ticks = random.randint(18, 90)
                    return
                self._target = (random.randint(screen.left() + 60, screen.right() - 60),
                                random.randint(screen.top() + 70, screen.bottom() - 60))
            target_x, target_y = self._target
        dx, dy = target_x - cx, target_y - cy
        if abs(dx) + abs(dy) < 8:
            return
        self.facing = 1 if dx >= 0 else -1
        if abs(dy) > abs(dx) * 1.1:
            self.direction = "up" if dy < 0 else "down"
        else:
            self.direction = "side"
        factor = 0.028 if self.mode == "follow" else 0.012
        mx = max(-5, min(5, int(dx * factor)))
        my = max(-4, min(4, int(dy * factor)))
        nx = max(screen.left(), min(screen.right() - self.width(), self.x() + mx))
        ny = max(screen.top(), min(screen.bottom() - self.height(), self.y() + my))
        self.move(nx, ny)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        profile = {"gentle": (3.2, 0.12, 0.075, 4.0), "bouncy": (7.0, 0.17, 0.11, 7.0), "subtle": (1.5, 0.075, 0.045, 2.0)}[self.animation_style]
        motion_scale = 2.4 if self.mood == "sleepy" else (profile[0] if self.mood == "happy" else profile[0])
        bob = math.sin(self._tick * (0.055 if self.mood == "sleepy" else profile[1])) * motion_scale if self.animations_enabled and not self.dragging else 0.0
        breath = 1.0 + math.sin(self._tick * 0.045) * 0.009 if self.mood == "sleepy" else (1.0 + math.sin(self._tick * profile[2]) * (0.009 if self.animation_style == "subtle" else 0.018) if self.animations_enabled else 1.0)
        sway = math.sin(self._tick * 0.18) * profile[3] if self.animations_enabled and self.mood in ("wave", "happy") and not self.dragging else 0.0
        figure_y = 58 + bob
        figure_h = self.pet_size
        sprite_key = {"up": "back", "down": "front", "side": "side"}.get(self.direction, "front")
        if sprite_key not in self._sprites:
            sprite_key = "front"
        pix = (self._custom_movie.currentPixmap() if self._custom_movie is not None else self._custom_sprite) if (self._custom_movie is not None or self._custom_sprite is not None) else self._sprites.get(sprite_key)
        center_x = self.width() / 2
        center_y = figure_y + figure_h * 0.52
        painter.save()
        painter.translate(center_x + sway, center_y)
        painter.scale(breath, breath)
        painter.translate(-center_x, -center_y)
        if self.mood in ("happy", "curious") and self.animations_enabled:
            glow_alpha = int(24 + 18 * (0.5 + 0.5 * math.sin(self._tick * 0.16)))
            painter.setPen(QPen(QColor(180, 145, 255, glow_alpha), 2))
            painter.setBrush(QColor(160, 120, 255, max(4, glow_alpha // 3)))
            painter.drawEllipse(QRectF(center_x - self.pet_size * .36, figure_y + self.pet_size * .25,
                                       self.pet_size * .72, self.pet_size * .55))
        if pix:
            draw_w = pix.width()
            x = (self.width() - draw_w) / 2
            draw_y = int(figure_y + max(0, (self.pet_size - pix.height()) // 2))
            if self._custom_sprite is None and sprite_key == "side" and self.facing < 0:
                painter.save()
                painter.translate(self.width(), 0)
                painter.scale(-1, 1)
                painter.drawPixmap(int(x), draw_y, pix)
                painter.restore()
            else:
                painter.drawPixmap(int(x), draw_y, pix)
        else:
            # Self-contained fallback mascot when upstream sprites have not been downloaded.
            self._draw_fallback(painter, int(figure_y), figure_h)
        painter.restore()
        if self.bubble:
            self._draw_bubble(painter)
        painter.end()

    def _draw_fallback(self, painter: QPainter, y: int, h: int) -> None:
        """Draw the bundled, original round-fish mascot without external image files."""
        from PySide6.QtGui import QLinearGradient, QRadialGradient
        cx = self.width() / 2
        body_w = min(self.width() - 18, h * 0.96)
        body_h = h * 0.70
        body_x = cx - body_w / 2
        body_y = y + h * 0.18

        # Tail and fins sit behind the round body.
        tail = QPainterPath()
        tail.moveTo(body_x + body_w * .16, body_y + body_h * .69)
        tail.cubicTo(body_x - body_w * .03, body_y + body_h * .52,
                     body_x - body_w * .20, body_y + body_h * .47,
                     body_x - body_w * .17, body_y + body_h * .75)
        tail.cubicTo(body_x - body_w * .10, body_y + body_h * .92,
                     body_x + body_w * .05, body_y + body_h * .86,
                     body_x + body_w * .20, body_y + body_h * .79)
        tail.closeSubpath()
        painter.setPen(QPen(QColor(40, 123, 166), 2))
        painter.setBrush(QColor(68, 174, 218))
        painter.drawPath(tail)

        top_fin = QPainterPath()
        top_fin.moveTo(cx - body_w * .22, body_y + body_h * .17)
        top_fin.cubicTo(cx - body_w * .14, body_y - body_h * .10,
                        cx + body_w * .10, body_y - body_h * .12,
                        cx + body_w * .24, body_y + body_h * .16)
        top_fin.closeSubpath()
        painter.setBrush(QColor(93, 197, 229))
        painter.drawPath(top_fin)

        body = QRectF(body_x, body_y, body_w, body_h)
        grad = QLinearGradient(body_x, body_y, body_x + body_w * .8, body_y + body_h)
        grad.setColorAt(0.0, QColor(151, 232, 246))
        grad.setColorAt(0.55, QColor(83, 194, 226))
        grad.setColorAt(1.0, QColor(48, 146, 195))
        painter.setPen(QPen(QColor(34, 111, 153), 2.4))
        painter.setBrush(grad)
        painter.drawEllipse(body)

        # Soft belly patch and a tiny side fin.
        painter.setPen(QPen(Qt.PenStyle.NoPen))
        belly = QRadialGradient(cx, body_y + body_h * .65, body_w * .48)
        belly.setColorAt(0, QColor(220, 250, 250, 230))
        belly.setColorAt(1, QColor(220, 250, 250, 0))
        painter.setBrush(belly)
        painter.drawEllipse(QRectF(cx - body_w * .35, body_y + body_h * .48,
                                   body_w * .70, body_h * .42))
        fin = QPainterPath()
        fin.moveTo(cx + body_w * .20, body_y + body_h * .59)
        fin.cubicTo(cx + body_w * .43, body_y + body_h * .51,
                    cx + body_w * .45, body_y + body_h * .74,
                    cx + body_w * .23, body_y + body_h * .77)
        fin.closeSubpath()
        painter.setBrush(QColor(47, 151, 197))
        painter.drawPath(fin)

        # Oversized expressive eyes; both remain visible when facing sideways.
        eye_y = body_y + body_h * .40
        eye_gap = body_w * .19
        eye_x = cx + (body_w * .13 * self.facing)
        eye_centers = [(eye_x - eye_gap * .52, eye_y), (eye_x + eye_gap * .52, eye_y + 2)]
        for ex, ey in eye_centers:
            painter.setPen(QPen(QColor(32, 85, 111), 1.2))
            painter.setBrush(QColor(255, 255, 255))
            painter.drawEllipse(QRectF(ex - body_w * .075, ey - body_w * .085,
                                       body_w * .15, body_w * .17))
            if self._blink_closed <= 0 and self.mood != "sleepy":
                painter.setPen(QPen(Qt.PenStyle.NoPen))
                painter.setBrush(QColor(18, 51, 77))
                pupil_x = ex + body_w * .018 * self.facing
                painter.drawEllipse(QRectF(pupil_x - body_w * .032, ey - body_w * .035,
                                           body_w * .064, body_w * .085))
                painter.setBrush(QColor(255, 255, 255))
                painter.drawEllipse(QRectF(pupil_x - body_w * .018, ey - body_w * .030,
                                           body_w * .023, body_w * .026))
            else:
                painter.setPen(QPen(QColor(32, 85, 111), 2.2))
                painter.drawLine(int(ex - body_w * .045), int(ey), int(ex + body_w * .045), int(ey))

        # Rosy cheeks and a tiny smile complete the friendly mascot look.
        painter.setPen(QPen(Qt.PenStyle.NoPen))
        painter.setBrush(QColor(255, 147, 165, 165))
        painter.drawEllipse(QRectF(cx - body_w * .31, eye_y + body_h * .10, body_w * .12, body_h * .075))
        painter.drawEllipse(QRectF(cx + body_w * .19, eye_y + body_h * .10, body_w * .12, body_h * .075))
        painter.setPen(QPen(QColor(29, 91, 120), 2.1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawArc(QRectF(cx - body_w * .075, eye_y + body_h * .12,
                               body_w * .15, body_h * .11), 205 * 16, 130 * 16)

        # Small shine highlights make the silhouette read well at desktop-pet size.
        painter.setPen(QPen(Qt.PenStyle.NoPen))
        painter.setBrush(QColor(255, 255, 255, 190))
        painter.drawEllipse(QRectF(body_x + body_w * .20, body_y + body_h * .18,
                                   body_w * .12, body_h * .045))
        painter.drawEllipse(QRectF(body_x + body_w * .31, body_y + body_h * .24,
                                   body_w * .055, body_h * .025))
        painter.setPen(QColor(30, 101, 135))
        painter.setFont(QFont("Microsoft YaHei UI", 8, QFont.Weight.Bold))
        painter.drawText(QRectF(8, y + h - 15, self.width() - 16, 16), Qt.AlignmentFlag.AlignCenter, "大肥鱼 · STAR PET")

    def _draw_bubble(self, painter: QPainter) -> None:
        text = self.bubble.replace("\n", " ")
        max_chars = max(8, min(22, (self.width() - 20) // 14))
        if len(text) > max_chars:
            text = text[:max_chars - 1] + "…"
        rect = QRectF(5, 4, self.width() - 10, 46)
        painter.setPen(QPen(QColor(180, 192, 210, 220), 1))
        painter.setBrush(QColor(255, 255, 255, 238))
        painter.drawRoundedRect(rect, 14, 14)
        painter.setPen(QColor(38, 48, 66))
        painter.setFont(QFont("Microsoft YaHei UI", 9))
        painter.drawText(rect.adjusted(8, 3, -8, -3), Qt.AlignmentFlag.AlignCenter, text)

    def enterEvent(self, event) -> None:  # noqa: N802
        self._is_hovered = True
        if not self.passthrough and not self.bubble:
            self.mood = "curious"
            self.mood_until = self._tick + 45
            self.say(random.choice(["嗯？", "找我吗？", "怎么了？"]), 2200)
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._is_hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = True
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self._drag_start = event.globalPosition().toPoint()
            self._last_position = self.pos()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self.dragging and event.buttons() & Qt.MouseButton.LeftButton:
            new_pos = event.globalPosition().toPoint() - self._drag_offset
            dx = new_pos.x() - self.x()
            if abs(dx) > 1:
                self.facing = 1 if dx > 0 else -1
                self.direction = "side"
            self.move(new_pos)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        moved = (event.globalPosition().toPoint() - self._drag_start).manhattanLength() > 8
        self.dragging = False
        self.petDropped.emit()
        if event.button() == Qt.MouseButton.LeftButton and not moved:
            if self._suppress_release_click:
                self._suppress_release_click = False
            else:
                self.mood = "curious"
                self.mood_until = self._tick + 45
                # Delay the single click so a double-click can cancel it cleanly.
                self._click_timer.start()
        event.accept()

    def mouseDoubleClickEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._click_timer.stop()
            self._suppress_release_click = True
            self.petDoubleClicked.emit()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)

    def contextMenuEvent(self, event) -> None:  # noqa: N802
        # Preserve QWidget's handling so CustomContextMenu emits its signal.
        super().contextMenuEvent(event)
