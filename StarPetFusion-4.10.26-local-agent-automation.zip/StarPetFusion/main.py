from __future__ import annotations

import random
import sys
import logging
from pathlib import Path
from typing import Any

from PySide6.QtCore import QObject, QThread, Qt, Signal
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QMenu,
    QMessageBox, QPushButton, QPlainTextEdit, QSystemTrayIcon, QVBoxLayout,
    QWidget, QInputDialog, QStyle, QFileDialog,
)

from config_store import ConfigStore, app_data_dir
from app_logging import configure_logging
from ai_settings_dialog import AISettingsDialog
from external_agent_dialog import ExternalAgentDialog
from agent_tools_dialog import AgentToolsDialog
from data_safety_dialog import DataSafetyDialog
from stage_d_dialog import StageDDialog
from tts_settings_dialog import TTSSettingsDialog
from agent_tools import AgentToolGateway
from pet_widget import PetWidget
from services import AIClient, ChatStore, get_weather, open_local_path, system_status
from skills import Role, build_system_prompt, list_roles, source_root
from voice_service import speak_async
from voice_input_service import record_and_transcribe
from media_settings_dialog import MediaSettingsDialog
from permissions_dialog import PermissionsDialog
from access_control import is_allowed
from productivity import ProductivityDialog
from ai_growth import GrowthStore
from growth_dialog import GrowthDialog
from agent_runtime import AgentRuntime, style_options

APP_DIR = Path(__file__).resolve().parent


class WorkerSignals(QObject):
    finished = Signal(object)
    failed = Signal(str)


class TaskThread(QThread):
    def __init__(self, function, *args, **kwargs) -> None:
        super().__init__()
        self.function, self.args, self.kwargs = function, args, kwargs
        self.signals = WorkerSignals()

    def run(self) -> None:
        try:
            result = self.function(*self.args, **self.kwargs)
            self.signals.finished.emit(result)
        except Exception as exc:
            self.signals.failed.emit(str(exc))


class ChatDialog(QDialog):
    def __init__(self, controller: "AppController", initial_text: str = "") -> None:
        super().__init__(controller.pet)
        self.controller = controller
        self.setWindowTitle("StarPetFusion · 角色会客厅")
        self.resize(900, 780)
        self.setMinimumSize(720, 640)
        self._thread: TaskThread | None = None
        self._tool_gateway = None
        self._current_role: Role | None = None
        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 20)
        root.setSpacing(14)
        top = QHBoxLayout()
        top.setSpacing(8)
        top.addWidget(QLabel("角色"))
        self.role_search = QLineEdit()
        self.role_search.setPlaceholderText("搜索角色…")
        self.role_search.setMaximumWidth(150)
        top.addWidget(self.role_search)
        self.role_box = QComboBox()
        self.role_items = list_roles()
        for role in self.role_items:
            self.role_box.addItem(role.name, role.slug)
        default_role = str(self.controller.config.get("default_role", "默认助手"))
        for i, role in enumerate(self.role_items):
            if role.slug == default_role or role.name == default_role:
                self.role_box.setCurrentIndex(i)
                break
        top.addWidget(self.role_box, 1)
        self.favorite_btn = QPushButton("☆ 收藏")
        self.favorite_btn.setToolTip("将当前角色加入或移出收藏")
        self.favorite_btn.clicked.connect(self.toggle_favorite_role)
        top.addWidget(self.favorite_btn)
        top.addWidget(QLabel("语气"))
        self.style_box = QComboBox()
        self.style_box.setToolTip("只改变表达方式，不会修改人物原始设定")
        for style_key, style_label in style_options():
            self.style_box.addItem(style_label, style_key)
        self.style_box.currentIndexChanged.connect(self.save_language_style)
        top.addWidget(self.style_box)
        self.reload_btn = QPushButton("刷新角色")
        self.reload_btn.clicked.connect(self.reload_roles)
        top.addWidget(self.reload_btn)
        root.addLayout(top)
        self.notice = QLabel()
        self.notice.setWordWrap(True)
        self.notice.setObjectName("MutedText")
        self.notice.setStyleSheet("padding:4px 2px;")
        bundled_count = sum(1 for role in self.role_items if role.directory is not None)
        upstream_root = APP_DIR / "vendor" / "hsr-skills"
        upstream_count = sum(1 for p in upstream_root.iterdir() if p.is_dir() and (p / "SKILL.md").is_file()) if upstream_root.is_dir() else 0
        if upstream_count == 0:
            self.notice.setText(f"当前已加载 {bundled_count} 个内置角色；未检测到有效 hsr-skills 资料。联网运行 python prepare.py，成功后点击“刷新角色”即可，无需重启。")
        else:
            self.notice.setText(f"角色资料已就绪：当前列表 {len(self.role_items)} 个角色（内置 {bundled_count}，上游 hsr-skills {upstream_count}）。资料按提示词预算选择性摘录；对话历史保存在本机。")
        root.addWidget(self.notice)
        self.transcript = QPlainTextEdit()
        self.transcript.setReadOnly(True)
        self.transcript.setObjectName("ConversationView")
        root.addWidget(self.transcript, 1)
        row = QHBoxLayout()
        row.setSpacing(8)
        self.input = QLineEdit()
        self.input.setPlaceholderText("写下你的消息… 也可以使用语音输入（Enter 发送）")
        self.input.setMinimumHeight(42)
        self.input.returnPressed.connect(self.send_message)
        row.addWidget(self.input, 1)
        self.voice_input_btn = QPushButton("🎙 语音输入")
        self.voice_input_btn.setObjectName("SecondaryButton")
        self.voice_input_btn.setToolTip("按下后录制 5 秒；Whisper 模型首次加载较慢，音频在本机识别")
        self.voice_input_btn.setMinimumHeight(42)
        self.voice_input_btn.clicked.connect(self.start_voice_input)
        row.addWidget(self.voice_input_btn)
        quick_btn = QPushButton("快捷话题 ▾")
        quick_btn.setObjectName("SecondaryButton")
        quick_menu = QMenu(quick_btn)
        for prompt in ("今天心情怎么样？", "给我一个学习建议。", "聊聊你的角色设定。", "帮我制定今天的计划。", "推荐一个有趣的话题。"):
            action = QAction(prompt, quick_menu)
            action.triggered.connect(lambda checked=False, p=prompt: self.input.setText(p))
            quick_menu.addAction(action)
        quick_btn.setMenu(quick_menu)
        row.addWidget(quick_btn)
        self.send_btn = QPushButton("发送  ↗")
        self.send_btn.setObjectName("PrimaryButton")
        self.send_btn.setMinimumHeight(42)
        self.send_btn.clicked.connect(self.send_message)
        row.addWidget(self.send_btn)
        root.addLayout(row)
        bottom = QHBoxLayout()
        bottom.setSpacing(6)
        self.clear_btn = QPushButton("清空记录")
        self.clear_btn.setObjectName("SecondaryButton")
        self.clear_btn.clicked.connect(self.clear_history)
        bottom.addWidget(self.clear_btn)
        self.prompt_btn = QPushButton("角色设定")
        self.prompt_btn.setObjectName("SecondaryButton")
        self.prompt_btn.clicked.connect(self.edit_role_prompt)
        bottom.addWidget(self.prompt_btn)
        export_btn = QPushButton("导出记录")
        export_btn.setObjectName("SecondaryButton")
        export_btn.clicked.connect(self.export_history)
        bottom.addWidget(export_btn)
        bottom.addStretch(1)
        self.feedback_good = QPushButton("回答有帮助 👍")
        self.feedback_good.setObjectName("SecondaryButton")
        self.feedback_good.clicked.connect(lambda: self.rate_last_answer(1))
        bottom.addWidget(self.feedback_good)
        self.feedback_bad = QPushButton("需要改进 👎")
        self.feedback_bad.setObjectName("SecondaryButton")
        self.feedback_bad.clicked.connect(lambda: self.rate_last_answer(-1))
        bottom.addWidget(self.feedback_bad)
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(self.close)
        bottom.addWidget(close_btn)
        root.addLayout(bottom)
        self.role_box.currentIndexChanged.connect(self.load_history)
        self.role_search.textChanged.connect(self.filter_roles)
        self._transcript_slug = ""
        self.load_history()
        self.update_favorite_button()
        if initial_text:
            self.input.setText(initial_text)

    def filter_roles(self, text: str) -> None:
        query = text.casefold().strip()
        current = self.role_box.currentData()
        self.role_box.blockSignals(True)
        self.role_box.clear()
        favorites = self.controller.config.get("favorite_roles", [])
        favorites = favorites if isinstance(favorites, list) else []
        roles = sorted(self.role_items, key=lambda r: (r.slug not in favorites, r.name.casefold()))
        for role in roles:
            if query in role.name.casefold() or query in role.slug.casefold():
                self.role_box.addItem(("★ " if role.slug in favorites else "") + role.name, role.slug)
        idx = self.role_box.findData(current)
        if idx >= 0:
            self.role_box.setCurrentIndex(idx)
        self.role_box.blockSignals(False)
        self.update_favorite_button()

    def toggle_favorite_role(self) -> None:
        slug = self.role_box.currentData()
        if not slug:
            return
        favorites = self.controller.config.get("favorite_roles", [])
        favorites = favorites if isinstance(favorites, list) else []
        if slug in favorites:
            favorites.remove(slug)
        else:
            favorites.append(slug)
        self.controller.config.set("favorite_roles", favorites)
        self.filter_roles(self.role_search.text())

    def update_favorite_button(self) -> None:
        slug = self.role_box.currentData() if hasattr(self, "role_box") else None
        favorites = self.controller.config.get("favorite_roles", [])
        self.favorite_btn.setText("★ 已收藏" if slug in favorites else "☆ 收藏")

    def reload_roles(self) -> None:
        self.role_items = list_roles()
        wanted = self.role_box.currentData()
        self.role_box.blockSignals(True)
        self.role_box.clear()
        for role in self.role_items:
            self.role_box.addItem(role.name, role.slug)
        idx = self.role_box.findData(wanted)
        self.role_box.setCurrentIndex(max(0, idx))
        self.role_box.blockSignals(False)
        self.load_history()
        bundled_count = sum(1 for role in self.role_items if role.directory is not None)
        upstream_root = APP_DIR / "vendor" / "hsr-skills"
        upstream_count = sum(1 for p in upstream_root.iterdir() if p.is_dir() and (p / "SKILL.md").is_file()) if upstream_root.is_dir() else 0
        if hasattr(self, "notice"):
            if upstream_count:
                self.notice.setText(f"刷新完成：当前 {len(self.role_items)} 个角色（内置 {bundled_count}，上游 hsr-skills {upstream_count}）。")
            else:
                self.notice.setText(f"刷新完成：当前 {len(self.role_items)} 个角色（内置 {bundled_count}）；上游资料尚未就绪，可运行 python prepare.py 后再次刷新。")

    def selected_role(self) -> Role:
        slug = self.role_box.currentData() or "default"
        return next((r for r in self.role_items if r.slug == slug), self.role_items[0])

    def save_language_style(self, _index: int = -1) -> None:
        if not hasattr(self, "style_box"):
            return
        role = self.selected_role()
        styles = self.controller.config.get("role_styles", {})
        if not isinstance(styles, dict):
            styles = {}
        styles[role.slug] = str(self.style_box.currentData() or "character")
        self.controller.config.set("role_styles", styles)

    def load_history(self) -> None:
        role = self.selected_role()
        self._current_role = role
        self._transcript_slug = role.slug
        self.controller.set_active_role(role.slug)
        styles = self.controller.config.get("role_styles", {})
        style_key = styles.get(role.slug, "character") if isinstance(styles, dict) else "character"
        self.style_box.blockSignals(True)
        style_index = self.style_box.findData(style_key)
        self.style_box.setCurrentIndex(max(0, style_index))
        self.style_box.blockSignals(False)
        history = self.controller.store.history(role.slug, limit=40)
        self.transcript.clear()
        for msg in history:
            name = "我" if msg["role"] == "user" else role.name
            self.transcript.appendPlainText(f"{name}：{msg['content']}\n")
        self.controller.config.set("default_role", role.slug)
        self.update_favorite_button()
        self.input.setFocus()

    def clear_history(self) -> None:
        if not self.controller.has_permission("history_delete", self): return
        role = self.selected_role()
        answer = QMessageBox.question(self, "确认清空", f"要删除本机保存的「{role.name}」对话记录吗？")
        if answer == QMessageBox.StandardButton.Yes:
            self.controller.store.clear(role.slug)
            self.load_history()

    def export_history(self) -> None:
        if not self.controller.has_permission("history_export", self): return
        role = self.selected_role()
        default_name = f"StarPetFusion_{role.slug}_chat.txt"
        path, _ = QFileDialog.getSaveFileName(self, "导出聊天记录", str(Path.home() / default_name), "文本文件 (*.txt)")
        if not path:
            return
        try:
            lines = [f"StarPetFusion · {role.name} 聊天记录", "=" * 36, ""]
            for msg in self.controller.store.history(role.slug, limit=100):
                speaker = "我" if msg["role"] == "user" else role.name
                lines.append(f"{speaker}：{msg['content']}\n")
            Path(path).write_text("\n".join(lines), encoding="utf-8")
        except OSError as exc:
            QMessageBox.warning(self, "导出失败", f"无法写入文件：{exc}")
        else:
            self.notice.setText(f"已导出「{role.name}」的聊天记录。")

    def edit_role_prompt(self) -> None:
        if not self.controller.has_permission("edit_roles", self): return
        role = self.selected_role()
        overrides = self.controller.config.get("role_prompt_overrides", {})
        if not isinstance(overrides, dict):
            overrides = {}
        current = str(overrides.get(role.slug, ""))
        text, ok = QInputDialog.getMultiLineText(
            self, f"{role.name} · 角色补充设定",
            "补充该角色的语气、行为和回答偏好（仅对当前角色生效）：",
            current or ("保持聪慧、自信、理性，表达简洁而有个人风格；不要每句话都刻薄；" 
                        "优先准确回答用户问题，不确定的游戏设定不要编造。" if "大黑塔" in role.name else ""),
        )
        if not ok:
            return
        overrides[role.slug] = text.strip()[:6000]
        self.controller.config.set("role_prompt_overrides", overrides)
        self.notice.setText(f"已保存「{role.name}」的专属设定。新消息会使用更新后的提示词。")

    def start_voice_input(self) -> None:
        if self._thread is not None and self._thread.isRunning():
            return
        self.voice_input_btn.setEnabled(False)
        self.voice_input_btn.setText("🎙 正在聆听…")
        self.notice.setText("请在 5 秒内说话。音频仅在本机识别，不会上传到 AI 服务。")
        self._thread = TaskThread(record_and_transcribe, 5, "base")
        self._thread.signals.finished.connect(self.on_voice_input)
        self._thread.signals.failed.connect(self.on_voice_error)
        self._thread.start()

    def on_voice_input(self, text: Any) -> None:
        self.voice_input_btn.setEnabled(True)
        self.voice_input_btn.setText("🎙 语音输入")
        self.input.setText(str(text).strip())
        self.input.setFocus()
        self.notice.setText("语音已转换为文字；检查无误后点击发送。")

    def on_voice_error(self, error: str) -> None:
        self.voice_input_btn.setEnabled(True)
        self.voice_input_btn.setText("🎙 语音输入")
        self.notice.setText(error)
        QMessageBox.information(self, "语音输入", error)

    def send_message(self) -> None:
        if not self.controller.has_permission("chat", self): return
        if self._thread is not None and self._thread.isRunning():
            return
        text = self.input.text().strip()
        if not text:
            return
        role = self.selected_role()
        self.input.clear()
        self.transcript.appendPlainText(f"我：{text}\n")
        self.controller.store.add(role.slug, "user", text)
        self.send_btn.setEnabled(False)
        self.input.setEnabled(False)
        self.transcript.appendPlainText(f"{role.name}：正在思考……\n")
        overrides = self.controller.config.get("role_prompt_overrides", {})
        extra_prompt = overrides.get(role.slug, "") if isinstance(overrides, dict) else ""
        system = build_system_prompt(role, extra_prompt=extra_prompt, user_text=text)
        history = self.controller.store.history(role.slug, limit=20)
        memory_context = self.controller.growth_store.context(role.slug) if self.controller.config.get("learning_enabled", True) else ""
        styles = self.controller.config.get("role_styles", {})
        style_key = styles.get(role.slug, "character") if isinstance(styles, dict) else "character"
        agent_enabled = bool(self.controller.config.get("agent_enabled", True))
        system = self.controller.agent_runtime.enrich_system_prompt(
            system, role.name, style_key, memory_context, text, agent_enabled
        )
        system += ("\n\n回答质量要求：先准确理解目标、限制条件与上下文；遇到复杂问题时在内部拆解任务，"
                  "检查关键假设、边界情况和潜在错误，必要时比较方案并核对结果。若信息不足，明确说明不确定性并提出最关键的澄清点。"
                  "最终优先提供准确、结构清晰、可执行的答案，并用简洁的推理摘要解释重要结论；不要输出隐藏的逐字思维链。")
        messages = [{"role": "system", "content": system}] + history
        try:
            from external_agent import ExternalAgentClient
            external_agent = ExternalAgentClient()
            if external_agent.enabled:
                import json
                from config_store import app_data_dir
                try:
                    integration_data=json.loads((app_data_dir()/"integrations.json").read_text(encoding="utf-8"))
                except (OSError,ValueError): integration_data={}
                roots=(integration_data.get("agent_tools",{}) or {}).get("roots",[])
                self._tool_gateway=AgentToolGateway(roots if isinstance(roots,list) else [])
                client=external_agent
                self._thread=TaskThread(client.chat_with_tools,messages,self._tool_gateway)
            else:
                self._tool_gateway=None
                client=AIClient(self.controller.config.data)
                self._thread=TaskThread(client.chat,messages)
        except Exception:
            self._tool_gateway=None
            client=AIClient(self.controller.config.data)
            self._thread=TaskThread(client.chat,messages)
        self._thread.signals.finished.connect(lambda response, slug=role.slug, name=role.name: self.on_answer(slug, name, response))
        self._thread.signals.failed.connect(self.on_error)
        self._thread.start()

    def on_answer(self, slug: str, name: str, response: Any) -> None:
        self.send_btn.setEnabled(True)
        self.input.setEnabled(True)
        # Remove the trailing thinking marker if still present.
        content = self.transcript.toPlainText()
        marker = f"{name}：正在思考……\n"
        if marker in content:
            content = content.rsplit(marker, 1)[0]
            self.transcript.setPlainText(content)
        reply = str(response).strip()
        if reply.startswith("STAR_PET_PENDING_WRITE:") and self._tool_gateway is not None:
            import json
            try:
                pending=json.loads(reply.split(":",1)[1])
                target=str(pending.get("target","")); size=int(pending.get("bytes",0)); token=str(pending.get("confirmation_token",""))
                operation="覆盖现有文件" if pending.get("exists") else "新建文件"
                preview=str(pending.get("preview",""))
                if pending.get("preview_truncated"): preview += "\n……（新内容预览已截断）"
                existing=str(pending.get("existing_preview", ""))[:500]
                diff=str(pending.get("diff_preview", ""))[:2500]
                details=f"\n\n现有内容预览：\n{existing}" if existing else ""
                details += f"\n\n差异预览：\n{diff}" if diff else ""
                choice=QMessageBox.question(self,"确认 Agent 文件写入",f"Agent 请求{operation}：\n{target}\n\n内容大小：{size} 字节。\n\n拟写入内容预览：\n{preview}{details}\n\n覆盖现有文件时会先保存本地备份。请确认路径和内容无误。是否写入？",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)
                outcome=self._tool_gateway.confirm_write(token,choice==QMessageBox.StandardButton.Yes)
                if outcome.get("ok") and outcome.get("backup", {}).get("created"):
                    logging.getLogger(__name__).info("Agent write backup created: id=%s", outcome["backup"].get("id"))
                reply=(f"文件写入成功：{outcome.get('path')}（{outcome.get('bytes')} 字节）" if outcome.get('ok') else ("已取消文件写入。" if outcome.get('cancelled') else f"文件写入未完成：{outcome.get('error','未知错误')}"))
            except (ValueError,TypeError,KeyError) as exc:
                reply=f"Agent 写入确认处理失败：{exc}"
        self.controller.store.add(slug, "assistant", reply)
        # Optional OS TTS. This uses installed system voices with per-character delivery
        # profiles; it does not clone or reproduce any official voice actor.
        voice_enabled = bool(self.controller.config.get("voice_enabled", False))
        speak_async(reply, slug, voice_enabled)
        self.transcript.appendPlainText(f"{name}：{reply}\n")
        if self.controller.pet.isVisible():
            self.controller.pet.mood = "happy"
            self.controller.pet.mood_until = self.controller.pet._tick + 70
            self.controller.pet.say(reply.replace("\n", " ")[:42])
        self.input.setFocus()

    def rate_last_answer(self, rating: int) -> None:
        slug = str(self.role_box.currentData() or "default")
        note = "用户反馈：回答有帮助" if rating > 0 else "用户反馈：回答需要改进"
        try:
            self.controller.growth_store.add_feedback(slug, rating, note)
            self.notice.setText("已记录本地反馈，可在「角色记忆与成长」中生成改进建议。")
        except Exception as exc:
            self.notice.setText(f"反馈保存失败：{exc}")

    def on_error(self, error: str) -> None:
        self.send_btn.setEnabled(True)
        self.input.setEnabled(True)
        content = self.transcript.toPlainText()
        marker = f"{self.selected_role().name}：正在思考……\n"
        if marker in content:
            self.transcript.setPlainText(content.rsplit(marker, 1)[0])
        self.transcript.appendPlainText(f"系统：{error}\n")
        self.input.setFocus()


class AppController(QObject):
    def __init__(self, app: QApplication) -> None:
        super().__init__()
        self.app = app
        self.config = ConfigStore()
        self.growth_store = GrowthStore()
        self.store = ChatStore()
        self.agent_runtime = AgentRuntime()
        self.pet = PetWidget(self.config.data)
        self.active_role_slug = str(self.config.get("default_role", "default") or "default")
        # Apply the saved role's portrait at startup, not only after opening chat.
        startup_portrait = self._find_role_portrait(self.active_role_slug)
        if startup_portrait:
            self.pet.set_appearance(startup_portrait, announce=False)
        if not QSystemTrayIcon.isSystemTrayAvailable() and self.pet.passthrough:
            # Avoid a persisted click-through setting making the app unreachable where no tray exists.
            self.pet.set_passthrough(False)
            self.config.set("passthrough", False)
        self.pet.petClicked.connect(self.open_chat)
        self.pet.petDoubleClicked.connect(self.feed_pet)
        self.pet.petDropped.connect(self.save_position)
        self.pet.modeChanged.connect(self.save_mode)
        self.tray = QSystemTrayIcon(self._app_icon(), self.app)
        self.tray.setToolTip("星穹桌宠 · 角色陪伴")
        self.tray.setContextMenu(self.build_menu(tray=True))
        self.tray.activated.connect(self.on_tray_activated)
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()
        from PySide6.QtCore import QTimer
        self._monitor = QTimer(self)
        self._monitor.timeout.connect(self.check_system)
        self._monitor.start(10_000)
        self._last_alert: dict[str, float] = {}
        self._dialogs: list[ChatDialog] = []
        self.pet.show()
        self.pet.say("你好！双击喂食，右键打开菜单。")

    def _app_icon(self) -> QIcon:
        icon_path = APP_DIR / "vendor" / "dafeiyu-pet" / "sprites" / "icon.png"
        if icon_path.is_file():
            icon = QIcon(str(icon_path))
            if not icon.isNull():
                return icon
        return QApplication.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)

    def build_menu(self, tray: bool = False) -> QMenu:
        menu = QMenu()
        chat = QAction("角色聊天…", menu)
        chat.triggered.connect(lambda checked=False: self.open_chat())
        menu.addAction(chat)
        workbench = QAction("日常工作台（待办/便签/文件查找）…", menu)
        workbench.setEnabled(is_allowed(self.config, "productivity"))
        workbench.triggered.connect(self.open_productivity)
        menu.addAction(workbench)
        feed = QAction("喂食", menu)
        feed.triggered.connect(self.feed_pet)
        menu.addAction(feed)
        action_menu = menu.addMenu("互动动作")
        # Keep one entry per visible action. Role-specific image states are routed
        # through the same menu instead of duplicating a second action submenu.
        for key, label in (("wave", "打个招呼"), ("happy", "开心一下"), ("think", "思考中"), ("sleep", "休息一会儿"), ("cheer", "鼓励我"), ("idle", "恢复待机")):
            action = QAction(label, action_menu)
            if key in {"happy", "think", "sleep", "idle"}:
                action.triggered.connect(lambda checked=False, state=key: self.apply_role_animation_state(state))
            else:
                action.triggered.connect(lambda checked=False, k=key: self.pet_action(k))
            action_menu.addAction(action)
        action_menu.addSeparator()
        animations = QAction("启用动态效果", action_menu)
        animations.setCheckable(True)
        animations.setChecked(self.pet.animations_enabled)
        animations.triggered.connect(self.toggle_animations)
        action_menu.addAction(animations)
        style_menu = action_menu.addMenu("动画风格")
        for key, label in (("gentle", "柔和呼吸"), ("bouncy", "活泼弹跳"), ("subtle", "轻微动态")):
            style_action = QAction(label, style_menu)
            style_action.setCheckable(True)
            style_action.setChecked(self.pet.animation_style == key)
            style_action.triggered.connect(lambda checked=False, k=key: self.set_animation_style(k))
            style_menu.addAction(style_action)
        chatter = QAction("偶尔碎碎念", action_menu)
        chatter.setCheckable(True)
        chatter.setChecked(self.pet.idle_chatter)
        chatter.triggered.connect(self.toggle_idle_chatter)
        action_menu.addAction(chatter)
        mode_menu = menu.addMenu("移动模式")
        for key, label in (("wander", "自由散步"), ("follow", "跟随鼠标"), ("still", "原地待着")):
            action = QAction(label, mode_menu)
            action.setCheckable(True)
            action.setChecked(self.pet.mode == key)
            action.triggered.connect(lambda checked=False, k=key: self.set_mode(k))
            mode_menu.addAction(action)
        size_menu = menu.addMenu("桌宠大小")
        for size, label in ((130, "小"), (190, "中"), (250, "大")):
            action = QAction(label, size_menu)
            action.triggered.connect(lambda checked=False, s=size: self.set_size(s))
            size_menu.addAction(action)
        appearance_menu = menu.addMenu("切换桌宠外观")
        fish_action = QAction("大肥鱼（恢复默认）", appearance_menu)
        fish_action.triggered.connect(lambda checked=False: self.set_appearance(None))
        appearance_menu.addAction(fish_action)
        appearance_menu.addSeparator()
        for image_path, label in self.available_pet_images():
            action = QAction(label, appearance_menu)
            action.setToolTip(str(image_path))
            action.triggered.connect(lambda checked=False, p=str(image_path): self.set_appearance(p))
            appearance_menu.addAction(action)
        role_portrait_action = QAction("为当前角色设置专属立绘…", appearance_menu)
        role_portrait_action.triggered.connect(self.choose_role_portrait)
        appearance_menu.addAction(role_portrait_action)
        custom_action = QAction("设置通用桌宠图片…", appearance_menu)
        custom_action.triggered.connect(self.choose_pet_image)
        appearance_menu.addAction(custom_action)
        media = QAction("语音与动画资源设置…", menu)
        media.triggered.connect(self.media_settings)
        menu.addAction(media)
        menu.addSeparator()
        weather = QAction("查看天气", menu)
        weather.triggered.connect(self.weather)
        menu.addAction(weather)
        permissions = QAction("基本权限管理…", menu)
        permissions.triggered.connect(self.permissions_settings)
        menu.addAction(permissions)
        growth = QAction("角色记忆与成长…", menu)
        growth.setEnabled(is_allowed(self.config, "growth"))
        growth.triggered.connect(self.open_growth)
        menu.addAction(growth)
        agent = QAction("启用 Agent 任务辅助", menu)
        agent.setCheckable(True)
        agent.setChecked(bool(self.config.get("agent_enabled", True)))
        agent.triggered.connect(self.toggle_agent)
        menu.addAction(agent)
        external_agent = QAction("外部智能体连接…", menu)
        external_agent.setEnabled(is_allowed(self.config, "edit_settings"))
        external_agent.triggered.connect(self.external_agent_settings)
        menu.addAction(external_agent)
        agent_tools = QAction("Agent 工具与目录授权…", menu)
        agent_tools.setEnabled(is_allowed(self.config, "edit_settings"))
        agent_tools.triggered.connect(self.agent_tools_settings)
        menu.addAction(agent_tools)
        data_safety = QAction("数据安全与恢复…", menu)
        data_safety.triggered.connect(self.data_safety_settings)
        menu.addAction(data_safety)
        stage_d = QAction("数据迁移与诊断…", menu)
        stage_d.triggered.connect(self.stage_d_settings)
        menu.addAction(stage_d)
        tts_settings = QAction("TTS 语音服务设置…", menu)
        tts_settings.setEnabled(is_allowed(self.config, "edit_settings"))
        tts_settings.triggered.connect(self.tts_settings)
        menu.addAction(tts_settings)
        settings = QAction("AI 设置…", menu)
        settings.setEnabled(is_allowed(self.config, "edit_settings"))
        settings.triggered.connect(self.ai_settings)
        menu.addAction(settings)
        city = QAction("设置城市…", menu)
        city.triggered.connect(self.set_city)
        menu.addAction(city)
        install = QAction("安装大黑塔到 Codex…", menu)
        install.triggered.connect(self.install_herta)
        menu.addAction(install)
        knowledge = QAction("崩铁角色资料检索…", menu)
        knowledge.triggered.connect(self.search_hsr_knowledge)
        menu.addAction(knowledge)
        open_roles = QAction("打开角色资料目录", menu)
        open_roles.triggered.connect(lambda: open_local_path(source_root()))
        menu.addAction(open_roles)
        menu.addSeparator()
        top = QAction("窗口置顶", menu)
        top.setCheckable(True)
        top.setChecked(self.pet.topmost)
        top.triggered.connect(self.toggle_topmost)
        menu.addAction(top)
        passthrough = QAction("鼠标穿透（可从托盘关闭）", menu)
        passthrough.setCheckable(True)
        passthrough.setChecked(self.pet.passthrough)
        passthrough.triggered.connect(self.toggle_passthrough)
        menu.addAction(passthrough)
        menu.addSeparator()
        config_dir = QAction("打开配置目录", menu)
        config_dir.triggered.connect(lambda: open_local_path(app_data_dir()))
        menu.addAction(config_dir)
        quit_action = QAction("退出桌宠", menu)
        quit_action.triggered.connect(self.quit)
        menu.addAction(quit_action)
        return menu

    def search_hsr_knowledge(self) -> None:
        query, ok = QInputDialog.getText(self.pet, "崩铁角色资料检索", "输入角色名、技能或设定关键词：")
        if not ok or not query.strip():
            return
        try:
            from hsr_knowledge import search
            results = search(query.strip(), limit=8)
        except Exception as exc:
            QMessageBox.warning(self.pet, "资料检索失败", str(exc))
            return
        if not results:
            QMessageBox.information(self.pet, "资料检索", "本地资料中没有找到匹配内容。可先运行 python prepare.py 更新上游角色资料。")
            return
        lines = []
        for item in results:
            lines.append(f"【{item['title']}｜{item['character']}】\n{item['snippet']}\n来源：{item['source']}")
        QMessageBox.information(self.pet, f"资料检索结果：{query.strip()}", "\n\n".join(lines)[:12000])

    def _find_role_portrait(self, slug: str) -> str | None:
        """Resolve role-specific portrait from user config or bundled asset directories."""
        portraits = self.config.get("role_portraits", {})
        if isinstance(portraits, dict):
            configured = portraits.get(slug)
            if configured and Path(str(configured)).is_file():
                return str(Path(str(configured)).resolve())
        try:
            from character_asset_registry import find_role_portrait
            found = find_role_portrait(slug)
            if found and Path(found).is_file():
                return found
        except Exception:
            pass
        return None

    def set_active_role(self, slug: str) -> None:
        self.active_role_slug = slug or "default"
        portrait = self._find_role_portrait(self.active_role_slug)
        if portrait:
            # Role appearance is separate from the user's global fallback appearance.
            # Do not overwrite config['appearance_path'] with a temporary role image.
            self.pet.set_appearance(portrait, announce=False)
        else:
            # Never leave the previous character's portrait on screen when switching
            # to a role that has no image yet. Fall back to the user's global image.
            global_appearance = str(self.config.get("appearance_path", "") or "")
            if global_appearance and Path(global_appearance).is_file():
                self.pet.set_appearance(global_appearance, announce=False)
            else:
                self.pet.set_appearance(None, announce=False)
        self.apply_role_animation_state("idle", announce=False)
        if not portrait and self.active_role_slug not in ("default", ""):
            self.pet.say("角色设定已切换；尚未找到该角色立绘。右键桌宠 → 切换桌宠外观 → 为当前角色设置专属立绘。", 5200)

    def apply_role_animation_state(self, state: str, announce: bool = True) -> None:
        slug = getattr(self, "active_role_slug", str(self.config.get("default_role", "default")))
        mapping = self.config.get("role_animation_assets", {})
        role_map = mapping.get(slug, {}) if isinstance(mapping, dict) else {}
        path = role_map.get(state) if isinstance(role_map, dict) else None
        # Discover local per-character state assets automatically; keep user mappings authoritative.
        if not path:
            try:
                from character_asset_registry import update_config_mapping
                merged = update_config_mapping({"role_animation_assets": mapping})
                role_map = merged.get(slug, {}) if isinstance(merged, dict) else {}
                path = role_map.get(state) if isinstance(role_map, dict) else None
                if merged != mapping:
                    self.config.set("role_animation_assets", merged)
            except Exception:
                path = None
        if path and Path(path).is_file():
            if self.pet.set_appearance(path, announce=False):
                self.config.set("active_animation_state", state)
                try:
                    from integrations import notify_animation
                    notify_animation(slug, state)
                except Exception:
                    pass
                if announce: self.pet.say(f"已切换专属动作：{state}")
                return
        # Missing state asset: restore this role's portrait rather than leaving a
        # previous role's state image on screen; motion falls back to procedural mood.
        portrait = self._find_role_portrait(slug)
        if portrait and (not self.pet.appearance_path or Path(self.pet.appearance_path).resolve() != Path(portrait).resolve()):
            self.pet.set_appearance(portrait, announce=False)
        moods = {"idle":"idle", "happy":"happy", "think":"think", "sleep":"sleepy"}
        self.pet.mood = moods.get(state, "idle")
        self.pet.mood_until = self.pet._tick + (999999 if state == "sleep" else 180)
        self.config.set("active_animation_state", state)
        if announce: self.pet.say(f"当前角色使用程序化动作：{state}（尚未导入该状态素材）")
        try:
            from integrations import notify_animation
            notify_animation(slug, state)
        except Exception:
            pass
        self.pet.update()

    def media_settings(self) -> None:
        if not self.has_permission("manage_assets"): return
        roles = list_roles()
        dialog = MediaSettingsDialog(self.config, roles, self.pet)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.pet.say("语音与动画资源设置已保存。")

    def on_tray_activated(self, reason) -> None:
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            self.pet.showNormal()
            self.pet.raise_()
            self.pet.activateWindow()

    def open_chat(self, initial_text: str = "") -> None:
        if self.pet.passthrough:
            self.pet.set_passthrough(False)
            self.config.set("passthrough", False)
        dialog = ChatDialog(self, initial_text)
        dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self._dialogs.append(dialog)
        dialog.finished.connect(lambda _=0, d=dialog: self._forget_dialog(d))
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    def _forget_dialog(self, dialog: ChatDialog) -> None:
        try:
            self._dialogs.remove(dialog)
        except ValueError:
            pass

    def feed_pet(self) -> None:
        options = ["🐟 小鱼干", "🍰 蛋糕", "🍡 团子", "🍭 棒棒糖", "💎 钻石"]
        selected, ok = QInputDialog.getItem(self.pet, "投喂桌宠", "选择一样食物：", options, 0, False)
        if not ok:
            return
        lines = {
            "🐟": ["小鱼干！不错嘛。", "咔嚓咔嚓，收到！"],
            "🍰": ["蛋糕？今天算你有品位。", "甜点时间到。"],
            "🍡": ["团子软乎乎的。", "嗯，还挺好吃。"],
            "🍭": ["棒棒糖，勉强合格。", "好吧，这次原谅你。"],
            "💎": ["这个真能吃吗？", "闪闪发光，先收藏。"],
        }
        food_key = selected.split(" ", 1)[0]
        self.pet.say(random.choice(lines[food_key]))

    def pet_action(self, action: str) -> None:
        self.pet.react(action)

    def toggle_agent(self, enabled: bool) -> None:
        """Enable or disable Agent task assistance and persist the setting."""
        enabled = bool(enabled)
        self.config.set("agent_enabled", enabled)
        self.pet.say("Agent 任务辅助已开启。" if enabled else "Agent 任务辅助已关闭。")

    def toggle_animations(self, enabled: bool) -> None:
        self.pet.set_animations_enabled(enabled)
        self.config.set("animations_enabled", enabled)
        self.pet.say("动态效果已开启。" if enabled else "动态效果已关闭。")

    def set_animation_style(self, style: str) -> None:
        self.pet.set_animation_style(style)
        self.config.set("animation_style", style)
        labels = {"gentle": "柔和呼吸", "bouncy": "活泼弹跳", "subtle": "轻微动态"}
        self.pet.say(f"动画风格：{labels.get(style, style)}")

    def toggle_idle_chatter(self, enabled: bool) -> None:
        self.pet.set_idle_chatter(enabled)
        self.config.set("idle_chatter", enabled)
        self.pet.say("我偶尔会主动说几句话。" if enabled else "我会安静待着，有事叫我就好。")

    def available_pet_images(self) -> list[tuple[Path, str]]:
        """Discover selectable image assets while excluding sprite atlases and app icons."""
        roots = [APP_DIR / "vendor", APP_DIR / "character_assets", APP_DIR / "frontend" / "assets" / "characters"]
        extensions = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}
        found: list[tuple[Path, str]] = []
        for asset_root in roots:
            if not asset_root.is_dir():
                continue
            for path in asset_root.rglob("*"):
                if not path.is_file() or path.suffix.lower() not in extensions:
                    continue
                name = path.name.lower()
                if name in {"icon.png", "spritesheet.webp", "spritesheet.png", "sprite-sheet.png"}:
                    continue
                # State images are selected through the role-animation menu, not the
                # global appearance list. This prevents idle/happy/think/sleep duplicates.
                if path.stem.casefold().replace('-', '_') in {"idle", "happy", "think", "sleep"}:
                    continue
                if "dafeiyu-pet" in path.parts and path.parent.name == "sprites":
                    continue
                label = f"{path.stem}（{path.parent.name}）"
                found.append((path, label))
        return sorted(found, key=lambda item: (item[1].lower(), str(item[0]).lower()))[:120]

    def set_appearance(self, image_path: str | None) -> None:
        if not self.pet.set_appearance(image_path):
            QMessageBox.warning(self.pet, "无法切换外观", "图片无法读取，请选择 PNG、JPG、WEBP、BMP 或 GIF 图片。")
            return
        self.config.set("appearance_path", self.pet.appearance_path)

    def choose_role_portrait(self) -> None:
        if not self.has_permission("manage_assets"):
            return
        slug = getattr(self, "active_role_slug", str(self.config.get("default_role", "default")))
        if not slug or slug == "default":
            QMessageBox.information(self.pet, "角色立绘", "请先打开角色聊天窗口并选择一个具体角色，再设置专属立绘。")
            return
        path, _ = QFileDialog.getOpenFileName(
            self.pet, "选择当前角色的专属立绘", str(Path.home()),
            "图片文件 (*.png *.jpg *.jpeg *.webp *.bmp *.gif)",
        )
        if not path:
            return
        # Copy to the writable per-user data directory so the setting survives
        # moving/updating the project folder.
        import shutil
        from config_store import app_data_dir
        src = Path(path)
        dest_dir = app_data_dir() / "role_portraits" / slug
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / ("portrait" + src.suffix.lower())
        try:
            if src.resolve() != dest.resolve():
                shutil.copy2(src, dest)
        except OSError as exc:
            QMessageBox.warning(self.pet, "导入立绘失败", str(exc))
            return
        portraits = self.config.get("role_portraits", {})
        portraits = dict(portraits) if isinstance(portraits, dict) else {}
        portraits[slug] = str(dest.resolve())
        self.config.set("role_portraits", portraits)
        if self.pet.set_appearance(str(dest), announce=False):
            self.pet.say(f"已应用当前角色专属立绘：{src.stem}")
        else:
            QMessageBox.warning(self.pet, "立绘加载失败", "文件已复制，但图片解码失败，请尝试 PNG 或 WEBP 格式。")

    def choose_pet_image(self) -> None:
        if not self.has_permission("manage_assets"): return
        path, _ = QFileDialog.getOpenFileName(
            self.pet, "选择通用桌宠图片", str(Path.home()),
            "图片文件 (*.png *.jpg *.jpeg *.webp *.bmp *.gif)",
        )
        if path:
            self.set_appearance(path)

    def set_mode(self, mode: str) -> None:
        self.pet.set_mode(mode)
        self.config.set("mode", mode)
        labels = {"wander": "自由散步", "follow": "跟随鼠标", "still": "原地待着"}
        self.pet.say(f"已切换：{labels[mode]}")

    def save_mode(self, mode: str) -> None:
        self.config.set("mode", mode)

    def set_size(self, size: int) -> None:
        self.pet.set_size(size)
        self.config.set("size", size)
        self.save_position()

    def save_position(self) -> None:
        self.config.data["x"] = self.pet.x()
        self.config.data["y"] = self.pet.y()
        self.config.save()

    def toggle_topmost(self, enabled: bool) -> None:
        self.pet.set_topmost(enabled)
        self.config.set("topmost", enabled)

    def toggle_passthrough(self, enabled: bool) -> None:
        self.pet.set_passthrough(enabled)
        self.config.set("passthrough", enabled)
        if enabled:
            self.tray.showMessage("星穹桌宠", "已启用鼠标穿透。可从系统托盘右键菜单关闭。", QSystemTrayIcon.MessageIcon.Information, 3500)

    def set_city(self) -> None:
        city, ok = QInputDialog.getText(self.pet, "设置城市", "天气查询城市：", text=str(self.config.get("city", "Tokyo")))
        if ok and city.strip():
            self.config.set("city", city.strip())
            self.pet.say(f"城市已设为 {city.strip()}")

    def weather(self) -> None:
        if not self.has_permission("network"): return
        city = str(self.config.get("city", "Tokyo"))
        self.pet.say("正在查询天气……")
        worker = TaskThread(get_weather, city)
        worker.signals.finished.connect(lambda result: self._weather_result(str(result)))
        worker.signals.failed.connect(lambda error: self.pet.say(error[:75]))
        self._keep_worker(worker)
        worker.start()

    def _weather_result(self, result: str) -> None:
        self.pet.say(result[:100], duration_ms=6500)

    def _keep_worker(self, worker: TaskThread) -> None:
        if not hasattr(self, "_workers"):
            self._workers = []
        self._workers.append(worker)
        worker.finished.connect(lambda: self._drop_worker(worker))

    def _drop_worker(self, worker: TaskThread) -> None:
        if hasattr(self, "_workers"):
            try:
                self._workers.remove(worker)
            except ValueError:
                pass

    def check_system(self) -> None:
        worker = TaskThread(system_status)
        worker.signals.finished.connect(self._status_result)
        self._keep_worker(worker)
        worker.start()

    def _status_result(self, status: dict[str, Any]) -> None:
        import time
        now = time.monotonic()
        warnings = []
        if status.get("cpu", 0) >= 90:
            warnings.append(("cpu", f"CPU 使用率 {status['cpu']:.0f}%"))
        if status.get("memory", 0) >= 95:
            warnings.append(("memory", f"内存使用率 {status['memory']:.0f}%"))
        if status.get("gpu_temp") is not None and status["gpu_temp"] >= 80:
            warnings.append(("gpu", f"显卡温度 {status['gpu_temp']}°C"))
        for key, message in warnings:
            if now - self._last_alert.get(key, 0) > 300:
                self._last_alert[key] = now
                self.pet.say(f"系统提醒：{message}")
                break

    def has_permission(self, permission: str, parent=None) -> bool:
        if is_allowed(self.config, permission):
            return True
        QMessageBox.information(parent or self.pet, "权限受限", "当前权限设置已禁止此操作。可在右键菜单的「基本权限管理」中调整。")
        return False

    def open_productivity(self) -> None:
        if not self.has_permission("productivity"): return
        dialog = ProductivityDialog(self, self.pet)
        # File-search controls are hidden unless the matching permission is enabled.
        if not is_allowed(self.config, "file_search"):
            dialog.folder.setEnabled(False); dialog.query.setEnabled(False)
            dialog.search_button.setEnabled(False); dialog.results.setEnabled(False)
        dialog.exec()

    def permissions_settings(self) -> None:
        dialog = PermissionsDialog(self.config, self.pet)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.pet.say("基本权限设置已保存。")

    def open_growth(self) -> None:
        if not self.has_permission("growth"): return
        dialog = GrowthDialog(self.config, list_roles(), ChatStore(), self.pet)
        dialog.exec()

    def external_agent_settings(self) -> None:
        if not self.has_permission("edit_settings"): return
        dialog = ExternalAgentDialog(self.pet)
        if dialog.exec() == QDialog.DialogCode.Accepted and dialog.result_config:
            state = "已启用" if dialog.result_config.get("enabled") else "已关闭"
            self.pet.say(f"外部智能体连接{state}。")

    def agent_tools_settings(self) -> None:
        if not self.has_permission("edit_settings"): return
        dialog=AgentToolsDialog(self.pet)
        if dialog.exec()==QDialog.DialogCode.Accepted:
            self.pet.say("Agent 目录授权已保存。")

    def data_safety_settings(self) -> None:
        if not self.has_permission("edit_settings"): return
        DataSafetyDialog(self.pet).exec()

    def stage_d_settings(self) -> None:
        """Open the data portability and diagnostics dialog from the context menu."""
        if not self.has_permission("edit_settings"): return
        StageDDialog(self.pet).exec()

    def tts_settings(self) -> None:
        if not self.has_permission("edit_settings"): return
        dialog=TTSSettingsDialog(self.pet)
        if dialog.exec()==QDialog.DialogCode.Accepted:
            self.pet.say("TTS 语音服务设置已保存。")

    def ai_settings(self) -> None:
        if not self.has_permission("edit_settings"): return
        dialog = AISettingsDialog(self.config.data, self.pet)
        if dialog.exec() == QDialog.DialogCode.Accepted and dialog.result_config:
            for key in ("provider", "api_base_url", "api_model", "api_key"):
                self.config.set(key, dialog.result_config.get(key, ""))
            provider = str(self.config.get("provider", "custom"))
            model = str(self.config.get("api_model", ""))
            self.pet.say(f"AI 设置已保存：{provider} / {model}")

    def install_herta(self) -> None:
        if not self.has_permission("install_external"): return
        from install_herta_pet import SOURCE, FILES, install_herta_pet
        if not all((SOURCE / name).is_file() for name in FILES):
            QMessageBox.information(self.pet, "需要先准备素材", "没有找到大黑塔宠物包。请先联网运行：\npython prepare.py")
            return
        answer = QMessageBox.question(self.pet, "安装到 Codex", "将大黑塔宠物包复制到 Codex 的 pets 目录。是否继续？")
        if answer != QMessageBox.StandardButton.Yes:
            return
        # A different installed version is never overwritten unless the user runs the CLI with --force.
        try:
            destination = install_herta_pet()
        except Exception as exc:
            QMessageBox.warning(self.pet, "安装未完成", str(exc))
        else:
            QMessageBox.information(
                self.pet, "安装完成",
                f"已安装到：{destination}\n打开 Codex：设置 → 宠物 → 刷新，然后选择「大黑塔」。",
            )

    def quit(self) -> None:
        self.save_position()
        self.tray.hide()
        self.pet.close()
        self.app.quit()


def main() -> int:
    try:
        log_path = configure_logging()
        logging.getLogger(__name__).info("Application starting; log_path=%s", log_path)
    except Exception:
        # Logging must never prevent the desktop app from opening.
        pass
    app = QApplication(sys.argv)
    app.setApplicationName("StarPetFusion")
    app.setQuitOnLastWindowClosed(False)
    app.setStyleSheet("""
        QWidget { font-family: 'Microsoft YaHei UI', 'Segoe UI', sans-serif; font-size: 10pt; color: #e9e7f1; }
        QDialog { background: #11121a; color: #e9e7f1; }
        QLabel { color: #d9d9e7; }
        QLabel#DialogTitle { color: #faf9ff; font-size: 19pt; font-weight: 700; }
        QLabel#MutedText { color: #9698ad; font-size: 9pt; }
        QLabel#StatusText { color: #c8c9dc; background: #191b28; border: 1px solid #2b2e42; border-radius: 12px; padding: 10px; }
        QLabel#StatusText[success="true"] { color: #a6ebcb; border-color: #2b7658; }
        QLineEdit, QComboBox { min-height: 34px; padding: 5px 10px; background: #191b27; color: #f0eff8; border: 1px solid #303348; border-radius: 9px; selection-background-color: #6e61bb; }
        QPlainTextEdit { background: #151722; color: #eeedf7; border: 1px solid #292d40; border-radius: 14px; padding: 15px; selection-background-color: #6e61bb; font-size: 10.5pt; }
        QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus { border: 1px solid #8e83e6; }
        QComboBox QAbstractItemView { background: #191b27; color: #f0eff8; selection-background-color: #4a426f; border: 1px solid #303348; }
        QPushButton { min-height: 34px; background: #6d63b8; color: #fff; border: 0; border-radius: 9px; padding: 7px 14px; font-weight: 600; }
        QPushButton:hover { background: #8177ce; }
        QPushButton:pressed { background: #514a8e; }
        QPushButton:disabled { background: #303142; color: #85869b; }
        QPushButton#SecondaryButton { background: #1c1e2b; border: 1px solid #32354a; color: #d7d7e8; }
        QPushButton#SecondaryButton:hover { background: #282a3b; border-color: #555675; }
        QPushButton#PrimaryButton { background: #766be0; padding-left: 20px; padding-right: 20px; }
        QPushButton#PrimaryButton:hover { background: #8a80ee; }
        QMenu { background: #191b27; color: #f0eff8; border: 1px solid #34364a; padding: 5px; }
        QMenu::item { padding: 8px 26px; border-radius: 6px; }
        QMenu::item:selected { background: #3c385b; }
        QScrollBar:vertical { background: transparent; width: 10px; margin: 3px; }
        QScrollBar::handle:vertical { background: #383a50; border-radius: 5px; min-height: 24px; }
        QScrollBar::handle:vertical:hover { background: #5a5c7a; }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
    """)
    controller = AppController(app)
    # Keep a strong reference for Qt signal callbacks and the system tray lifetime.
    app.controller = controller  # type: ignore[attr-defined]
    if not QSystemTrayIcon.isSystemTrayAvailable():
        # On desktop environments without a tray, allow right-click through a keyboard shortcut isn't possible;
        # display menu on Ctrl+M so the app remains manageable.
        from PySide6.QtGui import QShortcut, QKeySequence
        shortcut = QShortcut(QKeySequence("Ctrl+M"), controller.pet)
        shortcut.activated.connect(lambda: controller.build_menu().exec(controller.pet.mapToGlobal(controller.pet.rect().center())))
        controller.pet.setToolTip("右键菜单不可用时，可尝试 Ctrl+M 打开菜单。")
    # Context menus are delivered from the pet window itself.
    controller.pet.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
    controller.pet.customContextMenuRequested.connect(
        lambda pos: controller.build_menu().exec(controller.pet.mapToGlobal(pos))
    )
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
