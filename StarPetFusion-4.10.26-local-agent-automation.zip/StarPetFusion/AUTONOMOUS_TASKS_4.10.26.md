# StarPetFusion 4.10.26 本地智能体自动任务部署说明

## 运行方式（手动启动）

1. Windows 10/11 安装 Python 3.10+。
2. 首次安装依赖：双击 `setup.bat`；如果只部署网页服务，也可以在项目目录执行 `python -m pip install -r requirements-service.txt`。
3. 双击 `start_service.bat`，服务只绑定 `127.0.0.1:8765`，不会自动开机启动，也不会监听局域网。
4. 浏览器打开 `http://127.0.0.1:8765/`，进入左侧“自动任务”。
5. 点击“启动执行器”。如需定时巡检，选择“开启（每 30 分钟）”再启动执行器。定时巡检仅在服务进程与任务执行器运行期间有效。

## 可用任务

- **服务与硬件巡检**：检查网关、Ollama、IndexTTS、Qwen3-TTS 的 HTTP 就绪状态并读取 RAM/GPU 资源信息。未就绪的服务会被记录，不会擅自重启外部程序。
- **Ollama 模型盘点**：读取本机 `/api/tags`、`/api/ps` 与版本信息。只允许 loopback 地址；不下载、不删除、不推送模型。
- **角色音色试听生成与质检**：选择 1–5 个角色，填写文本，调用已存在的 IndexTTS/Qwen3-TTS 本地服务。IndexTTS 需要已登记且授权的参考音频。真实生成依赖用户本机模型权重和服务状态。
- **代码测试、备份与打包**：先创建项目备份，再运行项目 `quality_gate.py`；只有质量门禁通过才生成 ZIP 与 SHA-256 文件。不会自动安装依赖或修改源代码。
- **代码变更（需审批）**：提交项目内文本文件的相对路径和完整内容后，任务停在“待审批”。只有点击“批准并执行”后才备份旧文件并写入；路径、扩展名、大小及凭据/数据库目录均受限制。变更后请单独运行“代码测试、备份与打包”。

## 状态、日志和恢复

- SQLite 状态：`data/automation/tasks.sqlite3`
- 日志：`data/automation/automation.log`
- 备份与发布文件：`data/automation/backups/`、`data/automation/artifacts/`
- 任务状态包括 `queued`、`running`、`needs_approval`、`completed`、`failed`、`cancelled`。
- 若进程中断，数据库中残留的 `running` 任务会在下次模块初始化时安全地重新排队。巡检、Ollama 盘点、语音样本任务遇到未捕获的临时异常最多尝试 3 次；质量门禁和代码写入不会自动重试。

## 安全边界

- 没有任意 Shell / PowerShell / Python 命令执行端点。
- 代码写入需审批；覆盖现有文件前自动备份。
- 不会自动删除模型、改系统设置、安装软件、上传音频或重启外部服务。
- 发布包会排除虚拟环境、缓存、自动任务数据库/日志、参考音频/试听样本、数据库文件、模型分配本地配置和凭据文件。
- 这是本机功能权限控制，不是抵御同一 Windows 用户下恶意程序的操作系统沙箱；请不要把服务暴露到公网或局域网。

## HTTP API

- `GET /api/v1/automation/status`
- `POST /api/v1/automation/runner/start`，JSON：`{"periodic_audit": false}`
- `POST /api/v1/automation/runner/stop`
- `GET /api/v1/automation/tasks?limit=50`
- `POST /api/v1/automation/tasks`，任务类型：`health_check`、`ollama_inventory`、`voice_sample`、`release_check`、`code_patch`
- `POST /api/v1/automation/tasks/{task_id}/approval`，JSON：`{"approved": true}`
- `GET /api/v1/automation/events?limit=100`

## 已知限制

此版本提供持久化任务编排、白名单执行器与本地任务工具，并不声称模型已经能够独立推断并任意修改整个代码库。代码变更通过明确的内容提交和人工审批执行；语音质检指标也不能替代人工试听。要在真实 Windows / GPU / TTS 环境中验收，需在用户电脑上运行相应任务。
