import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import autonomous_tasks as at

class AutonomousTaskTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = at.DB_PATH
        at.DB_PATH = Path(self.temp.name) / 'tasks.sqlite3'
        at._init_db()

    def tearDown(self):
        at.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_create_safe_task_persists(self):
        task = at.create_task('health_check', {}, 'test health')
        self.assertEqual(task['status'], 'queued')
        self.assertEqual(at.get_task(task['id'])['title'], 'test health')

    def test_rejects_unknown_task_type(self):
        with self.assertRaises(ValueError):
            at.create_task('run_shell', {'command': 'echo nope'})

    def test_ollama_only_loopback(self):
        with self.assertRaises(ValueError):
            at.create_task('ollama_inventory', {'base_url': 'http://example.com:11434'})

    def test_code_patch_requires_approval_and_refusal_cancels(self):
        task = at.create_task('code_patch', {'relative_path': 'docs/automation-note.md', 'content': 'test content'})
        self.assertEqual(task['status'], 'needs_approval')
        result = at.approve_task(task['id'], False)
        self.assertEqual(result['status'], 'cancelled')

    def test_code_patch_blocks_path_traversal_and_credentials(self):
        with self.assertRaises(ValueError):
            at.create_task('code_patch', {'relative_path': '../outside.py', 'content': 'x'})
        with self.assertRaises(ValueError):
            at.create_task('code_patch', {'relative_path': '.env', 'content': 'SECRET=x'})

    def test_executor_only_runs_registered_handler(self):
        with patch.object(at, '_health_check', return_value={'ok': True, 'summary': {}}):
            self.assertTrue(at._execute('health_check', {})['ok'])
        with self.assertRaises(ValueError):
            at._execute('arbitrary', {})

if __name__ == '__main__':
    unittest.main()
