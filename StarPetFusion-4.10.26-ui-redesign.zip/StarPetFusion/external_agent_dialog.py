from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QSpinBox, QVBoxLayout)

from config_store import app_data_dir
from external_agent import ExternalAgentClient, agent_config


class ExternalAgentDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("外部智能体连接")
        self.setMinimumWidth(560)
        self.setModal(True)
        self.result_config: dict[str, Any] | None = None
        cfg = agent_config()
        layout = QVBoxLayout(self)
        title = QLabel("连接成熟的外部 Agent 应用")
        title.setObjectName("DialogTitle")
        desc = QLabel("适用于提供 OpenAI 兼容 /chat/completions 接口的智能体平台或本地服务。启用后，本轮聊天内容和角色系统提示会发送给该服务；请只连接可信服务。")
        desc.setWordWrap(True)
        desc.setObjectName("MutedText")
        layout.addWidget(title)
        layout.addWidget(desc)
        self.enabled = QCheckBox("启用外部智能体（启用后优先使用该服务回答）")
        self.enabled.setChecked(bool(cfg.get("enabled", False)))
        self.endpoint = QLineEdit(str(cfg.get("endpoint", "https://YOUR_AGENT_HOST/v1")))
        self.endpoint.setPlaceholderText("https://agent.example.com/v1 或 http://127.0.0.1:8000/v1")
        self.model = QLineEdit(str(cfg.get("model", "")))
        self.model.setPlaceholderText("服务商提供的模型 ID / Agent ID")
        self.key_env = QLineEdit(str(cfg.get("api_key_env", "STAR_PET_EXTERNAL_AGENT_KEY")))
        self.connect_timeout = QSpinBox()
        self.connect_timeout.setRange(3, 60)
        self.connect_timeout.setValue(int(cfg.get("connect_timeout", 10)))
        self.connect_timeout.setSuffix(" 秒")
        self.timeout = QSpinBox()
        self.timeout.setRange(10, 600)
        self.timeout.setValue(int(cfg.get("read_timeout", cfg.get("timeout", 240))))
        self.timeout.setSuffix(" 秒")
        self.thinking_enabled = QCheckBox("启用结构化深度思考提示（建议开启）")
        self.thinking_enabled.setChecked(bool(cfg.get("thinking_enabled", True)))
        self.latency_mode = QComboBox()
        self.latency_mode.addItem("快速响应（短提示词、精简上下文）", "fast")
        self.latency_mode.addItem("均衡模式", "balanced")
        self.latency_mode.addItem("深度分析（可能更慢）", "deep")
        current_mode = str(cfg.get("latency_mode", "fast"))
        mode_idx = self.latency_mode.findData(current_mode)
        self.latency_mode.setCurrentIndex(max(0, mode_idx))
        self.max_history = QSpinBox()
        self.max_history.setRange(2, 24)
        self.max_history.setValue(max(2, min(int(cfg.get("max_history_messages", 8)), 24)))
        self.max_tokens = QSpinBox()
        self.max_tokens.setRange(0, 8192)
        self.max_tokens.setSingleStep(256)
        self.max_tokens.setValue(max(0, min(int(cfg.get("max_tokens", 0)), 8192)))
        self.reasoning_effort = QComboBox()
        self.reasoning_effort.addItem("自动兼容（不额外传参）", "auto")
        self.reasoning_effort.addItem("低", "low")
        self.reasoning_effort.addItem("中", "medium")
        self.reasoning_effort.addItem("高", "high")
        current_effort = str(cfg.get("reasoning_effort", "auto"))
        idx = self.reasoning_effort.findData(current_effort)
        self.reasoning_effort.setCurrentIndex(max(0, idx))
        form = QFormLayout()
        form.addRow("启用", self.enabled)
        form.addRow("接口地址", self.endpoint)
        form.addRow("模型 / Agent ID", self.model)
        form.addRow("密钥环境变量名", self.key_env)
        form.addRow("连接建立超时", self.connect_timeout)
        form.addRow("模型生成超时", self.timeout)
        form.addRow("响应策略", self.latency_mode)
        form.addRow("保留历史消息数", self.max_history)
        form.addRow("最大生成 Token（0=服务默认）", self.max_tokens)
        form.addRow("思考增强", self.thinking_enabled)
        form.addRow("原生推理强度", self.reasoning_effort)
        layout.addLayout(form)
        self.status = QLabel("密钥请设置在系统环境变量中。模型生成超时建议 180–300 秒；“原生推理强度”仅适用于明确支持 reasoning_effort 的接口，不兼容时请保持“自动兼容”。")
        self.status.setWordWrap(True)
        self.status.setObjectName("MutedText")
        layout.addWidget(self.status)
        actions = QHBoxLayout()
        self.test_btn = QPushButton("测试连接")
        self.test_btn.setObjectName("SecondaryButton")
        self.test_btn.clicked.connect(self.test_connection)
        actions.addWidget(self.test_btn)
        actions.addStretch(1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Save)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("保存连接")
        buttons.button(QDialogButtonBox.StandardButton.Save).setObjectName("PrimaryButton")
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self.save_settings)
        actions.addWidget(buttons)
        layout.addLayout(actions)

    def _config(self) -> dict[str, Any]:
        return {"enabled": self.enabled.isChecked(), "protocol": "openai_compatible",
            "endpoint": self.endpoint.text().strip().rstrip("/"), "model": self.model.text().strip(),
            "api_key_env": self.key_env.text().strip(), "timeout": self.timeout.value(),
            "read_timeout": self.timeout.value(), "connect_timeout": self.connect_timeout.value(),
            "thinking_enabled": self.thinking_enabled.isChecked(),
            "reasoning_effort": str(self.reasoning_effort.currentData() or "auto"),
            "latency_mode": str(self.latency_mode.currentData() or "fast"),
            "max_history_messages": self.max_history.value(), "max_tokens": self.max_tokens.value(),
            "temperature": 0.4}

    def test_connection(self) -> None:
        cfg = self._config()
        self.test_btn.setEnabled(False)
        self.status.setText("正在测试外部智能体连接……")
        class Worker(QThread):
            result = Signal(bool, str)
            def run(worker_self):
                try:
                    result = ExternalAgentClient(cfg).test_connection()
                    worker_self.result.emit(True, result[:240])
                except Exception as exc:
                    worker_self.result.emit(False, str(exc)[:500])
        self.worker = Worker(self)
        self.worker.result.connect(lambda ok, msg: self.status.setText(("连接成功：" if ok else "连接失败：") + msg))
        self.worker.finished.connect(lambda: self.test_btn.setEnabled(True))
        self.worker.start()

    def save_settings(self) -> None:
        cfg = self._config()
        if cfg["enabled"] and (not cfg["endpoint"] or not cfg["model"] or not cfg["api_key_env"].isidentifier()):
            QMessageBox.warning(self, "配置不完整", "请检查接口地址、模型 ID 和密钥环境变量名。")
            return
        path = app_data_dir() / "integrations.json"
        try:
            current = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
            if not isinstance(current, dict): current = {}
            current["external_agent"] = cfg
            temp = path.with_suffix(".json.tmp")
            temp.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
            temp.replace(path)
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "保存失败", str(exc))
            return
        self.result_config = cfg
        self.accept()
