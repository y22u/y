# 官方资料与素材管理

本项目以官方公开页面作为事实核对入口，保存链接、检索日期与原创摘要。不会自动抓取、拆包或重新分发官方游戏资源、PV/角色动画、立绘、音乐、语音音轨或游戏模型。

## 如何添加合法素材
- 仅放入你有权使用和分发的资源，或仅在个人本地使用且符合适用地区官方规则的资源。
- 建议在 `user_animations/<角色slug>/<状态>.gif` 放置自制/获授权的动画。
- 建议在 `user_voice/<角色slug>/` 放置自己录制或明确获授权的音频。
- 每个资源附 `LICENSE.txt`，注明来源、授权范围、署名和是否允许再分发。
- 官方角色配音演员的声音属于受保护的个人声音/表演；本项目不提供未经授权的声音克隆。

## 官方规则参考
- https://hsr.hoyoverse.com/en-us/news/111203?type=news
- https://support.hoyoverse.com/hc/en-us/articles/51005649400729-What-are-the-guidelines-for-creating-and-selling-fan-made-content
