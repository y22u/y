from __future__ import annotations
"""Safe, local-only data export/import and integrity diagnostics for StarPetFusion."""
import hashlib, json, os, re, shutil, sqlite3, tempfile, time, zipfile
from pathlib import Path
from typing import Any
from config_store import app_data_dir

FORMAT = "starpetfusion-portable-backup"
FORMAT_VERSION = 1
MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
ALLOWED_FILES = ("config.json", "integrations.json", "growth.sqlite3")
SECRET_KEY = re.compile(r"(api.?key|token|secret|password|credential|authorization)", re.I)


def _sanitize(value: Any, key: str = "") -> Any:
    if SECRET_KEY.search(key):
        return ""
    if isinstance(value, dict):
        return {str(k): _sanitize(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_sanitize(v) for v in value]
    return value


def _source_files(root: Path) -> dict[str, Path]:
    return {name: root / name for name in ALLOWED_FILES if (root / name).is_file()}


def create_diagnostic_report() -> dict[str, Any]:
    root = app_data_dir()
    report: dict[str, Any] = {"app": "StarPetFusion", "report_version": 1,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "checks": [], "files": []}
    for name in ALLOWED_FILES:
        path = root / name
        exists = path.is_file()
        entry = {"name": name, "exists": exists, "size_bytes": path.stat().st_size if exists else 0}
        if exists and name.endswith(".json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                entry["json_valid"] = isinstance(data, dict)
                if name == "config.json":
                    entry["provider"] = str(data.get("provider", "unknown"))[:80]
                    entry["model_configured"] = bool(data.get("api_model"))
                elif name == "integrations.json":
                    entry["integrations_configured"] = isinstance(data, dict)
            except Exception:
                entry["json_valid"] = False
        report["files"].append(entry)
    report["checks"].append({"name": "data_directory_readable", "ok": root.is_dir() and os.access(root, os.R_OK)})
    report["checks"].append({"name": "growth_database_integrity", "ok": _sqlite_ok(root / "growth.sqlite3")})
    return report


def _sqlite_ok(path: Path) -> bool:
    if not path.is_file(): return True
    db = None
    try:
        db = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
        return db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    except Exception:
        return False
    finally:
        if db is not None:
            db.close()


def export_backup(destination: str | Path, include_sensitive: bool = False) -> dict[str, Any]:
    """Export a validated archive. Default removes secret-like config fields."""
    root = app_data_dir(); dest = Path(destination).expanduser().resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    entries: dict[str, bytes] = {}
    for name, path in _source_files(root).items():
        if name == "growth.sqlite3":
            fd, tmp_name = tempfile.mkstemp(suffix=".sqlite3"); os.close(fd)
            tmp = Path(tmp_name)
            try:
                src = sqlite3.connect(path, timeout=5)
                dst = sqlite3.connect(tmp, timeout=5)
                try:
                    src.backup(dst)
                    dst.commit()
                finally:
                    dst.close()
                    src.close()
                entries[name] = tmp.read_bytes()
            finally: tmp.unlink(missing_ok=True)
        elif name.endswith(".json"):
            try: data = json.loads(path.read_text(encoding="utf-8"))
            except Exception as exc: raise ValueError(f"{name} 不是有效 JSON，已停止导出") from exc
            if not include_sensitive: data = _sanitize(data)
            entries[name] = (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    manifest = {"format": FORMAT, "version": FORMAT_VERSION, "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "redacted_secrets": not include_sensitive,
                "files": {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}}
    entries["manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in entries.items(): zf.writestr(name, data)
    return {"path": str(dest), "files": len(entries)-1, "redacted_secrets": not include_sensitive, "bytes": dest.stat().st_size}


def inspect_backup(archive: str | Path) -> dict[str, Any]:
    path = Path(archive)
    if not path.is_file() or path.stat().st_size > MAX_ARCHIVE_BYTES: raise ValueError("备份包不存在或超过 100 MB 限制")
    with zipfile.ZipFile(path, "r") as zf:
        names = zf.namelist()
        if sum(info.file_size for info in zf.infolist()) > MAX_ARCHIVE_BYTES:
            raise ValueError("备份包解压后超过 100 MB 限制")
        if any(Path(n).is_absolute() or ".." in Path(n).parts or n not in (*ALLOWED_FILES, "manifest.json") for n in names):
            raise ValueError("备份包包含未允许的路径或文件")
        if "manifest.json" not in names: raise ValueError("缺少备份清单")
        manifest = json.loads(zf.read("manifest.json"))
        if manifest.get("format") != FORMAT or manifest.get("version") != FORMAT_VERSION: raise ValueError("备份格式或版本不受支持")
        expected = manifest.get("files")
        if not isinstance(expected, dict): raise ValueError("备份清单无效")
        for name, digest in expected.items():
            if name not in ALLOWED_FILES or name not in names: raise ValueError("备份清单引用了未允许的文件")
            data = zf.read(name)
            if hashlib.sha256(data).hexdigest() != digest: raise ValueError(f"文件校验失败：{name}")
            if name.endswith(".json"):
                obj = json.loads(data.decode("utf-8"))
                if not isinstance(obj, dict): raise ValueError(f"JSON 结构无效：{name}")
            if name == "growth.sqlite3":
                fd, tmp_name = tempfile.mkstemp(suffix=".sqlite3"); os.close(fd); tmp = Path(tmp_name)
                try:
                    tmp.write_bytes(data)
                    if not _sqlite_ok(tmp): raise ValueError("记忆数据库完整性检查失败")
                finally: tmp.unlink(missing_ok=True)
        return {"valid": True, "created_at": manifest.get("created_at", ""), "files": list(expected), "redacted_secrets": bool(manifest.get("redacted_secrets"))}


def import_backup(archive: str | Path) -> dict[str, Any]:
    """Validate first; create rollback snapshots for each existing target before atomic replacement."""
    info = inspect_backup(archive); root = app_data_dir(); snapshots = root / "backups" / "stage-d-import" / time.strftime("%Y%m%d-%H%M%S")
    with zipfile.ZipFile(archive, "r") as zf:
        manifest = json.loads(zf.read("manifest.json")); files = manifest["files"]
        payloads = {name: zf.read(name) for name in files}
    snapshots.mkdir(parents=True, exist_ok=True)
    for name in payloads:
        target = root / name
        if target.exists(): shutil.copy2(target, snapshots / name)
    replaced = []
    try:
        for name, data in payloads.items():
            target = root / name; target.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp_name = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=root); os.close(fd); tmp = Path(tmp_name)
            try:
                tmp.write_bytes(data)
                if name == "growth.sqlite3" and not _sqlite_ok(tmp): raise ValueError("记忆数据库完整性检查失败")
                os.replace(tmp, target); replaced.append(name)
            finally: tmp.unlink(missing_ok=True)
    except Exception:
        for name in replaced:
            old = snapshots / name
            if old.is_file(): shutil.copy2(old, root / name)
            else: (root / name).unlink(missing_ok=True)
        raise
    return {"imported": replaced, "rollback_snapshot": str(snapshots), "backup_info": info}
