# StarPetFusion 4.5.0 — 免费 TTS 与 Agent 可用性阶段

## 本阶段交付

- 新增 `GET /api/v1/diagnostics`，检查 Edge TTS 依赖、Qwen3-TTS/IndexTTS sidecar 健康、Ollama 本地服务和外部 Agent 配置。只返回是否就绪，不返回密钥。
- 服务版本更新为 4.5.0。
- 新增 `AGENT_PRESETS.json`：Ollama 本地模型、通用 OpenAI 兼容 Agent、本地 OpenAI 兼容服务三种可配置接入预设。
- 保留 4.2 的 Edge TTS（在线免费、需网络）、4.3 的 Qwen3-TTS 与 IndexTTS（本地开源模型、需各自独立环境/权重）以及 Gemini/Google Cloud/通用外部 TTS 适配器。
- 新增本地诊断脚本 `diagnose_integrations.py`，便于用户在自己的 Windows 环境定位缺依赖、sidecar 未启动、Ollama 未启动或 Agent 配置不完整的问题。

## 关键边界

“已接入”指应用代码中有适配器和调用路径；“可使用”还要求对应依赖、模型权重、凭据、网络和硬件均满足。Edge TTS 无 API Key，但依赖互联网及服务可用性；Qwen3/IndexTTS 不需要按调用付费，但下载模型需要网络和磁盘/算力；Ollama 本地模型同样需要本机资源。外部产品（例如 Qoder、Trae、OpenCode 等）只有在具体版本/实例提供可用 API 或兼容服务时才能通过通用连接器使用，不宣称已原生接入每个产品。

## 验证

- `/api/v1/diagnostics` 的 ready 仅代表依赖或服务端点可响应，不保证模型生成成功。
- 在目标电脑执行 `python diagnose_integrations.py`，按提示启动服务；分别在网页 TTS 页面选 Edge、Qwen3、IndexTTS 实际生成短音频，并在 Agent 页面分别测试 Ollama/外部 Agent。
- 真实模型端到端测试需要用户本机下载权重、配置 API 或启动服务后进行，本打包环境不含模型权重与用户凭据。
