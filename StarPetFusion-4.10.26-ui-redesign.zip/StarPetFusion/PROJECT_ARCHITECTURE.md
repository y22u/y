# StarPetFusion 项目结构与功能架构（精简版）

## 核心运行链

`start.bat / main.py` → `PetWidget`（桌宠窗口、动画与交互） → 右键菜单/聊天窗口 → `services.py`（AI API、SQLite 历史、天气和系统监控） → 用户配置目录 `%APPDATA%\StarPetFusion\`。

## 模块分层

- **启动与窗口**：`main.py`、`pet_widget.py`、`config_store.py`、`app_logging.py`。
- **角色资料**：`bundled_roles/` 保存离线角色卡；`skills.py` 读取并组合角色提示词；`character_database.py`、`character_library.py` 与 `character_asset_registry.py` 管理角色资料/素材索引。
- **AI 与语音**：`services.py`、`integrations.py`、`voice_service.py`、`voice_pipeline.py`、`tts_adapters.py`；ASR批处理入口为 `tools/transcribe_audio_review.py`。
- **安全与数据**：`data_safety.py`、`access_control.py`、`permissions_dialog.py`、`data_portability.py`、`productivity_data.py`。
- **可选服务**：`backend/` 提供独立后端；`isolated_tts/` 提供隔离 TTS；`frontend/` 提供轻量前端资源。
- **测试**：`tests/` 覆盖角色库、桌宠交互、数据安全、服务接口、语音适配器与音频转录流程。
- **开源素材准备**：`prepare.py` 只在用户主动执行时从登记的上游仓库下载至 `vendor/`；`download_dafeiyu_assets.py` 会从 `1190fasheqi/dafeiyu-pet` 获取三视图并写入 `vendor/dafeiyu-pet/sprites/`，`download_hsr_assets.py` 是可选角色图片候选导入工具。代码许可不自动授予游戏立绘/动画素材再分发权。

## 资源与缓存策略

- 角色对话数据库、用户配置与导入图片属于用户数据，保留在 `%APPDATA%\StarPetFusion\`，不要通过“清理缓存”删除。
- `data/audio_review/audio_mp3_16k/` 是36段复核音频的唯一保留副本；重复的 `voice_review/audio_mp3_16k/` 已删除。
- Python `__pycache__`、`.pyc`、临时日志、测试缓存及历史逐版说明属于可再生成或重复文件，已清理/合并。
- 没有删除任何 Python 功能模块、角色卡、原始音频或测试用例。

## 当前外观机制

桌宠优先读取用户配置的 `appearance_path`；未设置时使用 `vendor/dafeiyu-pet/sprites/` 下的正面/侧面/背面 PNG（若上游包提供），否则回退到程序绘制形象。用户可通过菜单切换外观或导入单张图片/GIF。上游素材下载是否成功需在联网环境实际执行 `python prepare.py` 验证。
