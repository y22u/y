"""Preflight checks for StarPetFusion and the optional voice-training workflow."""
from __future__ import annotations
import importlib.util
import json
import os
import platform
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main() -> int:
    print('StarPetFusion environment check')
    print(f'Python: {sys.version.split()[0]} ({platform.system()} {platform.machine()})')
    print(f'Project: {ROOT}')
    required = {'PySide6': 'PySide6', 'requests': 'requests', 'psutil': 'psutil'}
    missing = []
    for label, module in required.items():
        ok = importlib.util.find_spec(module) is not None
        print(f'[{"OK" if ok else "MISSING"}] {label}')
        if not ok:
            missing.append(label)
    for label, module in [('System TTS (optional)', 'pyttsx3'), ('Microphone ASR (optional)', 'faster_whisper'), ('Audio capture (optional)', 'sounddevice')]:
        print(f'[{"OK" if importlib.util.find_spec(module) else "OPTIONAL"}] {label}')
    appdata = Path(os.environ.get('APPDATA', Path.home() / '.config')) / 'StarPetFusion'
    print(f'User config: {appdata}')
    integration_file = appdata / 'integrations.json'
    if integration_file.exists():
        try:
            cfg = json.loads(integration_file.read_text(encoding='utf-8'))
            tts = cfg.get('tts', {}) if isinstance(cfg, dict) else {}
            print(f'External TTS: {"enabled" if isinstance(tts, dict) and tts.get("enabled") else "disabled"}')
        except (OSError, ValueError):
            print('[WARN] integrations.json exists but is not valid JSON')
    else:
        print('External TTS: not configured (system TTS can still be used)')
    if missing:
        print('\nMissing required dependencies. Run setup.bat or: python -m pip install -r requirements.txt')
        return 1
    print('\nCore environment looks ready. Audio devices, API credentials, and actual model quality require separate runtime tests.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
