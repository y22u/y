from __future__ import annotations

import json
import os
import logging
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests

from config_store import app_data_dir

logger = logging.getLogger(__name__)


class ChatStore:
    """Lightweight per-role conversation history stored locally in SQLite."""
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (app_data_dir() / "conversations.sqlite3")
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role_slug TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_messages_role_id ON messages(role_slug, id)")

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.path, timeout=5)
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def add(self, role_slug: str, role: str, content: str) -> None:
        with self._lock, self._connect() as db:
            db.execute(
                "INSERT INTO messages(role_slug, role, content, created_at) VALUES(?,?,?,?)",
                (role_slug, role, content, datetime.now().isoformat(timespec="seconds")),
            )

    def history(self, role_slug: str, limit: int = 20) -> list[dict[str, str]]:
        with self._lock, self._connect() as db:
            rows = db.execute(
                "SELECT role, content FROM messages WHERE role_slug=? ORDER BY id DESC LIMIT ?",
                (role_slug, max(1, min(int(limit), 100))),
            ).fetchall()
        rows.reverse()
        return [{"role": r, "content": c} for r, c in rows if r in ("user", "assistant")]

    def clear(self, role_slug: str) -> None:
        with self._lock, self._connect() as db:
            db.execute("DELETE FROM messages WHERE role_slug=?", (role_slug,))


class AIClient:
    def __init__(self, config: dict[str, Any]) -> None:
        self.provider = str(config.get("provider") or "deepseek").lower()
        self.base_url = str(config.get("api_base_url") or "https://api.deepseek.com").rstrip("/")
        self.model = str(config.get("api_model") or "deepseek-flash")
        self.config_key = str(config.get("api_key") or "")
        self.is_local = self.provider == "ollama" or "localhost" in self.base_url or "127.0.0.1" in self.base_url

    def api_key(self) -> str:
        return (os.environ.get("STAR_PET_API_KEY") or os.environ.get("DEEPSEEK_API_KEY") or self.config_key).strip()

    def chat(self, messages: list[dict[str, str]], timeout: int = 45) -> str:
        key = self.api_key()
        if not key and not self.is_local:
            raise RuntimeError("还没有 API Key。请在右键菜单的「AI 设置」中配置，或设置 STAR_PET_API_KEY 环境变量。")
        url = self.base_url + "/chat/completions"
        payload = {"model": self.model, "messages": messages, "temperature": 0.8, "stream": False}
        try:
            resp = requests.post(
                url,
                headers=({"Authorization": f"Bearer {key}"} if key else {}) | {"Content-Type": "application/json"},
                json=payload,
                timeout=timeout,
            )
            resp.raise_for_status()
            body = resp.json()
            answer = body["choices"][0]["message"]["content"]
            if isinstance(answer, list):
                answer = "\n".join(str(part.get("text", "")) for part in answer if isinstance(part, dict))
            answer = str(answer).strip()
            if not answer:
                raise RuntimeError("模型返回了空内容，请重试。")
            return answer
        except requests.Timeout as exc:
            logger.warning("AI request timed out; provider=%s model=%s", self.provider, self.model)
            raise RuntimeError("请求超时，请检查网络或稍后再试。") from exc
        except requests.HTTPError as exc:
            logger.warning("AI HTTP request failed; provider=%s model=%s status=%s", self.provider, self.model, exc.response.status_code if exc.response is not None else "unknown")
            # Provider response bodies can echo request metadata or account details.
            # Keep user-facing errors actionable without exposing raw remote content.
            detail = ""
            status = exc.response.status_code if exc.response is not None else "?"
            if status == 401:
                tip = "请检查 API Key 是否正确。"
            elif status == 402:
                tip = "服务商提示额度或计费异常，请检查账户额度。"
            elif status == 404:
                tip = "请检查 Base URL 与模型 ID 是否正确。"
            elif status == 429:
                tip = "请求过于频繁或额度暂时受限，请稍后重试。"
            else:
                tip = "请检查服务状态、网络与配置。"
            raise RuntimeError(f"模型 API 请求失败（HTTP {status}）：{tip} {detail}") from exc
        except (requests.RequestException, ValueError, KeyError, IndexError, TypeError) as exc:
            logger.warning("AI response processing failed; provider=%s error_type=%s", self.provider, type(exc).__name__)
            raise RuntimeError(f"无法读取模型响应：{exc}") from exc


def get_weather(city: str, timeout: int = 8) -> str:
    city = city.strip() or "Tokyo"
    safe_city = quote(city, safe="")
    headers = {"User-Agent": "StarPetFusion/1.0 (weather lookup)"}
    # Primary source: wttr.in simple text response.
    try:
        response = requests.get(f"https://wttr.in/{safe_city}?format=j1", headers=headers, timeout=timeout)
        response.raise_for_status()
        data = response.json()
        current = data["current_condition"][0]
        temp = current.get("temp_C", "?")
        desc = current.get("lang_zh", [{}])[0].get("value") or current.get("weatherDesc", [{}])[0].get("value", "天气情况未知")
        humidity = current.get("humidity")
        wind = current.get("windspeedKmph")
        extras = []
        if humidity is not None:
            extras.append(f"湿度 {humidity}%")
        if wind is not None:
            extras.append(f"风速 {wind} km/h")
        return f"{city} 当前 {temp}°C，{desc}" + ("；" + "，".join(extras) if extras else "")
    except Exception as first_error:
        # Fallback: text format is lighter and often available where JSON is not.
        try:
            response = requests.get(f"https://wttr.in/{safe_city}?format=3", headers=headers, timeout=timeout)
            response.raise_for_status()
            return response.text.strip().replace("\n", " ")
        except Exception as second_error:
            raise RuntimeError(f"天气查询失败：{second_error}") from first_error


def system_status() -> dict[str, Any]:
    import psutil
    cpu = psutil.cpu_percent(interval=0.15)
    memory = psutil.virtual_memory().percent
    result: dict[str, Any] = {"cpu": cpu, "memory": memory, "gpu_temp": None}
    try:
        import pynvml  # type: ignore
        pynvml.nvmlInit()
        try:
            count = pynvml.nvmlDeviceGetCount()
            if count:
                handle = pynvml.nvmlDeviceGetHandleByIndex(0)
                result["gpu_temp"] = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
        finally:
            pynvml.nvmlShutdown()
    except Exception:
        pass
    return result


def open_local_path(path: Path) -> None:
    """Open a folder in the user's file manager using the platform's standard API."""
    import subprocess
    import sys
    path.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])
