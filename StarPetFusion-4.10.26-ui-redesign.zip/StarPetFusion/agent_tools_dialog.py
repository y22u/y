from __future__ import annotations
import json
from pathlib import Path
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QListWidget,QPushButton,QFileDialog,QMessageBox
from config_store import app_data_dir

class AgentToolsDialog(QDialog):
    """UI for explicitly granting local directories to the Agent file tools."""
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle('Agent 工具与目录授权'); self.resize(640,430)
        self.path=app_data_dir()/'integrations.json'; self.data={}
        try: self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
        except (OSError,ValueError): self.data={}
        cfg=self.data.get('agent_tools',{}) if isinstance(self.data,dict) else {}
        self.roots=[str(Path(x).expanduser().resolve()) for x in cfg.get('roots',[]) if isinstance(x,str)] if isinstance(cfg,dict) else []
        layout=QVBoxLayout(self); layout.addWidget(QLabel('仅授权你选择的目录。Agent 可以列出、搜索和读取文本文件；创建或覆盖文件时仍需逐次确认。'))
        self.list=QListWidget(); layout.addWidget(self.list); self._refresh()
        row=QHBoxLayout(); layout.addLayout(row)
        add=QPushButton('添加目录…'); add.clicked.connect(self.add_root); row.addWidget(add)
        remove=QPushButton('移除选中'); remove.clicked.connect(self.remove_root); row.addWidget(remove); row.addStretch(1)
        save=QPushButton('保存授权'); save.clicked.connect(self.save); row.addWidget(save)
    def _refresh(self):
        self.list.clear(); self.list.addItems(self.roots)
    def add_root(self):
        p=QFileDialog.getExistingDirectory(self,'选择授权目录',str(Path.home()))
        if p:
            resolved=str(Path(p).resolve())
            if resolved not in self.roots: self.roots.append(resolved); self._refresh()
    def remove_root(self):
        i=self.list.currentRow()
        if i>=0: self.roots.pop(i); self._refresh()
    def save(self):
        self.data=self.data if isinstance(self.data,dict) else {}
        self.data['agent_tools']={'roots':self.roots}
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True); tmp=self.path.with_suffix('.json.tmp')
            tmp.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(self.path)
        except OSError as exc: QMessageBox.warning(self,'保存失败',str(exc)); return
        self.accept()
