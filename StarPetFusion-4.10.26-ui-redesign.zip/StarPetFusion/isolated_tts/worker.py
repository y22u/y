"""Loopback-only TTS sidecar; run this file inside the model's own Python environment."""
from __future__ import annotations
import os, sys, tempfile, uuid
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
PROVIDER = os.environ.get("STAR_PET_TTS_SIDECAR_PROVIDER", "qwen3").strip().lower()
PORT = int(os.environ.get("STAR_PET_TTS_SIDECAR_PORT", "8766" if PROVIDER == "qwen3" else "8767"))
app = FastAPI(title=f"StarPetFusion isolated {PROVIDER} TTS", version="1.0.0")
class Request(BaseModel):
    text: str = Field(min_length=1, max_length=8000)
    voice: str = ""
    language: str = "zh-CN"
    style: str = ""
    speed: float = Field(default=1.0, ge=0.5, le=2.0)

@app.get("/health")
def health():
    return {"status": "ok", "provider": PROVIDER, "environment": "isolated", "port": PORT}

@app.post("/synthesize")
def synthesize(req: Request):
    out = Path(tempfile.gettempdir()) / "starpetfusion-sidecar-audio" / f"{uuid.uuid4().hex}.wav"
    try:
        if PROVIDER == "qwen3":
            from tts_adapters import Qwen3TTSAdapter
            path = Qwen3TTSAdapter().synthesize(req.text, out, voice=req.voice or "Vivian", language=req.language, style=req.style, speed=req.speed)
        elif PROVIDER == "indextts":
            from tts_adapters import IndexTTSAdapter
            path = IndexTTSAdapter().synthesize(req.text, out, voice=req.voice, language=req.language, style=req.style, speed=req.speed)
        else:
            raise ValueError("不支持的 sidecar provider")
        return FileResponse(path, media_type="audio/wav", filename="starpetfusion-tts.wav")
    except Exception as exc:
        # Keep internals out of the HTTP response; details remain in the local console.
        print(f"[{PROVIDER}] synthesis failed: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        raise HTTPException(status_code=502, detail=f"{PROVIDER} 合成失败（{type(exc).__name__}），请查看对应隔离服务窗口日志") from exc
