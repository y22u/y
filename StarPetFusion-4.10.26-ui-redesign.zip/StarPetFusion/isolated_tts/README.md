# StarPetFusion 4.3 — Qwen3-TTS / IndexTTS 隔离部署

## 隔离架构

- StarPetFusion 网关继续使用项目原有 Python 环境，监听 `127.0.0.1:8765`。
- Qwen3-TTS 使用项目目录下独立的 `.venvs/qwen3`，只在 `127.0.0.1:8766` 提供本机 HTTP 服务。
- IndexTTS 使用官方仓库 `isolated_tts/IndexTTS` 自己的 `uv` 项目环境，只在 `127.0.0.1:8767` 提供本机 HTTP 服务。
- 网关只通过 loopback HTTP 请求模型服务，不在网关进程内加载 Qwen/Index 的 Torch、Transformers 等重量级依赖。
- 模型缓存和模型权重可能占用大量磁盘空间；两个模型服务同时运行时也会争用内存/显存。依赖隔离不等于硬件资源隔离。

## 安装（Windows）

前置：Python 3.12、Git for Windows、可联网下载 Python 包和模型权重。双击项目根目录 `install_isolated_tts.bat`。该脚本会在 `.venvs/qwen3` 创建 Qwen 独立环境，并把 IndexTTS 官方仓库克隆到 `isolated_tts/IndexTTS`，由 `uv` 在该仓库内创建/管理环境。它不会把 `qwen-tts` 安装到 StarPetFusion 主环境。

如果你的显卡/驱动不支持对应 PyTorch 版本，需根据 PyTorch 官方安装选择器先选合适的 CPU/CUDA 版本，再安装 `qwen-tts`；安装脚本不会自动替换 NVIDIA 驱动或 CUDA 驱动。

## 模型权重

### Qwen3-TTS

首次调用会从 Hugging Face 下载默认模型 `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice` 及所需 tokenizer 权重。可通过环境变量 `STAR_PET_QWEN3_TTS_MODEL` 更换为官方支持的模型 ID 或本地模型目录。模型下载需要网络和足够磁盘空间。

### IndexTTS

IndexTTS 仓库代码和 Python 环境不等于模型权重已下载。请按官方仓库当前 README 的模型下载说明准备 `checkpoints`（需含 `config.yaml` 和所需权重），并确认参考 WAV 文件路径有效。可以在启动前设置：

```bat
set STAR_PET_INDEXTTS_MODEL_DIR=D:\AIModels\IndexTTS\checkpoints
set STAR_PET_INDEXTTS_CONFIG=D:\AIModels\IndexTTS\checkpoints\config.yaml
set STAR_PET_INDEXTTS_REFERENCE_WAV=D:\AIModels\voices\reference.wav
```

参考音频应来自你有权使用的声音。默认示例 WAV 路径仅是便捷默认值，实际文件是否存在取决于官方仓库版本及示例资源下载状态。

## 启动顺序

1. 运行 `install_isolated_tts.bat` 并按上文准备模型权重。
2. 双击 `start_qwen3_sidecar.bat`，等待模型服务启动/首次下载完成。
3. 双击 `start_indextts_sidecar.bat`，等待模型服务启动。
4. 启动 StarPetFusion 主网关：

```powershell
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8765
```

5. 浏览器打开 `http://127.0.0.1:8765/`，进入“语音与 TTS”，分别选择 Qwen3-TTS 或 IndexTTS。

也可以双击 `start_all_isolated_tts.bat` 同时打开两个服务窗口。该脚本只负责启动，不会代替模型权重准备或验证显卡兼容性。

## 健康检查

- `http://127.0.0.1:8766/health` — Qwen3 sidecar
- `http://127.0.0.1:8767/health` — IndexTTS sidecar

若网关显示合成失败，先看对应 sidecar 控制台日志；网关的 `/api/v1/tts` 会将详细异常限制在服务端日志中。

## 隔离边界与限制

这是进程 + Python 环境 + 本机 HTTP 的依赖隔离，不是 Docker/VM 级安全沙箱。两个服务共用当前 Windows 用户权限、磁盘和 GPU。两个端口仅绑定 `127.0.0.1`，不要改为 `0.0.0.0` 公开到局域网。Qwen3-TTS 和 IndexTTS 的实际模型推理需在目标电脑完成验证；打包本身不包含大体积模型权重，也不能保证所有 Windows GPU 驱动组合一次安装成功。
