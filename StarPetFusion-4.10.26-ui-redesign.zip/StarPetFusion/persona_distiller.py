from __future__ import annotations
"""Context-aware persona distillation for StarPetFusion.

Stable traits stay in the prompt; long background and topic-specific guidance are
selected only when relevant. This is prompt compression, not model training.
"""
import json
from pathlib import Path
from typing import Any

ALWAYS_FIELDS = (("name", "name"), ("lore_summary", "lore_summary"), ("identity", "核心身份"), ("personality", "核心性格"), ("speech_style", "speech_style"), ("interaction_rules", "interaction_rules"))
TOPIC_TERMS = {
    "background": ("背景", "经历", "剧情", "关系", "世界观", "是谁", "设定", "过去", "故事"),
    "motivation": ("为什么", "目标", "动机", "价值观", "在意", "选择"),
    "strengths": ("优点", "擅长", "能力", "优势", "长处"),
    "vulnerabilities": ("缺点", "弱点", "不足", "矛盾", "脆弱", "压力"),
    "habits": ("习惯", "口头", "说话", "语气", "风格", "怎么表达"),
    "emotional_responses": ("难过", "焦虑", "生气", "心情", "情绪", "安慰", "压力", "累", "迷茫"),
    "relationship_style": ("关系", "朋友", "信任", "相处", "在乎", "同伴"),
    "scenario": ("情境", "场景", "扮演", "日常", "陪我", "一起"),
    "first_message": ("开场", "打招呼", "第一句", "自我介绍"),
    "example_dialogue": ("示例", "例子", "怎么回答", "对话", "语料"),
}

def _read_manifest(role_dir: Path) -> dict[str, Any]:
    try:
        data = json.loads((role_dir / "manifest.json").read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}

def distill_persona(role_dir: Path, user_text: str = "", max_chars: int = 2600) -> str:
    """Build a bounded role card with stable identity plus topic-relevant details."""
    data = _read_manifest(role_dir)
    if not data:
        return ""
    parts: list[str] = []
    used = 0
    def add(label: str, value: Any) -> None:
        nonlocal used
        if value is None or value == "" or value == []:
            return
        if isinstance(value, list):
            value = "；".join(str(x) for x in value if str(x).strip())
        elif isinstance(value, dict):
            value = "；".join(f"{k}：{v}" for k, v in value.items())
        text = f"{label}：{str(value).strip()}"
        remaining = max_chars - used
        if remaining <= len(label) + 3:
            return
        text = text[:remaining]
        parts.append(text)
        used += len(text) + 1
    for key, label in ALWAYS_FIELDS:
        add(label, data.get(key))
    query = (user_text or "").casefold()
    selected: list[str] = []
    for field, terms in TOPIC_TERMS.items():
        if any(term.casefold() in query for term in terms):
            selected.append(field)
    # Only include a compact subset of dialogue examples when the user asks about style/examples.
    for field in selected:
        if field == "example_dialogue":
            examples = data.get(field, [])
            if isinstance(examples, list) and examples:
                first = examples[0]
                if isinstance(first, dict):
                    add("对话示例", f"用户：{first.get('user','')}；{data.get('name','角色')}：{first.get('character','')}")
        elif field == "background":
            add("背景摘要", data.get("background") or data.get("lore_summary"))
        else:
            add(field, data.get(field))
    # A tiny first-message seed is useful only when the user asks for an opening/greeting.
    if any(term in query for term in TOPIC_TERMS["first_message"]):
        add("开场示例", data.get("first_message"))
    return "【人物设定蒸馏摘要】\n" + "\n".join(parts) if parts else ""
