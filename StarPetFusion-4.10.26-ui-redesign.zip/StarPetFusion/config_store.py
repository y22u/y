from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

APP_NAME = "StarPetFusion"


def app_data_dir() -> Path:
    """Return a per-user writable config directory, separate from source files."""
    if os.name == "nt" and os.environ.get("APPDATA"):
        root = Path(os.environ["APPDATA"])
    else:
        root = Path.home() / ".config"
    path = root / APP_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


DEFAULT_CONFIG: dict[str, Any] = {
    "mode": "wander",             # wander | follow | still
    "size": 190,
    "topmost": True,
    "passthrough": False,
    "animations_enabled": True,
    "animation_style": "gentle",
    "favorite_roles": [],
    "idle_chatter": False,
    "agent_enabled": True,
    "role_styles": {},  # Per-role language style, independent of original character data.
    "voice_enabled": False,  # Optional system TTS; disabled by default.
    "role_animation_assets": {},
    "role_portraits": {},
    "active_animation_state": "idle",
    "permissions": {"growth": True, "chat": True, "network": True, "edit_settings": True, "manage_assets": True, "edit_roles": True, "history_export": True, "history_delete": True, "install_external": True, "productivity": True, "file_search": True, "open_files": True},

    "city": "Tokyo",
    "provider": "deepseek",
    "api_base_url": "https://api.deepseek.com",
    "api_model": "deepseek-flash",
    "api_key": "",               # Prefer STAR_PET_API_KEY / DEEPSEEK_API_KEY environment vars.
    "default_role": "默认助手",
    "role_prompt_overrides": {},
    "appearance_path": "",      # Optional custom desktop-pet image; empty means original fish.
    "x": None,
    "y": None,
}


class ConfigStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (app_data_dir() / "config.json")
        self.data: dict[str, Any] = dict(DEFAULT_CONFIG)
        self.load()

    def load(self) -> dict[str, Any]:
        if self.path.exists():
            try:
                loaded = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    self.data.update(loaded)
                    # Migrate the retired DeepSeek chat alias to the current API model ID.
                    if (self.data.get("provider", "deepseek") == "deepseek"
                            and self.data.get("api_model") == "deepseek-chat"):
                        self.data["api_model"] = "deepseek-flash"
            except (OSError, json.JSONDecodeError):
                # Keep defaults; do not crash the pet because of a malformed config.
                pass
        self.save()
        return self.data

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".json.tmp")
        temp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self.data[key] = value
        self.save()
