# StarPetFusion 4.10.12

- Added searchable character image lookbook and local preview switching.
- Bundled 7 uploaded art images and 1 generated concept poster.
- Added `character_assets/USER_CHARACTER_LIBRARY.json`.
- Preserved the existing Da Feiyu desktop pet core and visual baseline.
- Image assets are previews, not 3D models.
