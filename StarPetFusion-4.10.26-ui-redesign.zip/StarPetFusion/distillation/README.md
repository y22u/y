# StarPetFusion teacher–student TTS workflow (laptop-first)

## What this is
This implements **dataset-level distillation**: an authorized teacher TTS produces text/audio pairs, and a smaller pretrained student TTS is fine-tuned on those pairs. It does not copy the teacher's weights and is not logit-level distillation. Classical logit/hidden-state distillation requires a teacher that exposes compatible training targets; most hosted TTS APIs do not expose those internals.

## Rights and dataset
Use only recordings, transcripts, and voices for which you have explicit permission or a license that permits model training and redistribution. Official PV/story audio is not automatically licensed for training. This project intentionally does not ship scraped or cloned official actor audio. For character-inspired results, use a licensed synthetic voice and describe delivery traits (pace, warmth, articulation) without impersonating a specific actor.

## Laptop constraints
- Start with a pretrained multilingual/single-language student checkpoint supported by your installed TTS toolkit; do not train a high-quality neural TTS from scratch on a laptop.
- Prefer CPU-friendly batch sizes (1–4), short clips, 16–22.05 kHz where compatible, and early stopping. A GPU is helpful but not required for dataset preparation; training may be slow on CPU.
- Keep 10% of samples as held-out validation, compare intelligibility and latency, and retain the original checkpoint.

## Steps
1. Create `texts.txt`, one sentence per line, using text you are allowed to synthesize.
2. Configure `STAR_PET_TTS_ENDPOINT`, optional `STAR_PET_TTS_MODEL`, and `STAR_PET_TTS_API_KEY` in your environment. Endpoint must be HTTPS or loopback HTTP.
3. Generate pairs (voice must be licensed for this use):

   ```powershell
   python distillation/prepare_dataset.py --texts texts.txt --out distillation/teacher_dataset --endpoint https://YOUR_PROVIDER/v1/audio/speech --model YOUR_MODEL --voice YOUR_LICENSED_VOICE --authorized
   ```

4. Select a pretrained student checkpoint and matching Coqui TTS config. Configure the config's dataset formatter/path to the generated folder, then run:

   ```powershell
   python distillation/train_student.py --dataset distillation/teacher_dataset --config path/to/student_config.json --checkpoint path/to/student_checkpoint.pth --output runs/student_tts --dry-run
   ```

   Remove `--dry-run` to launch training. Coqui versions and recipes differ, so verify that the config uses a compatible dataset formatter and the installed version's training command.

## External TTS adapter
`tts_adapters.py` supports an OpenAI-compatible speech endpoint or a generic JSON endpoint. It sends text and voice preset; provider-specific payloads may need a small adapter. API keys are read from environment variables, not stored in project files.

## Quick start on Windows

1. Run `setup.bat` once; it creates `.venv` and installs the desktop app dependencies.
2. Run `start.bat` to open StarPetFusion. Enable voice output in the app's settings/configuration; with `pyttsx3` installed it uses an OS-installed general-purpose voice.
3. Run `python check_environment.py` if startup or audio fails.
4. To use an external TTS provider, copy the `tts` object from `integrations.example.json` to `%APPDATA%\StarPetFusion\integrations.json`, fill in the provider endpoint/model/authorized voice, set `enabled` to `true`, and set the API key in the environment variable named by `api_key_env`. Restart the app. Provider request/response formats differ; this adapter expects audio bytes with an `audio/*` content type.

## Quick dataset smoke test

Use a provider and voice whose terms explicitly allow training. Copy `texts.example.txt` to your own text list, then run the command above. The example contains only generic original sentences. The dataset generator makes network requests to the endpoint you configure; it does not scrape game clients, PVs, story videos, or protected pages.

A generated dataset is not itself a trained model. Fine-tuning still needs a compatible Coqui TTS installation, a model checkpoint, and a matching config. Do not expect a reliable character voice from a tiny smoke-test dataset; test intelligibility, pronunciation, latency, and licensing before daily use.
