"""Create teacher-generated TTS pairs for a student model using authorized data.

Input: UTF-8 text file, one utterance per line.
Output: wav files + metadata.csv in a simple LJSpeech-like format.
This is dataset-level teacher distillation; it does not copy teacher weights.
"""
from __future__ import annotations
import argparse, csv, os, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_adapters import ExternalTTSAdapter


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--texts', required=True, help='UTF-8 text file, one sentence per line')
    ap.add_argument('--out', default='distillation/teacher_dataset')
    ap.add_argument('--endpoint', default=os.environ.get('STAR_PET_TTS_ENDPOINT', ''))
    ap.add_argument('--mode', choices=['openai_compatible', 'generic_json'], default='openai_compatible')
    ap.add_argument('--model', default=os.environ.get('STAR_PET_TTS_MODEL', ''))
    ap.add_argument('--voice', default='alloy', help='Provider voice preset; use only authorized voices')
    ap.add_argument('--language', default='zh-CN')
    ap.add_argument('--authorized', action='store_true', help='Confirm you have rights to use the selected voice/model and data')
    args = ap.parse_args()
    if not args.authorized:
        ap.error('For safety, pass --authorized only after confirming the provider license and voice/data permissions.')
    if not args.endpoint:
        ap.error('Set --endpoint or STAR_PET_TTS_ENDPOINT')
    source = Path(args.texts)
    if not source.is_file():
        ap.error(f'text file not found: {source}')
    lines = [re.sub(r'\s+', ' ', x).strip() for x in source.read_text(encoding='utf-8').splitlines()]
    lines = [x for x in lines if x]
    if not lines:
        ap.error('no non-empty text lines found')
    out = Path(args.out); wav_dir = out / 'wavs'; wav_dir.mkdir(parents=True, exist_ok=True)
    adapter = ExternalTTSAdapter(args.endpoint, mode=args.mode, model=args.model)
    manifest = out / 'metadata.csv'
    with manifest.open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f, delimiter='|')
        for i, line in enumerate(lines, 1):
            name = f'{i:06d}.wav'
            adapter.synthesize(line, wav_dir / name, voice=args.voice, language=args.language)
            writer.writerow([name, line, line])
            print(f'[{i}/{len(lines)}] {name}')
    (out / 'DATA_RIGHTS.txt').write_text(
        'Dataset generated from a user-configured TTS provider.\n'
        'Keep provider license, model ID/version, permission records, and source text with this dataset.\n'
        'Do not use voices or recordings without the relevant rights/consent.\n', encoding='utf-8')
    print(f'Wrote {len(lines)} samples to {manifest}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
