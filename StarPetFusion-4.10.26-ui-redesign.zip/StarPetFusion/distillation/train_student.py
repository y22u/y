"""Validate a teacher-generated dataset and launch Coqui TTS student fine-tuning.

Requires an installed Coqui TTS version, a compatible pretrained checkpoint and config.
Training recipes differ by model; use a checkpoint/config pair supported by your installed version.
"""
from __future__ import annotations
import argparse, csv, subprocess, sys
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--dataset', required=True, help='Folder containing metadata.csv and wavs/')
    ap.add_argument('--config', required=True, help='Student model config JSON compatible with installed Coqui TTS')
    ap.add_argument('--checkpoint', required=True, help='Pretrained student checkpoint to fine-tune')
    ap.add_argument('--output', default='runs/student_tts')
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()
    dataset = Path(args.dataset).resolve(); meta = dataset / 'metadata.csv'
    config = Path(args.config).resolve(); ckpt = Path(args.checkpoint).resolve()
    if not meta.is_file() or not (dataset / 'wavs').is_dir():
        ap.error('dataset must contain metadata.csv and wavs/')
    if not config.is_file() or not ckpt.is_file():
        ap.error('config/checkpoint path does not exist')
    with meta.open(encoding='utf-8', newline='') as f:
        rows = list(csv.reader(f, delimiter='|'))
    if len(rows) < 10:
        ap.error('need at least 10 samples for a smoke-test; useful quality usually needs substantially more diverse data')
    missing = [r[0] for r in rows if len(r) < 3 or not (dataset / 'wavs' / r[0]).is_file()]
    if missing:
        ap.error(f'{len(missing)} audio files missing from manifest; first: {missing[0]}')
    cmd = [sys.executable, '-m', 'TTS.bin.train_tts', '--config_path', str(config),
           '--restore_path', str(ckpt), '--coqpit.output_path', str(Path(args.output).resolve())]
    print('Validated teacher-generated dataset:', len(rows), 'samples')
    print('Student training command:', ' '.join(cmd))
    if args.dry_run:
        print('Dry run only; no model weights were changed.')
        return 0
    print('Note: ensure the selected config points to this dataset in its dataset formatter/path fields.')
    return subprocess.call(cmd)

if __name__ == '__main__':
    raise SystemExit(main())
