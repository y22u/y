# 角色设定与形象数字库

StarPetFusion 使用本地 SQLite 数据库 `character_assets/character_library.db` 管理角色设定与形象素材索引。

- `characters`：角色 slug、显示名、角色 manifest JSON、提示词/设定 Markdown。
- `assets`：本地素材路径、类型、来源平台/链接、许可说明、署名要求、是否允许再分发、SHA-256。
- `library_meta`：数据库版本与用途说明。

## 初始化 / 重建角色资料

```bash
python tools/build_character_library.py
```

当前数据库从 `bundled_roles/*/manifest.json` 与 `prompt_profile.md` 导入已有的角色设定，不会覆盖用户独立保存的图片文件。

## 导入你有权使用的形象图片

将图片保存到本机后，可用 `character_library.register_asset(...)` 复制到 `character_assets/<role-slug>/` 并登记来源、许可和校验值。`role-slug` 必须是数据库已有角色。常见状态名：`portrait`、`idle`、`happy`、`think`、`sleep`。图片进入角色素材目录后，桌宠的“切换桌宠外观”菜单即可扫描识别。

## 社交平台素材的使用边界

公开可见不等于可自由下载、打包再分发。每张图都需要逐项核对作者许可、署名要求、修改权限和再分发范围。未经许可不自动爬取或打包其他创作者的崩铁 Q 版作品；数据库可以登记来源和许可，避免素材来源丢失。当前发布包不包含未经授权的官方立绘、游戏模型或社交平台同人图片。

## 大肥鱼默认形象

当未配置自定义图片、且没有原始外部精灵文件时，桌宠会使用 `pet_widget.py` 中的内置矢量绘制形象，不依赖网络或外部图片。若要恢复某张特定的“网络热门图”，需要提供该图或其确切出处；本项目不会把相似绘制冒充成原图。
