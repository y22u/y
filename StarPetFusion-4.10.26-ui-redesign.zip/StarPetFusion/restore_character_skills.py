"""Restore missing bundled role SKILL.md files without overwriting existing user data.

Usage:
  python restore_character_skills.py
  python restore_character_skills.py --restore-vendor

Default mode repairs missing files under bundled_roles/ from the packaged recovery
snapshot. Optional --restore-vendor copies missing role cards into vendor/hsr-skills/
only when the destination slug is absent or has no SKILL.md. Existing files are
never overwritten. A JSON report is written to skill_recovery_report.json.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUNDLED = ROOT / "bundled_roles"
RECOVERY = ROOT / "skill_recovery" / "bundled_roles"
VENDOR = ROOT / "vendor" / "hsr-skills"
REPORT = ROOT / "skill_recovery_report.json"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="诊断并恢复缺失的 StarPetFusion 角色 SKILL.md")
    parser.add_argument("--restore-vendor", action="store_true",
                        help="同时把缺失的内置角色资料补到 vendor/hsr-skills/；不会覆盖已有文件")
    args = parser.parse_args()

    report = {
        "app": "StarPetFusion",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "restored_bundled": [],
        "restored_vendor": [],
        "already_present": [],
        "missing_recovery_source": [],
        "errors": [],
    }
    RECOVERY.mkdir(parents=True, exist_ok=True)
    BUNDLED.mkdir(parents=True, exist_ok=True)

    snapshots = sorted(p for p in RECOVERY.iterdir() if p.is_dir())
    if not snapshots:
        print("[错误] 找不到内置恢复快照：", RECOVERY)
        print("请从完整工程 ZIP 重新解压 skill_recovery/ 目录。")
        return 2

    for snap in snapshots:
        src_skill = snap / "SKILL.md"
        if not src_skill.is_file():
            report["missing_recovery_source"].append(snap.name)
            continue
        dst_dir = BUNDLED / snap.name
        dst_skill = dst_dir / "SKILL.md"
        try:
            dst_dir.mkdir(parents=True, exist_ok=True)
            if dst_skill.is_file():
                report["already_present"].append(snap.name)
            else:
                shutil.copy2(src_skill, dst_skill)
                report["restored_bundled"].append({
                    "slug": snap.name, "path": str(dst_skill.relative_to(ROOT)),
                    "sha256": digest(dst_skill)
                })
            src_manifest = snap / "manifest.json"
            dst_manifest = dst_dir / "manifest.json"
            if src_manifest.is_file() and not dst_manifest.exists():
                shutil.copy2(src_manifest, dst_manifest)
        except OSError as exc:
            report["errors"].append({"slug": snap.name, "error": str(exc)})

    if args.restore_vendor:
        VENDOR.mkdir(parents=True, exist_ok=True)
        for snap in snapshots:
            src_skill = snap / "SKILL.md"
            if not src_skill.is_file():
                continue
            dst_dir = VENDOR / snap.name
            dst_skill = dst_dir / "SKILL.md"
            try:
                if dst_skill.is_file():
                    continue
                dst_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_skill, dst_skill)
                report["restored_vendor"].append({
                    "slug": snap.name, "path": str(dst_skill.relative_to(ROOT)),
                    "sha256": digest(dst_skill)
                })
            except OSError as exc:
                report["errors"].append({"vendor_slug": snap.name, "error": str(exc)})

    try:
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as exc:
        print("[警告] 无法写入报告：", exc)

    print("StarPetFusion 角色 Skill 恢复报告")
    print(f"内置恢复快照：{len(snapshots)} 个")
    print(f"补回 bundled_roles：{len(report['restored_bundled'])} 个")
    print(f"补回 vendor/hsr-skills：{len(report['restored_vendor'])} 个")
    print(f"原本已存在：{len(report['already_present'])} 个")
    print(f"恢复源缺失：{len(report['missing_recovery_source'])} 个")
    print(f"错误：{len(report['errors'])} 个")
    print("报告文件：", REPORT)
    print("注意：外部 hsr-skills 的完整上游资料不一定等同于内置角色卡；内置恢复仅保证本项目角色卡可用。")
    return 1 if report["errors"] or report["missing_recovery_source"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
