"""Pluggable TTS adapter for authorized third-party services.

Supports a generic JSON endpoint and an OpenAI-compatible /v1/audio/speech endpoint.
Never embeds API keys; keys are read from environment variables.
"""
from __future__ import annotations
import os
from pathlib import Path
from urllib.parse import urlparse
import requests


def _valid_endpoint(url: str) -> bool:
    try:
        p = urlparse(url)
        host = (p.hostname or "").lower()
        return p.scheme == "https" or (p.scheme == "http" and host in {"localhost", "127.0.0.1", "::1"})
    except ValueError:
        return False


class ExternalTTSAdapter:
    """Simple external TTS client. The service must be configured by the user."""
    def __init__(self, endpoint: str, api_key_env: str = "STAR_PET_TTS_API_KEY",
                 mode: str = "openai_compatible", model: str = "", timeout: int = 45):
        self.endpoint = str(endpoint).strip()
        self.api_key_env = str(api_key_env).strip()[:100]
        self.mode = mode if mode in {"openai_compatible", "generic_json"} else "openai_compatible"
        self.model = str(model).strip()[:160]
        self.timeout = max(5, min(int(timeout), 120))
        if not _valid_endpoint(self.endpoint):
            raise ValueError("TTS endpoint must use HTTPS or loopback HTTP")

    def synthesize(self, text: str, output_path: str | Path, *, voice: str = "alloy",
                   language: str = "zh-CN", style: str = "neutral", speed: float = 1.0) -> Path:
        text = str(text).strip()
        if not text:
            raise ValueError("text must not be empty")
        if len(text) > 4000:
            raise ValueError("text exceeds 4000 characters")
        speed = max(0.5, min(float(speed), 2.0))
        headers = {"Content-Type": "application/json"}
        key = os.environ.get(self.api_key_env, "").strip() if self.api_key_env else ""
        if key:
            headers["Authorization"] = f"Bearer {key}"
        if self.mode == "openai_compatible":
            payload = {"input": text, "voice": str(voice)[:100], "speed": speed, "response_format": "wav"}
            if self.model:
                payload["model"] = self.model
        else:
            payload = {"text": text, "voice": str(voice)[:100], "language": language[:16],
                       "style": style[:40], "speed": speed, "format": "wav"}
        response = requests.post(self.endpoint, json=payload, headers=headers, timeout=self.timeout)
        response.raise_for_status()
        content_type = response.headers.get("Content-Type", "").split(";", 1)[0].lower()
        if not content_type.startswith("audio/") or not response.content or len(response.content) > 40_000_000:
            raise ValueError("TTS service must return audio/* bytes (max 40 MB)")
        target = Path(output_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(response.content)
        return target


class EdgeTTSAdapter:
    """Free-to-use Edge online speech adapter; no API key, but internet is required.

    This relies on Microsoft's online Edge speech endpoint through edge-tts; it is not
    an offline model and availability/terms are controlled by the service provider.
    """
    def __init__(self, timeout: int = 45):
        self.timeout = max(5, min(int(timeout), 120))

    def synthesize(self, text: str, output_path: str | Path, *, voice: str = "zh-CN-XiaoxiaoNeural",
                   language: str = "zh-CN", style: str = "neutral", speed: float = 1.0) -> Path:
        import asyncio
        text = str(text).strip()
        if not text or len(text) > 8000:
            raise ValueError("文本不能为空且不能超过 8000 字符")
        try:
            import edge_tts
        except ImportError as exc:
            raise ValueError("缺少 edge-tts；请运行 python -m pip install edge-tts") from exc
        rate = int((max(0.5, min(float(speed), 2.0)) - 1.0) * 100)
        rate_text = f"{rate:+d}%"
        target = Path(output_path).with_suffix(".mp3")
        target.parent.mkdir(parents=True, exist_ok=True)
        async def _run():
            communicate = edge_tts.Communicate(text, voice=str(voice)[:100], rate=rate_text)
            await asyncio.wait_for(communicate.save(str(target)), timeout=self.timeout)
        try:
            asyncio.run(_run())
        except RuntimeError as exc:
            # FastAPI's synchronous route normally runs in a worker thread, so this is a
            # defensive fallback for callers already running an event loop.
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                pool.submit(lambda: asyncio.run(_run())).result(timeout=self.timeout)
        if not target.is_file() or target.stat().st_size <= 0:
            raise ValueError("Edge TTS 未生成有效音频文件")
        return target


_QWEN_MODELS = {}

class Qwen3TTSAdapter:
    """Optional local Qwen3-TTS adapter; model weights/dependencies are installed separately."""
    def __init__(self, model_id: str | None = None):
        self.model_id = model_id or os.environ.get("STAR_PET_QWEN3_TTS_MODEL", "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice")

    def synthesize(self, text: str, output_path: str | Path, *, voice: str = "Vivian",
                   language: str = "Chinese", style: str = "", speed: float = 1.0) -> Path:
        text = str(text).strip()
        if not text or len(text) > 8000: raise ValueError("文本不能为空且不能超过 8000 字符")
        try:
            import numpy as np
            import soundfile as sf
            from qwen_tts import Qwen3TTSModel
        except ImportError as exc:
            raise ValueError("Qwen3-TTS 依赖未安装。请参考 VOICE_MODELS_GUIDE.md 创建独立环境并安装 qwen-tts、soundfile") from exc
        model = _QWEN_MODELS.get(self.model_id)
        if model is None:
            model = Qwen3TTSModel.from_pretrained(self.model_id)
            _QWEN_MODELS[self.model_id] = model
        lang_map = {"zh-CN":"Chinese", "en-US":"English", "ja-JP":"Japanese", "Chinese":"Chinese", "English":"English", "Japanese":"Japanese"}
        wavs, sr = model.generate_custom_voice(text=text, language=lang_map.get(language, language), speaker=voice or "Vivian", instruct=style or None)
        target = Path(output_path).with_suffix(".wav"); target.parent.mkdir(parents=True, exist_ok=True)
        sf.write(str(target), np.asarray(wavs[0]), int(sr))
        return target


_INDEX_MODELS = {}

class IndexTTSAdapter:
    """Optional local IndexTTS adapter. Requires model weights and a reference voice WAV."""
    def __init__(self, model_dir: str | None = None, config_path: str | None = None, reference_wav: str | None = None):
        self.model_dir = model_dir or os.environ.get("STAR_PET_INDEXTTS_MODEL_DIR", "")
        self.config_path = config_path or os.environ.get("STAR_PET_INDEXTTS_CONFIG", "")
        self.reference_wav = reference_wav or os.environ.get("STAR_PET_INDEXTTS_REFERENCE_WAV", "")

    def synthesize(self, text: str, output_path: str | Path, *, voice: str = "", language: str = "zh-CN", style: str = "", speed: float = 1.0) -> Path:
        text = str(text).strip()
        if not text or len(text) > 8000: raise ValueError("文本不能为空且不能超过 8000 字符")
        model_dir = Path(self.model_dir) if self.model_dir else None
        cfg = Path(self.config_path) if self.config_path else (model_dir / "config.yaml" if model_dir else None)
        ref = Path(voice or self.reference_wav) if (voice or self.reference_wav) else None
        if not model_dir or not model_dir.is_dir() or not cfg or not cfg.is_file():
            raise ValueError("IndexTTS 模型未配置。请设置 STAR_PET_INDEXTTS_MODEL_DIR 和 STAR_PET_INDEXTTS_CONFIG，详见 VOICE_MODELS_GUIDE.md")
        if not ref or not ref.is_file():
            raise ValueError("IndexTTS 需要参考音频 WAV；请设置 STAR_PET_INDEXTTS_REFERENCE_WAV 或在音色字段填写本地 WAV 路径")
        try:
            from indextts.infer_v2_5 import IndexTTS2
        except ImportError:
            try: from indextts.infer_v2 import IndexTTS2
            except ImportError as exc: raise ValueError("IndexTTS Python 环境未安装。请在 IndexTTS 官方独立环境安装后再连接") from exc
        key = str(model_dir.resolve())
        model = _INDEX_MODELS.get(key)
        if model is None:
            try: model = IndexTTS2(cfg_path=str(cfg), model_dir=str(model_dir), use_bf16=False)
            except TypeError: model = IndexTTS2(cfg_path=str(cfg), model_dir=str(model_dir), use_fp16=False, use_cuda_kernel=False, use_deepspeed=False)
            _INDEX_MODELS[key] = model
        target = Path(output_path).with_suffix(".wav"); target.parent.mkdir(parents=True, exist_ok=True)
        kwargs = {"spk_audio_prompt": str(ref), "text": text, "output_path": str(target)}
        if "2.5" in str(model_dir): kwargs["lang"] = {"zh-CN":"ZH", "en-US":"EN", "ja-JP":"JP"}.get(language, "ZH")
        try: model.infer(**kwargs)
        except TypeError: model.infer(str(ref), text, str(target))
        if not target.is_file() or target.stat().st_size <= 0: raise ValueError("IndexTTS 未生成有效音频文件")
        return target


class GoogleGeminiTTSAdapter:
    """Gemini API TTS adapter using a Google AI API key (not Cloud OAuth)."""
    def __init__(self, api_key_env: str = "GEMINI_API_KEY", model: str = "gemini-2.5-flash-preview-tts", timeout: int = 60):
        self.api_key_env = str(api_key_env).strip()
        self.model = str(model).strip() or "gemini-2.5-flash-preview-tts"
        self.timeout = max(5, min(int(timeout), 180))

    def synthesize(self, text: str, output_path: str | Path, *, voice: str = "Kore", language: str = "zh-CN", style: str = "Speak naturally", speed: float = 1.0) -> Path:
        import base64, wave
        text = str(text).strip()
        if not text or len(text) > 8000: raise ValueError("文本不能为空且不能超过 8000 字符")
        key = os.environ.get(self.api_key_env, "").strip()
        if not key: raise ValueError(f"请先设置环境变量 {self.api_key_env}")
        prompt = f"{style}. Speak in {language}. Speaking pace {max(.5,min(float(speed),2.0)):.1f}x. Say the following text exactly:"
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        response = requests.post(url, params={"key": key}, json={"contents":[{"parts":[{"text":prompt + "\n" + text}]}],"generationConfig":{"responseModalities":["AUDIO"],"speechConfig":{"voiceConfig":{"prebuiltVoiceConfig":{"voiceName":str(voice)[:80]}}}}}, timeout=self.timeout)
        response.raise_for_status(); body=response.json()
        try:
            part=next(p for p in body["candidates"][0]["content"]["parts"] if "inlineData" in p or "inline_data" in p)
            inline=part.get("inlineData",part.get("inline_data")); raw=base64.b64decode(inline["data"])
            mime=str(inline.get("mimeType",inline.get("mime_type","audio/pcm;rate=24000")))
        except (KeyError, StopIteration, TypeError, ValueError) as exc:
            raise ValueError("Gemini TTS 返回中没有可识别的音频数据") from exc
        target=Path(output_path); target.parent.mkdir(parents=True,exist_ok=True)
        # Gemini returns raw PCM for this model; wrap it as WAV for desktop playback.
        rate=24000
        import re
        m=re.search(r"rate=(\d+)",mime)
        if m: rate=int(m.group(1))
        with wave.open(str(target),"wb") as wav:
            wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(rate); wav.writeframes(raw)
        return target


class GoogleCloudTTSAdapter:
    """Google Cloud Text-to-Speech REST adapter using Application Default Credentials."""
    def __init__(self, api_key_env: str = "GOOGLE_CLOUD_PROJECT", model: str = "gemini-2.5-flash-tts", timeout: int = 60, location: str = "global"):
        self.project_env=str(api_key_env).strip() or "GOOGLE_CLOUD_PROJECT"
        self.model=str(model).strip() or "gemini-2.5-flash-tts"
        self.timeout=max(5,min(int(timeout),180)); self.location=str(location).strip() or "global"

    def synthesize(self, text: str, output_path: str | Path, *, voice: str = "Kore", language: str = "zh-CN", style: str = "Speak naturally", speed: float = 1.0) -> Path:
        import base64, wave, io
        try:
            import google.auth
            from google.auth.transport.requests import Request
        except ImportError as exc:
            raise ValueError("缺少 google-auth；请运行 pip install google-auth") from exc
        text=str(text).strip()
        if not text or len(text)>8000: raise ValueError("文本不能为空且不能超过 8000 字符")
        creds,_=google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
        if not creds.valid: creds.refresh(Request())
        project=os.environ.get(self.project_env, "").strip()
        host="texttospeech.googleapis.com" if self.location=="global" else f"{self.location}-texttospeech.googleapis.com"
        url=f"https://{host}/v1/text:synthesize"
        payload={"input":{"text":text,"prompt":style},"voice":{"languageCode":language,"name":voice,"model_name":self.model},"audioConfig":{"audioEncoding":"LINEAR16","speakingRate":max(.25,min(float(speed),4.0))}}
        headers={"Authorization":f"Bearer {creds.token}","Content-Type":"application/json"}
        if project: headers["x-goog-user-project"]=project
        response=requests.post(url,json=payload,headers=headers,timeout=self.timeout); response.raise_for_status()
        try: raw=base64.b64decode(response.json()["audioContent"])
        except (KeyError,ValueError,TypeError) as exc: raise ValueError("Google Cloud TTS 返回缺少 audioContent") from exc
        target=Path(output_path); target.parent.mkdir(parents=True,exist_ok=True)
        # LINEAR16 is WAV-compatible; Cloud response may already contain a WAV header.
        if raw[:4]==b"RIFF": target.write_bytes(raw)
        else:
            with wave.open(str(target),"wb") as wav: wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(24000); wav.writeframes(raw)
        return target

class IsolatedTTSAdapter:
    """HTTP bridge to a model running in its own Python environment on loopback."""
    def __init__(self, endpoint: str, timeout: int = 240):
        self.endpoint = str(endpoint).strip().rstrip("/")
        self.timeout = max(10, min(int(timeout), 900))
        if not _valid_endpoint(self.endpoint):
            raise ValueError("隔离模型服务地址必须使用 HTTPS 或本机 loopback HTTP")

    def synthesize(self, text: str, output_path: str | Path, *, voice: str = "", language: str = "zh-CN", style: str = "", speed: float = 1.0) -> Path:
        text = str(text).strip()
        if not text or len(text) > 8000:
            raise ValueError("文本不能为空且不能超过 8000 字符")
        response = requests.post(
            self.endpoint + "/synthesize",
            json={"text": text, "voice": str(voice)[:500], "language": language[:16], "style": str(style)[:200], "speed": max(0.5, min(float(speed), 2.0))},
            headers={"Content-Type": "application/json"}, timeout=self.timeout,
        )
        response.raise_for_status()
        ctype = response.headers.get("Content-Type", "").split(";", 1)[0].lower()
        if ctype not in {"audio/wav", "audio/x-wav", "audio/mpeg"} or not response.content or len(response.content) > 40_000_000:
            raise ValueError("隔离模型服务没有返回有效音频（允许 WAV/MP3，最大 40 MB）")
        suffix = ".mp3" if ctype == "audio/mpeg" else ".wav"
        target = Path(output_path).with_suffix(suffix)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(response.content)
        return target
