# StarPetFusion 音频标注工作区

## 当前自动完成
- 检查音频文件是否存在、可解码。
- 测量时长、峰值电平、平均 20 ms 帧 RMS、低能量区间比例、估计活动比例、削波采样比例。
- 输出 `audio_annotation.csv`（UTF-8 with BOM，便于 Excel 打开）和 `audio_signal_report.json`。

## 必须人工/ASR 完成
- `transcript`：逐段语音转录。
- `human_role_confirmation`：必须对照原视频确认画面角色和说话者，不可凭音色猜角色。
- `speech_rate`：应在转录后按有效词/字数和语音时长计算。
- `pause_pattern`、`emotion_expression`：建议听音并结合上下文人工复核；低能量比例只是粗略信号指标，不能直接当成停顿或情绪结论。
- `confidence`：仅在有依据时填写。

## 运行
在项目根目录执行：

```bash
python tools/analyze_audio_review.py
```

需要 `pydub` 和可用的 FFmpeg。该脚本不调用在线服务，不会自动识别人物身份，也不会训练或克隆声音。源视频未随当前复核包提供时，角色画面对照需另行补齐。

## 真实 ASR 转录（新增）

本项目新增 `tools/transcribe_audio_review.py`，通过本地 `faster-whisper` 模型执行真实语音识别。首次运行需要联网下载模型（或预先准备模型缓存）；运行后可离线批处理。建议先用 `small` 模型试跑，资源充足时可选 `medium` 或 `large-v3` 提升准确率。

```bash
# 安装 ASR 可选依赖
python -m pip install -r requirements-asr.txt

# 自动检测语言，CPU 模式（首次运行会下载模型）
python tools/transcribe_audio_review.py --model small --device cpu --compute-type int8

# 如已知主要为日语，可指定语言以减少语言识别偏差
python tools/transcribe_audio_review.py --model small --language ja

# 覆盖已有转录结果
python tools/transcribe_audio_review.py --overwrite
```

输出：
- `audio_annotation.csv`：填入 ASR 文本、语言、模型状态和粗略字符速率。
- `asr_segments.json`：保存每段识别文本的起止时间及词级时间戳（模型支持时）。

脚本逐条保存进度，意外中断后可再次运行；已填入 transcript 的行默认跳过，`--overwrite` 可重新识别。识别结果仍需人工校对，尤其是专有名词、日语/中文混说、背景音乐和短语音。`faster-whisper` 不做可靠的说话者分离，因此 `speaker_count`、画面角色身份、情绪仍需人工确认；不得仅凭 ASR 结果推断角色或配音演员身份。

注意：本次构建集成了真实 ASR 执行流程，但当前构建环境未安装 `faster-whisper` 模型且无法在此处实际下载运行，因此没有伪造任何转录文本。要得到真实转录，请在可安装依赖并下载模型的电脑上执行上述命令。
