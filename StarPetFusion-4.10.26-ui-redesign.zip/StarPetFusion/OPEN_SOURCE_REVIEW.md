# StarPetFusion 开源项目调研与设计取舍

本文件记录对公开项目的功能调研，以及本项目借鉴的设计方向。这里的“借鉴”指功能分析与独立实现，不表示复制或合并了其他项目的源代码、角色图片或模型权重。

## 调研样本

| 项目 | 可参考的方向 | StarPetFusion 的处理方式 |
|---|---|---|
| [DyberPet](https://github.com/ChaozhongLiu/DyberPet) | 角色模组、动画交互、桌宠与助手分层 | 保留外观切换与模块化方向；没有复制其 GPL 项目代码或素材 |
| [Desktop Cat Companion](https://github.com/d011ar/Desktop-Cat-Companion) | PySide6 透明桌宠、后台模型请求、本地记忆和任务面板 | 沿用后台线程避免 UI 阻塞的思路；当前项目已有 SQLite 本地聊天记录 |
| [DeepSeek Desktop Pet](https://github.com/sjmsltx/deepseek-desktop-pet) | 角色提示词、模型档案、连接自检、主题系统 | 增加服务商预设、连接测试和按角色补充提示词；未复制其代码或图像 |
| [DeskMate](https://github.com/AayushAade/DeskMate) | 本地 Ollama、行为模块、助手能力拆分 | 增加本地 OpenAI 兼容接口配置，不要求本地模型填写云端 API Key |
| [NekoAI](https://nekoai.dev/) | 本地优先、多模型后端和轻量桌面伴侣 | 采用“桌宠基础交互不依赖云端 AI”的设计原则 |
| [Ollama API 文档](https://github.com/ollama/ollama/blob/main/docs/api/introduction.mdx) | 本地服务器与 OpenAI 兼容接口 | 支持 `http://localhost:11434/v1` 与 `/chat/completions` |
| [IRIS](https://github.com/vincenzo-afk/IRIS) | 语音交互、桌面任务与权限风险提示 | 仅参考模块边界和风险提示；该仓库未见明确许可证时不直接复用代码 |
| [NOVA](https://github.com/vincenzo-afk/NOVA) | 任务调度、文档检索、工具编排 | 参考功能分层；不直接复制其实现 |
| [Monaw](https://github.com/kailiang0120/monaw) | 本地文件工作流、应用自动化、工具集成 | 参考工作流；如需复用代码先逐项核对许可证与依赖 |
| [JARVIS](https://github.com/Akash-R-tech/JARVIS) | 本地待办、便签、应用启动 | 参考常见桌面助手场景，独立实现本地待办与便签 |

## 当前已实现的升级

- 深紫色主题：统一输入框、按钮、菜单、对话记录与设置窗口的视觉风格。
- AI 设置窗口：DeepSeek、Ollama 本地、OpenAI、自定义兼容接口四种预设；支持隐藏/显示密钥与测试连接。
- 本地模型：Ollama 本地接口允许空 API Key；模型名需与用户本机 `ollama list` 中的名称一致。
- 角色个性：每个角色可保存独立的补充提示词；识别大黑塔角色时追加温和的风格约束，减少普通客服腔并避免编造官方设定。
- 更明确的 API 错误提示：对 401、402、404、429 提供针对性检查建议。
- 自动化测试：覆盖本地 Ollama 不带密钥请求、角色提示词补充和已有核心逻辑。
- 2.7 日常工作台：增加本地待办、便签和用户选定目录内的只读文件名搜索；打开文件前二次确认，并阻止直接打开常见可执行文件/脚本。

## 图片与许可证

`python prepare.py` 会从 StarPetFusion 配置的三个上游仓库下载角色资料和图像素材到 `vendor/`，桌宠菜单会扫描其中可作为独立立绘的图片。出于上游许可证、角色素材授权和包体积考虑，发行压缩包不直接内嵌所有上游图像。使用或再分发 `vendor/` 中的文件前，应阅读各来源仓库的许可证、署名要求与素材条款；`prepare.py` 的下载不代表取得额外版权许可。

## 后续可扩展项

- 流式输出与取消生成。
- Ollama 本地模型列表自动发现。
- 插件 API 与更完善的提醒/日历联动。
- 角色包导入导出、动画帧集与 Live2D 渲染。
- API 用量显示、可选长期记忆摘要与可审计的工具权限。

上述未列入“已实现”的功能均属于后续规划，不应视为当前版本已有能力。


## 角色卡结构与上下文蒸馏（3.1）

- 参考 [SillyTavern 角色设计文档](https://docs.sillytavern.app/usage/characters/) 中将角色描述、性格摘要、场景、开场消息与示例对话分开组织的做法。
- 参考 [SillyTavern 角色设计指南](https://github.com/SillyTavern/SillyTavern-Docs/blob/main/Usage/Characters/characterdesign.md) 关于固定角色信息与可选示例上下文的区分。
- 本项目没有复制其代码或角色卡内容；只采用字段分层和上下文预算的设计思路，自行实现 `persona_distiller.py`。当前实现属于提示词压缩与按话题选择资料，不是训练模型权重的知识蒸馏。
