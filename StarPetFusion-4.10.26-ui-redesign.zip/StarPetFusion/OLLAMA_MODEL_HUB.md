# Ollama 模型统一管理与 HTTP 调用

StarPetFusion 4.10.19 将 Ollama 作为本地大语言模型的统一模型仓库和调用入口。聊天请求继续使用 Ollama 提供的 OpenAI-compatible HTTP API（`/v1/chat/completions`），模型管理使用 Ollama 原生 HTTP API。

## 设置

1. 安装并启动 Ollama，默认服务地址为 `http://127.0.0.1:11434`。
2. 打开桌宠右键菜单中的「AI 设置」，选择「Ollama 本地模型」。
3. 点击「刷新模型」读取已安装模型；选中后点击「使用所选模型」。
4. 如需新模型，在输入框填写 Ollama 模型标签（例如 `qwen2.5:3b`），点击「下载模型」。模型下载在后台线程运行，可查看状态。
5. 「删除所选」会从本机 Ollama 删除模型并释放磁盘空间，执行前会二次确认。
6. 点击「测试连接」，成功后保存设置。

## HTTP 接口

- `GET /api/tags`：列出本地模型。
- `POST /api/show`：模型信息查询（供后续扩展）。
- `POST /api/pull`：下载模型，按 NDJSON 流读取进度。
- `DELETE /api/delete`：删除模型。
- `POST /v1/chat/completions`：聊天推理，所有已安装且被 Ollama 支持的模型均通过模型标签调用。

模型管理默认只接受 loopback HTTP 地址，避免误把模型管理操作发送到局域网或公网服务器。聊天设置仍支持原有云端服务商和自定义 HTTPS/OpenAI-compatible 服务，不会强制切换用户原有设置。

## 语音模型边界

Ollama 管理的是其支持的 LLM/多模态模型，不是通用 TTS 运行时。StarPetFusion 的语音输出仍通过统一语音适配器的 HTTP/本地接口接入（Edge TTS、Qwen3-TTS sidecar、IndexTTS sidecar、Gemini/Google Cloud TTS 或兼容 HTTP 服务）；每个角色的音色配置独立保存，不把 TTS 模型错误地显示成 Ollama 聊天模型。若后续 TTS 服务自身提供 HTTP API，可按同一适配器模式接入。

## 隐私与资源

本地 Ollama 请求发往本机服务；选择云端提供商时，聊天内容会发往该服务商。模型下载会占用网络流量和磁盘空间；删除模型前请确认它不是当前唯一可用模型。
