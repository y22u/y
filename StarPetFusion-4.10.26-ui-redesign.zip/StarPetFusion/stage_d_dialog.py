from __future__ import annotations
import json
from pathlib import Path
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QMessageBox, QCheckBox, QTextEdit)
from data_portability import create_diagnostic_report, export_backup, inspect_backup, import_backup

class StageDDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle("阶段 D：数据迁移与诊断"); self.resize(720, 520)
        root = QVBoxLayout(self)
        root.addWidget(QLabel("导出本地配置、角色记忆数据库与集成设置；默认会清除备份中的密钥/token 字段。导入前会校验清单和文件哈希，并为现有文件创建回滚快照。"))
        self.report = QTextEdit(); self.report.setReadOnly(True); root.addWidget(self.report, 1)
        self.include_secrets = QCheckBox("导出密钥字段（不推荐；备份包可能包含 API Key/令牌）")
        root.addWidget(self.include_secrets)
        row = QHBoxLayout()
        for label, callback in [("刷新诊断", self.refresh_report), ("导出数据备份…", self.export_data), ("校验备份包…", self.inspect_data), ("导入/恢复备份…", self.import_data)]:
            b = QPushButton(label); b.clicked.connect(callback); row.addWidget(b)
        close = QPushButton("关闭"); close.clicked.connect(self.accept); row.addWidget(close); root.addLayout(row)
        self.refresh_report()
    def refresh_report(self):
        self.report.setPlainText(json.dumps(create_diagnostic_report(), ensure_ascii=False, indent=2))
    def export_data(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出 StarPetFusion 数据备份", "StarPetFusion-backup.zip", "ZIP 备份 (*.zip)")
        if not path: return
        include = self.include_secrets.isChecked()
        if include and QMessageBox.warning(self, "包含敏感信息", "备份包将包含配置中的密钥字段。请妥善保管，不要发送给他人。继续？", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes: return
        try:
            result = export_backup(path, include_sensitive=include)
            QMessageBox.information(self, "导出完成", f"已导出 {result['files']} 个数据文件。\n密钥字段已脱敏：{result['redacted_secrets']}\n{result['path']}")
        except Exception as exc: QMessageBox.warning(self, "导出失败", str(exc))
    def _choose(self):
        path, _ = QFileDialog.getOpenFileName(self, "选择 StarPetFusion 备份", "", "ZIP 备份 (*.zip)")
        return path
    def inspect_data(self):
        path = self._choose()
        if not path: return
        try: QMessageBox.information(self, "备份校验结果", json.dumps(inspect_backup(path), ensure_ascii=False, indent=2))
        except Exception as exc: QMessageBox.warning(self, "备份无效", str(exc))
    def import_data(self):
        path = self._choose()
        if not path: return
        try: info = inspect_backup(path)
        except Exception as exc: QMessageBox.warning(self, "备份无效", str(exc)); return
        warning = "导入将替换备份中包含的本地配置/记忆数据，现有文件会先保存到回滚快照目录。建议先关闭其他 StarPetFusion 实例。"
        if info.get("redacted_secrets"): warning += "\n此备份已脱敏，导入后需要重新配置 API Key 等密钥。"
        if QMessageBox.warning(self, "确认导入", warning + "\n继续？", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes: return
        try:
            result = import_backup(path)
            QMessageBox.information(self, "导入完成", f"已导入：{', '.join(result['imported'])}\n回滚快照：{result['rollback_snapshot']}\n建议重启应用使配置重新加载。")
            self.refresh_report()
        except Exception as exc: QMessageBox.warning(self, "导入失败", str(exc))
