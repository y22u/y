"""Discover character appearance and state-specific animation assets locally."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSET_ROOTS = (ROOT / 'character_assets', ROOT / 'frontend' / 'assets' / 'characters')
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp', '.bmp', '.gif'}
STATES = ('idle', 'happy', 'think', 'sleep')
PORTRAIT_NAMES = {'portrait', 'avatar', 'character', '立绘', '头像', '形象', '默认'}
NON_PORTRAIT_FILENAMES = {'spritesheet.webp', 'spritesheet.png', 'sprite-sheet.png', 'sprite_sheet.png', 'icon.png'}
# Common display-name/slug aliases let a role folder be found even when the upstream
# pack uses English IDs and the UI displays Chinese names.
ROLE_ALIASES = {
    '大黑塔': ('the-herta', 'the_herta', 'herta', '大黑塔'),
    'theherta': ('the-herta', 'the_herta', 'herta', '大黑塔'),
    '阿格莱雅': ('aglaea', '阿格莱雅'),
    'aglaea': ('aglaea', '阿格莱雅'),
    '海瑟音': ('hysilens', 'hyacine', '海瑟音'),
    'hysilens': ('hysilens', '海瑟音'),
    'hyacine': ('hyacine', '海瑟音'),
}

def _slug_key(value: str) -> str:
    return ''.join(ch for ch in str(value).casefold() if ch.isalnum())


def scan_assets(roots=ASSET_ROOTS) -> dict:
    """Scan role assets deterministically, preferring explicitly named portraits.

    Filesystem traversal order is not stable across platforms. Keep all discovered
    animations, but choose one predictable portrait per role so generated manifests
    do not silently change between runs when a folder contains multiple images.
    """
    roles = {}
    portrait_candidates = {}
    preferred_names = {_slug_key(name) for name in PORTRAIT_NAMES}
    files = []
    for root in roots:
        if not root.is_dir():
            continue
        files.extend(path for path in root.rglob('*') if path.is_file())
    for path in sorted(files, key=lambda item: str(item).casefold()):
        if path.suffix.lower() not in IMAGE_EXTENSIONS:
            continue
        if path.name.casefold() in NON_PORTRAIT_FILENAMES:
            continue
        # Expected layout: root/<role-slug>/<state>.<ext>; unknown files are portraits.
        slug = path.parent.name
        stem = path.stem.casefold().replace('-', '_')
        state = stem if stem in STATES else 'portrait'
        item = roles.setdefault(slug, {'portrait': None, 'animations': {}})
        if state == 'portrait':
            # Explicit portrait/avatar names win; otherwise pick the lexically first
            # candidate. PNG/WEBP are preferred when equally named.
            priority = (0 if _slug_key(path.stem) in preferred_names else 1,
                        0 if path.suffix.lower() in {'.png', '.webp'} else 1,
                        str(path).casefold())
            portrait_candidates.setdefault(slug, []).append((priority, path))
        else:
            item['animations'][state] = str(path.resolve())
    for slug, candidates in portrait_candidates.items():
        candidates.sort(key=lambda row: row[0])
        roles[slug]['portrait'] = str(candidates[0][1].resolve())
    return roles


def find_role_portrait(slug: str, roots=ASSET_ROOTS) -> str | None:
    """Find a portrait by role slug, accepting common folder/filename aliases."""
    wanted = _slug_key(slug)
    if not wanted:
        return None
    aliases = {_slug_key(item) for item in ROLE_ALIASES.get(str(slug).casefold(), ())}
    aliases.add(wanted)
    # Normalize display-name variants independent of case/punctuation.
    for alias_key, values in ROLE_ALIASES.items():
        if _slug_key(alias_key) == wanted:
            aliases.update(_slug_key(item) for item in values)
    candidates = []
    for root in roots:
        if not root.is_dir():
            continue
        for path in root.rglob('*'):
            if not path.is_file() or path.suffix.lower() not in IMAGE_EXTENSIONS:
                continue
            if path.name.casefold() in NON_PORTRAIT_FILENAMES:
                continue
            if path.stem.casefold().replace('-', '_') in STATES:
                continue
            parent_key = _slug_key(path.parent.name)
            stem_key = _slug_key(path.stem)
            # Preferred layout: root/<role-slug>/portrait.png. Also accept a flat
            # <role-slug>_portrait.png file for users who organize assets manually.
            if parent_key in aliases:
                priority = 0 if stem_key in {_slug_key(n) for n in PORTRAIT_NAMES} else 1
                candidates.append((priority, path.suffix.lower() not in {'.png', '.webp'}, str(path).casefold(), path))
            elif any(stem_key.startswith(alias) for alias in aliases) and any(stem_key.endswith(_slug_key(n)) for n in PORTRAIT_NAMES):
                candidates.append((2, path.suffix.lower() not in {'.png', '.webp'}, str(path).casefold(), path))
    if not candidates:
        return None
    candidates.sort(key=lambda row: row[:3])
    return str(candidates[0][3].resolve())

def update_config_mapping(config, roots=ASSET_ROOTS) -> dict:
    """Return role_animation_assets mapping without overwriting user-defined valid paths."""
    discovered = scan_assets(roots)
    existing = config.get('role_animation_assets', {})
    merged = dict(existing) if isinstance(existing, dict) else {}
    for slug, data in discovered.items():
        role_map = dict(merged.get(slug, {})) if isinstance(merged.get(slug, {}), dict) else {}
        for state, path in data['animations'].items():
            old = role_map.get(state)
            if not old or not Path(str(old)).is_file():
                role_map[state] = path
        if role_map:
            merged[slug] = role_map
    return merged


def write_manifest(path: Path | None = None, roots=ASSET_ROOTS) -> Path:
    target = path or (ROOT / 'character_assets' / 'CHARACTER_ASSET_MANIFEST.json')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps({'version': 1, 'states': list(STATES), 'roles': scan_assets(roots),
        'layout': 'character_assets/<role-slug>/{portrait.png,idle.png,happy.png,think.png,sleep.png}',
        'note': 'Missing state assets use procedural mood fallback; no image is invented.'}, ensure_ascii=False, indent=2), encoding='utf-8')
    return target


def main() -> int:
    target = write_manifest()
    print(f"角色素材清单已生成：{target}")
    print("目录结构：character_assets/<role-slug>/{portrait,idle,happy,think,sleep}.png")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
