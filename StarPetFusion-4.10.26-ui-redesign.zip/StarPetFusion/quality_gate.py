#!/usr/bin/env python3
"""Repeatable local release quality gate for StarPetFusion.

Runs offline checks only. It does not call external AI/TTS services or modify user data.
"""
from __future__ import annotations
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STEPS = [
    ("python_compile", [sys.executable, "-m", "compileall", "-q", "."]),
    ("unit_tests", [sys.executable, "-W", "error::ResourceWarning", "-m", "unittest", "discover", "-s", "tests", "-q"]),
    ("service_health", [sys.executable, "service_health.py"]),
    ("persona_prompt_generation", [sys.executable, "tools/generate_role_prompts.py", "--check"]),
]

def main() -> int:
    results = []
    for name, command in STEPS:
        try:
            proc = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, timeout=180)
            results.append({"name": name, "status": "PASS" if proc.returncode == 0 else "FAIL",
                            "returncode": proc.returncode,
                            "stdout_tail": proc.stdout[-1200:], "stderr_tail": proc.stderr[-1200:]})
        except subprocess.TimeoutExpired:
            results.append({"name": name, "status": "FAIL", "detail": "timed out after 180 seconds"})
        except OSError as exc:
            results.append({"name": name, "status": "FAIL", "detail": type(exc).__name__})
    report = {"project": "StarPetFusion", "gate": "local-release-quality", "checks": results,
              "passed": sum(x["status"] == "PASS" for x in results), "total": len(results)}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["passed"] == report["total"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
