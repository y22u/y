from __future__ import annotations
"""Permissioned local tool gateway for StarPetFusion Agent.

Tools are explicitly allow-listed. File operations are restricted to user-approved
roots; writes are staged and require a one-time confirmation token. No shell/code execution.
"""
import json
import os
import secrets
import difflib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

MAX_READ_BYTES = 256_000
MAX_SEARCH_RESULTS = 100
MAX_SEARCH_FILES_SCANNED = 10_000
MAX_WRITE_BYTES = 200_000
TEXT_SUFFIXES = {'.txt', '.md', '.json', '.csv', '.log', '.py', '.yaml', '.yml', '.ini', '.toml'}

@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    parameters: dict[str, Any]
    requires_confirmation: bool = False

class AgentToolGateway:
    """A small local tool registry with user-root sandboxing and confirmed writes."""
    def __init__(self, roots: list[str | Path] | None = None):
        self.roots = [Path(p).expanduser().resolve() for p in (roots or []) if str(p).strip()]
        self._pending: dict[str, tuple[str, dict[str, Any]]] = {}
        self._specs = {
            'list_files': ToolSpec('list_files', '列出已授权目录中的文件和子目录', {'type':'object','properties':{'root_index':{'type':'integer'},'relative_path':{'type':'string'}},'required':['root_index']}),
            'search_files': ToolSpec('search_files', '在已授权目录的文本文件中搜索关键词', {'type':'object','properties':{'root_index':{'type':'integer'},'query':{'type':'string'},'relative_path':{'type':'string'},'limit':{'type':'integer'}},'required':['root_index','query']}),
            'read_text_file': ToolSpec('read_text_file', '读取已授权目录中的文本文件（有大小限制）', {'type':'object','properties':{'root_index':{'type':'integer'},'relative_path':{'type':'string'}},'required':['root_index','relative_path']}),
            'stage_text_file': ToolSpec('stage_text_file', '准备在已授权目录中新建或覆盖文本文件；必须由用户确认后才能写入', {'type':'object','properties':{'root_index':{'type':'integer'},'relative_path':{'type':'string'},'content':{'type':'string'}},'required':['root_index','relative_path','content']}, True),
        }

    def schemas(self) -> list[dict[str, Any]]:
        return [{'type':'function','function':{'name':s.name,'description':s.description,'parameters':s.parameters}} for s in self._specs.values()]

    def list_roots(self) -> list[dict[str, str]]:
        return [{'index':i,'path':str(p)} for i,p in enumerate(self.roots)]

    def _root(self, index: Any) -> Path:
        if not isinstance(index, int) or isinstance(index, bool) or index < 0 or index >= len(self.roots):
            raise ValueError('目录索引无效；请先由用户明确授权一个目录。')
        root = self.roots[index]
        if not root.exists() or not root.is_dir():
            raise ValueError('授权目录不存在或不是目录。')
        return root

    def _path(self, root: Path, relative: Any) -> Path:
        rel = str(relative or '.')
        if len(rel) > 1000 or '\x00' in rel:
            raise ValueError('路径无效。')
        candidate = (root / rel).resolve()
        try: candidate.relative_to(root)
        except ValueError as exc: raise ValueError('路径超出授权目录范围。') from exc
        return candidate

    def execute(self, name: str, arguments: dict[str, Any] | str) -> dict[str, Any]:
        if name not in self._specs:
            return {'ok':False,'error':'工具未注册或未获允许。'}
        try:
            args = json.loads(arguments) if isinstance(arguments, str) else arguments
            if not isinstance(args, dict): raise ValueError('参数必须是 JSON 对象。')
            if name == 'list_files': return self._list(args)
            if name == 'search_files': return self._search(args)
            if name == 'read_text_file': return self._read(args)
            if name == 'stage_text_file': return self._stage(args)
            return {'ok':False,'error':'工具未实现。'}
        except (ValueError, OSError, UnicodeError, json.JSONDecodeError) as exc:
            return {'ok':False,'error':str(exc)[:500]}

    def _list(self, a: dict[str, Any]) -> dict[str, Any]:
        root = self._root(a.get('root_index')); folder = self._path(root, a.get('relative_path', '.'))
        if not folder.is_dir(): raise ValueError('目标不是目录。')
        items=[]
        for p in sorted(folder.iterdir(), key=lambda x:x.name.casefold())[:200]:
            items.append({'name':p.name,'type':'directory' if p.is_dir() else 'file','size':p.stat().st_size if p.is_file() else None})
        return {'ok':True,'root':str(root),'path':str(folder.relative_to(root)),'items':items}

    def _search(self, a: dict[str, Any]) -> dict[str, Any]:
        root = self._root(a.get('root_index')); query = str(a.get('query','')).strip()
        if not query or len(query)>300: raise ValueError('搜索词不能为空且不能超过 300 字符。')
        base = self._path(root, a.get('relative_path','.'))
        if not base.is_dir(): raise ValueError('搜索路径不是目录。')
        limit = max(1,min(int(a.get('limit',30)),MAX_SEARCH_RESULTS)); found=[]
        scanned = 0
        for p in base.rglob('*'):
            scanned += 1
            if len(found)>=limit or scanned > MAX_SEARCH_FILES_SCANNED: break
            if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES: continue
            try:
                if p.stat().st_size>MAX_READ_BYTES: continue
                lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
            except OSError: continue
            for n,line in enumerate(lines,1):
                if query.casefold() in line.casefold():
                    found.append({'path':str(p.relative_to(root)),'line':n,'text':line[:500]})
                    if len(found)>=limit: break
        return {'ok':True,'query':query,'results':found,'truncated':len(found)>=limit or scanned > MAX_SEARCH_FILES_SCANNED,'files_scanned':min(scanned,MAX_SEARCH_FILES_SCANNED)}

    def _read(self, a: dict[str, Any]) -> dict[str, Any]:
        root=self._root(a.get('root_index')); p=self._path(root,a.get('relative_path'))
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES: raise ValueError('仅允许读取常见文本文件。')
        if p.stat().st_size>MAX_READ_BYTES: raise ValueError('文件超过 256 KB 限制。')
        return {'ok':True,'path':str(p.relative_to(root)),'content':p.read_text(encoding='utf-8',errors='replace')}

    def _stage(self, a: dict[str, Any]) -> dict[str, Any]:
        root=self._root(a.get('root_index')); p=self._path(root,a.get('relative_path'))
        content=a.get('content')
        if not isinstance(content,str) or len(content.encode('utf-8'))>MAX_WRITE_BYTES: raise ValueError('内容必须是文本且 UTF-8 编码后不超过 200 KB。')
        if p.suffix.lower() not in TEXT_SUFFIXES: raise ValueError('只允许创建或修改常见文本文件。')
        token=secrets.token_urlsafe(18)
        self._pending[token]=(str(p),{'content':content,'root':str(root)})
        old_preview = ''
        diff_preview = ''
        if p.is_file() and p.stat().st_size <= MAX_READ_BYTES and p.suffix.lower() in TEXT_SUFFIXES:
            try:
                old_preview = p.read_text(encoding='utf-8', errors='replace')[:1000]
                diff_preview = ''.join(list(difflib.unified_diff(old_preview.splitlines(True), content[:5000].splitlines(True), fromfile='当前文件（预览）', tofile='拟写入内容（预览）'))[:80])[:6000]
            except OSError:
                old_preview = '[无法读取现有文件预览]'
        return {'ok':True,'requires_confirmation':True,'confirmation_token':token,'target':str(p),'bytes':len(content.encode('utf-8')),'preview':content[:1000],'preview_truncated':len(content)>1000,'exists':p.exists(),'existing_preview':old_preview,'diff_preview':diff_preview,'message':'文件尚未写入；请检查目标路径、现有内容和差异后明确确认。'}

    def confirm_write(self, token: str, approved: bool) -> dict[str, Any]:
        item=self._pending.pop(str(token),None)
        if item is None: return {'ok':False,'error':'确认令牌无效、过期或已使用。'}
        if not approved: return {'ok':False,'cancelled':True,'message':'用户取消了文件写入。'}
        raw, payload=item; root=Path(payload['root']).resolve(); target=Path(raw).resolve()
        try: target.relative_to(root)
        except ValueError: return {'ok':False,'error':'目标路径已超出授权目录。'}
        if target.exists() and target.is_dir(): return {'ok':False,'error':'目标是目录，不能写入。'}
        target.parent.mkdir(parents=True,exist_ok=True)
        backup_info = {'created': False, 'reason': 'new_file'}
        if target.exists():
            from data_safety import create_backup
            backup_info = create_backup(target)
        temp=target.with_name(target.name+'.starpet.tmp')
        try:
            temp.write_text(payload['content'],encoding='utf-8')
            os.replace(temp,target)
        finally:
            try: temp.unlink(missing_ok=True)
            except OSError: pass
        return {'ok':True,'path':str(target),'bytes':target.stat().st_size,'backup':backup_info}
