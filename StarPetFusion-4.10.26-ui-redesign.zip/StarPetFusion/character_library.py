"""Local SQLite library for character profiles and user-authorized appearance assets."""
from __future__ import annotations
import json, shutil, sqlite3
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / 'character_assets' / 'character_library.db'
IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp'}

def connect(db_path=DB_PATH):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.executescript('''
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS characters (
      slug TEXT PRIMARY KEY, name TEXT NOT NULL, profile_json TEXT NOT NULL,
      profile_markdown TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS assets (
      id INTEGER PRIMARY KEY AUTOINCREMENT, character_slug TEXT NOT NULL,
      kind TEXT NOT NULL DEFAULT 'portrait', local_path TEXT NOT NULL,
      source_url TEXT NOT NULL DEFAULT '', source_platform TEXT NOT NULL DEFAULT 'local import',
      license_name TEXT NOT NULL DEFAULT 'user-confirmed', attribution TEXT NOT NULL DEFAULT '',
      redistribution_allowed INTEGER NOT NULL DEFAULT 0, sha256 TEXT NOT NULL DEFAULT '',
      added_at TEXT NOT NULL, FOREIGN KEY(character_slug) REFERENCES characters(slug) ON DELETE CASCADE,
      UNIQUE(character_slug, kind, local_path)
    );
    CREATE TABLE IF NOT EXISTS library_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    ''')
    return conn

def import_profiles(root=ROOT, db_path=DB_PATH):
    root = Path(root); conn = connect(db_path); count = 0
    try:
        for manifest_path in sorted((root / 'bundled_roles').glob('*/manifest.json')):
            try: data = json.loads(manifest_path.read_text(encoding='utf-8'))
            except Exception: continue
            slug = str(data.get('slug') or manifest_path.parent.name)
            name = str(data.get('name') or slug)
            md_path = manifest_path.parent / 'prompt_profile.md'
            if not md_path.exists(): md_path = manifest_path.parent / 'SKILL.md'
            markdown = md_path.read_text(encoding='utf-8') if md_path.exists() else ''
            now = datetime.now(timezone.utc).isoformat()
            conn.execute('''INSERT INTO characters(slug,name,profile_json,profile_markdown,updated_at)
              VALUES(?,?,?,?,?) ON CONFLICT(slug) DO UPDATE SET name=excluded.name,
              profile_json=excluded.profile_json,profile_markdown=excluded.profile_markdown,updated_at=excluded.updated_at''',
              (slug, name, json.dumps(data, ensure_ascii=False), markdown, now))
            count += 1
        conn.execute("INSERT INTO library_meta(key,value) VALUES('schema_version','1') ON CONFLICT(key) DO UPDATE SET value=excluded.value")
        conn.execute("INSERT INTO library_meta(key,value) VALUES('purpose','Local character settings and appearance asset registry') ON CONFLICT(key) DO UPDATE SET value=excluded.value")
        conn.commit()
        return count
    finally: conn.close()

def list_characters(db_path=DB_PATH):
    conn = connect(db_path)
    try: return [dict(row) for row in conn.execute('SELECT slug,name,updated_at FROM characters ORDER BY name COLLATE NOCASE')]
    finally: conn.close()

def register_asset(character_slug: str, image_path, kind='portrait', source_url='', source_platform='local import', license_name='user-confirmed', attribution='', redistribution_allowed=False, db_path=DB_PATH):
    """Copy a user-authorized image into the role folder and register provenance in SQLite."""
    src = Path(image_path).expanduser().resolve()
    if not src.is_file() or src.suffix.lower() not in IMAGE_EXTS:
        raise ValueError('请选择存在的 PNG/JPG/WEBP/GIF/BMP 图片文件')
    conn = connect(db_path)
    try:
        role = conn.execute('SELECT slug FROM characters WHERE slug=?', (character_slug,)).fetchone()
        if not role: raise ValueError(f'数据库中没有角色：{character_slug}')
        import hashlib
        digest = hashlib.sha256(src.read_bytes()).hexdigest()
        dest_dir = ROOT / 'character_assets' / character_slug
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / (f'{kind}{src.suffix.lower()}')
        if src != dest.resolve(): shutil.copy2(src, dest)
        now = datetime.now(timezone.utc).isoformat()
        conn.execute('''INSERT INTO assets(character_slug,kind,local_path,source_url,source_platform,license_name,attribution,redistribution_allowed,sha256,added_at)
          VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(character_slug,kind,local_path) DO UPDATE SET source_url=excluded.source_url,
          source_platform=excluded.source_platform,license_name=excluded.license_name,attribution=excluded.attribution,
          redistribution_allowed=excluded.redistribution_allowed,sha256=excluded.sha256,added_at=excluded.added_at''',
          (character_slug,kind,str(dest.relative_to(ROOT)),source_url,source_platform,license_name,attribution,int(bool(redistribution_allowed)),digest,now))
        conn.commit(); return dest
    finally: conn.close()

if __name__ == '__main__':
    print(f'已导入角色资料：{import_profiles()} 个')
    print(f'数据库：{DB_PATH}')
