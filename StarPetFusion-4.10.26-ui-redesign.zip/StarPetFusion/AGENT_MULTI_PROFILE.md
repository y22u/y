# 多 Agent 配置与使用（4.5）

StarPetFusion 支持在聊天页面切换：

- **Ollama 本地模型**：运行在本机，不需要云端 API Key。
- **默认外部 Agent**：在桌宠右键菜单的“外部智能体连接”里配置一个 OpenAI 兼容接口。
- **多个 Agent 配置档**：可在 `%APPDATA%/StarPetFusion/integrations.json` 的 `agent_profiles` 中配置多个兼容接口。保存后刷新页面，聊天下拉框会显示已就绪的配置档。

示例（将占位地址、模型 ID 和环境变量名替换成服务商真实提供的信息；不要把密钥写入 JSON）：

```json
{
  "agent_profiles": {
    "deepseek_work": {
      "label": "DeepSeek 工作助手",
      "enabled": true,
      "endpoint": "https://api.deepseek.com/v1",
      "model": "替换为服务商当前支持的模型 ID",
      "api_key_env": "DEEPSEEK_API_KEY",
      "connect_timeout": 10,
      "read_timeout": 180,
      "temperature": 0.4
    },
    "my_gateway": {
      "label": "自定义 Agent 网关",
      "enabled": true,
      "endpoint": "https://替换为你的兼容网关地址/v1",
      "model": "替换为网关支持的模型或 Agent ID",
      "api_key_env": "MY_AGENT_API_KEY",
      "connect_timeout": 10,
      "read_timeout": 180,
      "temperature": 0.4
    }
  }
}
```

配置应与已有 `integrations.json` 合并，不能直接用上述片段覆盖整个文件。Windows PowerShell 中可在启动应用前设置密钥，例如 `$env:DEEPSEEK_API_KEY="你的密钥"`；不要将密钥提交到代码仓库、截图或报告中。

## 关于 Qoder、Trae、OpenCode 等桌面 Agent

产品名称不等于可调用 API。上述多配置档要求目标服务明确提供 OpenAI 兼容的 `/chat/completions` 接口（或由用户自行配置的可信兼容网关）。若某产品仅提供桌面界面、CLI 或专有协议，本版本不会假装已实现其原生连接器；需为该产品单独开发并验证对应适配器。

## 超时与隐私

- `connect_timeout` 建议 10 秒；`read_timeout` 可设 120–300 秒，最大 600 秒。
- 外部 Agent 会收到本轮聊天消息与系统提示词。仅连接可信服务，不要发送密码或敏感个人信息。
- Agent 配置档的 endpoint 必须是 HTTPS，或本机回环地址的 HTTP。项目不执行模型返回的任意 Shell/Python 代码。
