# 4.10.17：稳定角色列表

下载上游 GitHub 资源不再自动改变聊天框角色列表；上游资料与审核后的聊天角色目录分离。

# StarPetFusion 历史版本摘要

历史版本说明已合并为摘要以减少重复文档；当前版本详细变更保留在 `RELEASE_NOTES_4.10.6.md`。

## RELEASE_NOTES_2.1: StarPetFusion 2.1 功能扩展说明
- 增加 11 个离线可用的崩坏：星穹铁道女性角色风格卡：大黑塔、卡芙卡、三月七、阮·梅、流萤、黄泉、镜流、银狼、黑天鹅、符玄、托帕。
- 角色列表默认合并 `bundled_roles/` 与 `vendor/hsr-skills/`；同 slug 冲突时优先内置卡，降低上游目录变动造成的角色列表异常风险。
- 每个角色使用独立的 `manifest.json` 与 `SKILL.md`，便于扩展、审阅和自定义。

## RELEASE_NOTES_2.6: StarPetFusion 2.6 — 基本权限增强
- 新增基本权限管理窗口与标准、隐私、受限三种预设。
- 在功能入口和敏感操作中检查权限：远程聊天、天气、AI 设置、素材导入、角色提示词编辑、记录导出/删除、外部安装。
- 权限写入用户配置文件，默认维持旧版功能兼容。

## RELEASE_NOTES_2.7: StarPetFusion 2.7 — 日常工作台与受控文件访问
- 新增日常工作台：本地待办清单、便签和文件名搜索。
- 待办与便签保存在本地配置目录，不需要联网或 AI API。
- 文件查找仅遍历用户主动选择的目录，最多展示 500 个结果，不读取文件内容、不自动上传。

## RELEASE_NOTES_2.8: StarPetFusion 2.8 — 数据保护与工作台扩充
- 工作台增加“数据备份”标签页，可导出和导入待办/便签 JSON。
- 导入默认合并，不覆盖当前待办；便签会追加到现有内容之后。
- 写入工作台数据前尽量保存 `.previous.json` 安全副本。

## RELEASE_NOTES_2.9: StarPetFusion 2.9 — AI Growth & Integrations
- Added local, per-character memory with explicit add/delete controls.
- Added helpful / needs-improvement feedback buttons to chat.
- Added LLM-generated character style proposals based on recent chat and feedback; proposals require review and do not auto-edit source files.

## RELEASE_NOTES_3.0: StarPetFusion 3.0 — Agent 与人物风格架构
- 新增 `agent_runtime.py`：将角色设定、语言风格、用户授权的长期记忆与只读工具结果组合成清晰的 Agent 上下文。
- 新增 9 种表达风格：角色原设、自然日常、简洁直接、专业严谨、温柔鼓励、活泼俏皮、逻辑分析、正式书面、文学表达。风格按角色分别保存，不覆盖人物原始资料。
- 新增 Agent 辅助开关；关闭后仍可正常使用原有角色聊天。

## RELEASE_NOTES_3.1.1: StarPetFusion 3.1.1 修复说明
- 修复启动时系统托盘菜单绑定 `self.toggle_agent`，但 `AppController` 中缺少该方法导致的 `AttributeError`。
- 新增 `AppController.toggle_agent(enabled)`，通过配置存储保存 `agent_enabled` 状态，并向用户提示当前状态。
- 已对 `main.py` 执行 Python 语法编译检查。

## RELEASE_NOTES_3.1: StarPetFusion 3.1 — 人物设定扩充与提示词蒸馏
- 为 16 个内置角色补充身份、背景摘要、动机、优势、弱点、习惯、语言特征、情绪反应、关系风格、对话情境、开场和原创示例对话。
- 将黑塔与大黑塔区分为两个角色；修正风堇显示名。
- 每张卡注明为粉丝向原创扩展，不冒充官方完整设定，不复刻官方台词。

## RELEASE_NOTES_3.10: StarPetFusion 3.10 — Stage B engineering iteration
- Added `service_health.py` to validate AI endpoints, integration settings, and authorized Agent root configuration without making network calls. Run `python service_health.py` for a secret-free JSON report.
- Added tests for HTTPS/loopback endpoint policy, invalid AI settings, and native Google TTS configuration.
- Added `app_logging.py` with rotating per-user log files and redaction of common authorization/API/access-token patterns.

## RELEASE_NOTES_3.11: StarPetFusion 3.11 — Stage C
- Added pre-overwrite snapshots for confirmed Agent text-file writes.
- Added existing-file and unified-diff previews to the write confirmation flow.
- Added a data safety dialog for backup browsing, confirmed restore, and cleanup of logs older than 30 days.

## RELEASE_NOTES_3.12: StarPetFusion 3.12 — Stage D
- Added safe local data export/import for configuration and character-memory database.
- Default export redacts secret-like fields; sensitive export requires explicit opt-in and confirmation.
- Added archive format/version validation, SHA-256 integrity checks, strict path allow-listing, SQLite integrity checks, pre-import rollback snapshots, and atomic replacement.

## RELEASE_NOTES_3.13: StarPetFusion 3.13 — Stage E
- 新增 8 个内置角色资料卡：花火、飞霄、翡翠、忘归人、缇宝、遐蝶、赛飞儿、大丽花。
- 为已有内置角色补充统一的资料来源说明、复核日期和官方事实/粉丝扩展区分规则。
- 新增 `official_data/character_sources.json` 角色资料来源索引。

## RELEASE_NOTES_3.14: StarPetFusion 3.14 — Stage F
- Automatically enriched all 24 bundled role manifests with detailed prompt profiles.
- Generated a `prompt_profile.md` for every bundled role.
- Added `tools/generate_role_prompts.py` for repeatable batch prompt generation.

## RELEASE_NOTES_3.15: StarPetFusion 3.15 — Stability & Enterprise Readiness
- Added a repeatable local quality gate (`python quality_gate.py`).
- Added read-only role prompt validation (`python tools/generate_role_prompts.py --check`).
- Fixed SQLite connection lifecycle in growth memory and portability diagnostics/backup paths.

## RELEASE_NOTES_3.2: StarPetFusion 3.2 — Voice interaction & UI refinement
- Added local push-to-talk speech recognition button to the chat dialog.
- Added graceful dependency and microphone permission error messages; recognized text must be reviewed before sending.
- Refined chat dialog size, spacing, input grouping, focus states, and button hierarchy.

## RELEASE_NOTES_3.3: StarPetFusion 3.3 — Voice Pipeline & UI hierarchy
- Added `voice_pipeline.py` as a compact registry for ASR/TTS backend capabilities and normalized per-role delivery profiles.
- Voice profile normalization bounds speaking rate and volume and keeps delivery hints short and consistent across adapters.
- Local Faster-Whisper ASR now reuses a cached model between recordings and supports `language="auto"` for automatic language detection.

## RELEASE_NOTES_3.4: StarPetFusion 3.4 — Teacher/Student TTS Workflow
- `tts_adapters.py`: configurable external TTS adapter supporting OpenAI-compatible speech endpoints and generic JSON providers; API keys are environment-variable only.
- `distillation/prepare_dataset.py`: creates text/audio pairs from a user-configured teacher TTS endpoint and writes an LJSpeech-like manifest.
- `distillation/train_student.py`: validates dataset and checkpoint/config paths, then launches compatible Coqui TTS student fine-tuning.

## RELEASE_NOTES_3.6: StarPetFusion 3.6 — Agent Gateway & Orchestration
- Expanded Agent prompt policy with goal identification, concise planning, evidence-based completion claims, and uncertainty/permission boundaries.
- Added an external Agent connector for OpenAI-compatible `/chat/completions` services.
- Added a desktop UI entry: right-click pet → “外部智能体连接…”. Supports endpoint, model/Agent ID, API-key environment variable, timeout, test connection, enable/disable.

## RELEASE_NOTES_3.8: StarPetFusion 3.8 — Agent Tool Loop + Google TTS
- Added an Agent Tools dialog for explicitly granting/removing local directory roots.
- External OpenAI-compatible Agent requests can now use a bounded tool-call loop (up to six rounds) with the allow-listed local file tools.
- File write requests are staged; the UI asks the user to confirm the target path and byte count before committing. Denial cancels the write.

## RELEASE_NOTES_3.9: StarPetFusion 3.9 工程加固候选版
- 修复 Gemini API / Google Cloud TTS 原生适配器对通用 endpoint 字段的错误依赖。
- Agent 文件写入确认框展示操作类型、目标路径、UTF-8 字节数与内容预览。
- 写入大小限制改为按 UTF-8 编码字节计算，限制为 200 KB。

## RELEASE_NOTES_4.0: StarPetFusion 4.0 — 前后端分离（迭代一）
- 新增独立 FastAPI 后端与版本化 API。
- 新增独立 Web 工作台基础布局。
- 新增 Agent 对话、TTS 合成、健康检查和连接器元数据接口。

## RELEASE_NOTES_4.1: StarPetFusion 4.1 — 连接器与交互强化（迭代二）
- 重新设计工作台：总览、Agent 对话、语音与 TTS、连接器目录、安全与权限。
- 加入连接状态展示、聊天历史限制、表单输入校验与安全错误摘要。
- 分离本地 Ollama、外部 OpenAI 兼容 Agent、Google Cloud ADC、Gemini API Key 的连接说明。

## RELEASE_NOTES_4.10.1: StarPetFusion 4.10.1 — 大黑塔形象排查修复
- 修复动画 WEBP 可能被静态读取的问题：尝试通过 QMovie 播放多帧 WEBP，插件不支持时保留静态回退。
- 角色素材索引排除 sprite sheet 与图标文件，避免将整张图集误当作角色立绘。
- 新增只读工具 `diagnose_character_assets.py`，用于在用户本机定位遗留大黑塔图片/动画资源。

## RELEASE_NOTES_4.10.2: StarPetFusion 4.10.2 — 项目自检修正版
- 角色资源扫描改为稳定排序，避免同一角色目录内多个非状态图片因文件系统遍历顺序不同而随机覆盖立绘。
- 明确优先使用 `portrait`、`avatar`、`character`、`立绘`、`头像`、`形象`、`默认` 等显式命名的立绘文件。
- 补全阶段 I 的资源整合文档，说明角色知识、静态立绘和动画图集之间的区别及验收边界。

## RELEASE_NOTES_4.10.3: StarPetFusion 4.10.3 — 语音复核集成与数据恢复
- 以资料库最新可用工程包 4.10.2 为基线，保留既有 24 个角色档案、语音配置、UI、服务与测试。
- 恢复资料库中的 36 段语音复核数据包：音频样本、逐段 CSV 清单和来源校验信息。
- 新增语音复核数据校验脚本，检查清单行数、MP3 数量、缺失文件、重复引用及路径越界。

## RELEASE_NOTES_4.10.4: StarPetFusion 4.10.4 — 音频标注工作流
- 集成 36 段复核音频及原始复核清单。
- 新增 `tools/analyze_audio_review.py`，可批量校验音频并测量时长、峰值电平、短时 RMS、低能量比例、活动比例和削波比例。
- 新增 `data/audio_review/audio_annotation.csv` 与 `audio_signal_report.json`。

## RELEASE_NOTES_4.10: StarPetFusion 4.10
- Added uploaded MP4 media manifest: 36 videos with audio/video stream metadata, durations and SHA-256 hashes.
- Added voice interaction architecture refactor plan to centralize ASR, Agent handoff, TTS synthesis, playback control and profile configuration.
- Clarified privacy, source validation and non-imitative voice-style analysis limits.

## RELEASE_NOTES_4.2: StarPetFusion 4.2 — Voice model integration
- Edge TTS provider integrated into `/api/v1/tts`, no API key required; returns MP3 and is selected by default in the web TTS page.
- Qwen3-TTS local adapter using the official `qwen-tts` Python package and cached model instances.
- IndexTTS local adapter with explicit model/config/reference-WAV configuration and cached model instances.

## RELEASE_NOTES_4.3: StarPetFusion 4.3 — 隔离式语音模型部署
- Qwen3-TTS 运行在独立 `.venvs/qwen3` Python 环境，通过 loopback sidecar `127.0.0.1:8766` 提供合成。
- IndexTTS 使用其官方仓库的独立 `uv` 项目环境，通过 loopback sidecar `127.0.0.1:8767` 提供合成。
- 主网关通过 `IsolatedTTSAdapter` 传递文本/音色/语言/语速并接收音频字节，不在主环境导入两个模型的运行时依赖。

## RELEASE_NOTES_4.4.1: StarPetFusion 4.4.1 — 角色资料加载与 Agent 超时修复
- `prepare.py` 对 `hsr-skills` 同时尝试 `master`、`main` 下载源；下载成功后校验角色目录是否含 `SKILL.md`。
- 采用暂存目录下载与校验，只有新包有效才替换旧目录；失败时保留原有可用资料。
- 启动提示和“刷新角色”操作显示内置角色与上游角色数量，空目录不再被误判为资料已就绪。

## RELEASE_NOTES_4.5.0: StarPetFusion 4.5.0 — TTS 与 Agent 就绪检测
- 连接器页面增加“实际就绪检测”，调用 `/api/v1/diagnostics` 展示本机依赖/服务状态。
- 新增 `diagnose_integrations.py`，可在 Windows 本机检查 Edge TTS、Qwen3/IndexTTS sidecar、Ollama 和外部 Agent 配置。
- 新增 `AGENT_PRESETS.json`，提供 Ollama、本地 OpenAI 兼容服务、通用外部 OpenAI 兼容 Agent 的预设。

## RELEASE_NOTES_4.5: StarPetFusion 4.5 — TTS 与多 Agent 连接诊断
- 网关版本更新为 4.5.0。
- `/api/v1/connectors` 不再把本地 sidecar 的默认地址当作“已就绪”；会分别探测 Ollama、Qwen3-TTS 和 IndexTTS 的本机健康端点。
- 增加 `/api/v1/diagnostics` 汇总配置与就绪状态，不会调用付费云服务或发送测试文本。

## RELEASE_NOTES_4.7.0: StarPetFusion 4.7.0 — Stage J
- Added `hsr_knowledge.py`, a local searchable knowledge index with source paths and bounded snippets.
- Added `character_asset_registry.py` to discover character portrait and state-specific animation files while preserving valid user mappings.
- Added Stage J documentation and expanded automated tests.

## RELEASE_NOTES_4.8.0: StarPetFusion 4.8.0 — Role Appearance Reconstruction
- Fixed the missing role-to-visible-portrait binding when changing active character.
- Added role-specific portrait config and discovery.
- Added “为当前角色设置专属立绘…” to the desktop pet appearance menu.

## RELEASE_NOTES_4.8.1: StarPetFusion 4.8.1 — 角色外观与 TTS 服务入口修复
- 扩展角色立绘发现逻辑，支持大黑塔、阿格莱雅、海瑟音的中文名称与常见英文目录别名。
- 全局外观选择列表排除 `idle/happy/think/sleep` 状态图片，避免把同一角色的动画状态作为重复立绘选项。
- 将待机、开心、思考、睡觉状态入口合并到「互动动作」，移除重复的「当前角色专属动作」子菜单。

## RELEASE_NOTES_4.9.0: StarPetFusion 4.9.0 — 大肥鱼外观恢复与角色数字库
- 默认大肥鱼改为更圆润、表情更清晰的内置矢量绘制形象，不依赖网络、外部精灵文件或自定义图片。
- 新增 `character_library.py`：使用 SQLite 管理角色设定、Markdown 人设、图片索引、来源、许可、署名、再分发标记与 SHA-256。
- 首次预置数据库从 `bundled_roles` 导入 24 个角色资料；后续可运行 `python tools/build_character_library.py` 重建/更新资料。

## RELEASE_NOTES_4.9.1: StarPetFusion 4.9.1 — 角色资料来源与音色/形象描述扩展
- 导入用户上传压缩包中的 23 条视频标题与 b23.tv 链接，建立 `source_materials` SQLite 表。
- 按角色 PV、剧情 PV、动画短片、千星纪游、走近星穹、浮光映影分类。
- 14 条来源与角色 slug 建立关联；其余保留为通用官方资料来源。


## 4.10.10 — 混合语音路由
- 新增 `voice_router.py`：授权录音精确匹配、本地 Qwen3/IndexTTS sidecar、在线 Edge TTS（明确开启后）的优先级调度。
- 集成至 `voice_service.speak_text`，保留现有外部 TTS 和系统 TTS 兜底。
- 新增授权录音清单模板和授权政策说明；不打包任何未授权游戏录音。
- 在线 TTS 默认关闭，避免无提示将对话文本发送到第三方。


## 4.10.18
- 合并内置角色与上游角色资料，使用内存临时表按名称/别名/slug 去重；内置卡优先、上游资料补充。

## 4.10.20 — Unified Ollama Model Hub
- Unified frontend model deployment and role assignment under one Model Hub page.
- TTS configuration moved into the Model Hub; ASR route settings can be saved alongside agent model selection.
- Added local Ollama model list/pull/delete HTTP endpoints; pull runs asynchronously in a background thread.
- Chat supports an explicit selected Ollama model and falls back to the saved Agent assignment.
- Note: Ollama does not natively run every arbitrary TTS/ASR architecture; specialized speech models still require compatible runtimes or local HTTP sidecars.

## 4.10.22 — Ollama 多模型调度与运行态可观测性
- 参考 Ollama 官方 API、Open WebUI、Ollama Manager、LiteLLM 和多模型推理示例的职责分层思路。
- 新增 Ollama `/api/ps` 运行中模型视图与 `/api/version` 运行时版本检测，区分“已安装”与“驻留内存”。
- 删除模型前检查当前驻留状态，避免直接删除仍在运行的模型。
- 并发诊断增加等待任务与因槽位饱和而拒绝的累计计数，帮助根据实际负载调整限制。
- 保持 Ollama 管理接口仅允许本机回环地址；TTS/ASR 仍由专用适配器管理，不将非 LLM 模型误判为 Ollama 模型。


## 4.10.23 — 硬件资源感知调度建议

- 新增跨平台 RAM 可用量检测与可选 NVIDIA `nvidia-smi` 显存读取。
- 运行时诊断展示资源等级、推荐对话并发上限和建议原因。
- 资源建议不自动更改并发限制；在没有实际硬件/模型测量前避免误导性自动调度。
- 新增资源检测测试，覆盖低内存保守模式与充足内存模式。


## 4.10.24 — 角色专属音色预设完善
- 为内置角色配置独立语速、音量、表达指令和 Edge TTS / Qwen3-TTS 音色映射。
- Qwen3-TTS 采用完整的角色化表达指令；缓存键纳入表达指令和 provider voice，避免同文本跨角色错用缓存。
- 角色音色仅为通用合成声音的风格化预设，不克隆或冒充原配音演员。在线 TTS 保持显式授权开启。
- 增加角色音色配置完整性与引擎映射测试。

## 4.10.25 — 角色参考音频工作台与试听质检
- 新增角色音色状态 API，可检查授权参考音频和 IndexTTS/Qwen3-TTS sidecar 就绪状态。
- 新增 WAV 参考音频上传、PCM 格式/时长/声道/采样率检查、授权依据记录、SHA-256 校验及删除流程。
- 新增逐角色批量试听生成（每批最多 5 个角色），IndexTTS 使用已登记的参考音频，Qwen3-TTS 可用于内置说话人对照。
- 新增试听音频安全 ID 下载/播放接口，并提供时长、采样率、RMS、峰值和基础质量警告。
- 工作台加入角色参考音频管理、授权确认、角色选择、批量生成和试听控件。
- 自动化测试覆盖 WAV 质量指标、无效音频、授权门槛、manifest 哈希和删除操作。
- 说明：不附带任何角色/演员的录音或声纹；真实样本生成需要用户自行提供有授权的 WAV，并在本机启动对应 TTS sidecar。


## 4.10.26 — 本地智能体自动任务部署

- 新增 SQLite 持久化任务队列、事件日志和手动启动的后台执行器。
- 新增服务/硬件巡检、Ollama 模型盘点、角色音色生成与基础质检、质量门禁/备份/打包任务。
- 新增审批式代码变更流程：项目内文本文件白名单、路径约束、大小限制、写入前备份与原子替换。
- 新增可选 30 分钟巡检、进程中断后恢复残留任务、部分临时错误最多 3 次尝试。
- 新增 `start_service.bat` 和 `AUTONOMOUS_TASKS_4.10.26.md`。
- 不提供任意命令执行；不会自动重启外部服务、删除模型或安装依赖。
