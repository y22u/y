# StarPetFusion 阶段 A：稳定性验收

## 1. 目标环境
- Windows 10/11，使用项目要求的 Python 环境。
- 使用独立的测试用户数据目录；不要用唯一的正式角色库做破坏性测试。
- 第三方 TTS 测试会向配置的服务发送测试语句，可能消耗配额。

## 2. 自动诊断
在项目根目录运行：

```powershell
python -m pip install -r requirements.txt
python stage_a_check.py
python -m compileall -q .
python -m unittest discover -s tests -v
```

诊断会显示 Python、依赖、内置角色清单、集成配置、TTS 凭据可用性和音频播放器状态。不会打印 API 密钥或访问令牌。诊断在非 Windows 系统上的结果仅用于基础代码检查，不能替代 Windows GUI 验收。

## 3. Google TTS 实际联调
1. Gemini API：在系统环境变量中设置 `GEMINI_API_KEY`（或配置中指定的环境变量），启用 TTS，选择 `gemini_api`。
2. Google Cloud TTS：安装 `google-auth`，完成 Google Cloud 项目、API、权限和 Application Default Credentials（ADC）配置；选择 `google_cloud`。API Key 字段不用于 Cloud 鉴权。
3. 先运行离线检查，再执行 `python stage_a_check.py --live-tts`。该命令会发送一条短测试文本并验证返回的 WAV 文件，不会自动播放。
4. 在应用中开启外部 TTS，分别测试中文短句、较长文本、不同角色音色、超时、断网和凭据错误。
5. 记录实际模型 ID、区域、请求时间、结果和错误类型；不得把密钥、令牌或完整敏感请求写进报告。

## 4. Windows GUI / 音频验收
- 启动应用、关闭应用、连续启动 3 次，确认无崩溃和重复进程。
- 切换至少 3 个角色，确认角色名称、提示词、语音配置和历史记录没有串用。
- 测试本地 TTS、Gemini TTS、Google Cloud TTS；每种至少成功播放 3 次。
- 禁用外部 TTS或断网，确认应用退回本地 TTS（若本机引擎可用），且聊天流程仍可用。
- 检查临时音频文件是否被系统播放器锁定或残留；检查音频播放完成后的资源释放。
- 测试设置保存后重启，确认 provider、model、voice、language、location 与 timeout 持久化。

## 5. 数据安全验收
- 先备份 `%APPDATA%\StarPetFusion` 中的重要用户数据（尤其角色、历史和 integrations 配置）。
- 在副本中进行角色编辑、导入、导出、备份和恢复；确认旧数据不被默认覆盖。
- 将无效 JSON 配置放入测试目录，确认应用可提示/回退，不清空或重写用户角色数据。
- 验证 API Key 只通过环境变量读取，不出现在日志、截图、异常详情或打包文件中。

## 6. 通过标准
- 自动化测试全部通过，编译检查无错误。
- 所有阻断项关闭；TTS 服务实际请求与播放成功率、异常降级和数据恢复都有记录。
- Windows GUI、实际 Google API 和实际播放必须由目标 Windows 环境验收人签字；CI 或 Linux 环境的测试不能代替。
