"""Local, source-attributed search over StarPetFusion HSR character materials.

Indexes only local files. It does not scrape or redistribute full game narrative text.
Results carry source paths so the UI/Agent can distinguish facts from inference.
"""
from __future__ import annotations
import argparse, json, re
from dataclasses import dataclass, asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ROOTS = (ROOT / 'bundled_roles', ROOT / 'vendor' / 'hsr-skills', ROOT / 'official_data', ROOT / 'frontend' / 'assets' / 'characters')
TEXT_SUFFIXES = {'.md', '.txt', '.json', '.yaml', '.yml'}
MAX_FILE = 512_000

@dataclass
class Document:
    source: str
    title: str
    text: str
    character: str


def _read_doc(path: Path) -> Document | None:
    try:
        if path.stat().st_size > MAX_FILE or path.suffix.lower() not in TEXT_SUFFIXES:
            return None
        text = path.read_text(encoding='utf-8', errors='replace').strip()
    except OSError:
        return None
    if not text:
        return None
    heading = re.search(r'(?m)^#\s+(.+)$', text[:4000])
    title = heading.group(1).strip() if heading else path.stem
    # Role folder name is more useful than a filename for character attribution.
    character = path.parent.name if path.parent.name not in {'official_data', 'characters'} else path.stem
    try:
        source = str(path.relative_to(ROOT))
    except ValueError:
        source = str(path)
    return Document(source, title, text[:30_000], character)


def build_index(roots=ROOTS) -> list[Document]:
    docs, seen = [], set()
    for root in roots:
        if not root.is_dir():
            continue
        for path in sorted(root.rglob('*')):
            if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
                continue
            doc = _read_doc(path)
            if doc and doc.source not in seen:
                docs.append(doc); seen.add(doc.source)
    return docs


def _tokens(text: str) -> list[str]:
    # Preserve Chinese chunks as well as Latin words; substring matching supports Chinese queries.
    return [x.casefold() for x in re.findall(r'[\u3400-\u9fff]{1,}|[a-zA-Z0-9_+-]+', text) if x.strip()]


def search(query: str, limit: int = 8, roots=ROOTS) -> list[dict]:
    query = str(query).strip()
    if not query:
        return []
    qtokens = _tokens(query)
    docs = build_index(roots)
    results = []
    for doc in docs:
        hay = (doc.title + '\n' + doc.character + '\n' + doc.text).casefold()
        score = sum(hay.count(tok) * (3 if tok in doc.title.casefold() or tok in doc.character.casefold() else 1) for tok in qtokens)
        if query.casefold() in hay:
            score += 5
        if score <= 0:
            continue
        snippet = ''
        for line in doc.text.splitlines():
            if any(t in line.casefold() for t in qtokens):
                snippet = re.sub(r'\s+', ' ', line).strip()[:420]
                if snippet: break
        results.append({'score': score, 'character': doc.character, 'title': doc.title, 'source': doc.source, 'snippet': snippet or re.sub(r'\s+', ' ', doc.text)[:320]})
    results.sort(key=lambda x: (-x['score'], x['source']))
    return results[:max(1, min(int(limit), 20))]


def main() -> int:
    parser = argparse.ArgumentParser(description='检索 StarPetFusion 本地崩铁角色资料，结果附来源路径')
    parser.add_argument('query', nargs='+', help='查询词，例如 大黑塔 性格 或 阿格莱雅')
    parser.add_argument('--limit', type=int, default=8)
    parser.add_argument('--json', action='store_true')
    args = parser.parse_args()
    results = search(' '.join(args.query), args.limit)
    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    elif not results:
        print('没有找到匹配的本地资料。请运行 python prepare.py 更新上游资料，或检查 bundled_roles。')
    else:
        for i, item in enumerate(results, 1):
            print(f"{i}. {item['title']} [{item['character']}] 相关度={item['score']}\n   来源：{item['source']}\n   {item['snippet']}\n")
    return 0 if results else 1

if __name__ == '__main__':
    raise SystemExit(main())
