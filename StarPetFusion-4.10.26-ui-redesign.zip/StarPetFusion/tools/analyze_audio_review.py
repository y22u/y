#!/usr/bin/env python3
"""Create a review-ready audio annotation sheet with objective signal measurements.

This tool does NOT infer transcript, character identity, emotion, or clone a voice.
Human confirmation fields intentionally remain pending.
"""
from __future__ import annotations
import argparse, csv, json, math, statistics, wave
from pathlib import Path
from pydub import AudioSegment

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DIR = ROOT / 'data' / 'audio_review'


def analyze(path: Path) -> dict:
    audio = AudioSegment.from_file(path).set_channels(1).set_frame_rate(16000)
    samples = audio.get_array_of_samples()
    # Convert to normalized float without requiring numpy.
    scale = float(1 << (8 * audio.sample_width - 1))
    values = [s / scale for s in samples]
    frame_n = max(1, int(audio.frame_rate * 0.02))  # 20 ms windows
    rms_db, peaks = [], []
    for i in range(0, len(values), frame_n):
        frame = values[i:i + frame_n]
        if not frame: continue
        rms = math.sqrt(sum(x*x for x in frame) / len(frame))
        rms_db.append(20 * math.log10(max(rms, 1e-9)))
        peaks.append(max(abs(x) for x in frame))
    # Relative activity threshold plus a conservative floor. This is a rough
    # acoustic activity estimate, not a word/speech detector.
    floor_db = max(-48.0, (statistics.median(rms_db) - 24.0) if rms_db else -48.0)
    active = [v >= floor_db for v in rms_db]
    active_ratio = sum(active) / len(active) if active else 0.0
    silence_ratio = 1.0 - active_ratio
    return {
        'duration_seconds_measured': round(len(audio) / 1000, 3),
        'sample_rate_hz': audio.frame_rate,
        'channels': audio.channels,
        'peak_dbfs': round(20 * math.log10(max(max(peaks, default=0.0), 1e-9)), 2),
        'mean_frame_rms_dbfs': round(statistics.mean(rms_db), 2) if rms_db else None,
        'estimated_low_energy_ratio': round(silence_ratio, 4),
        'estimated_active_ratio': round(active_ratio, 4),
        'low_energy_threshold_dbfs': round(floor_db, 2),
        'clipping_sample_ratio': round(sum(1 for x in values if abs(x) >= 0.999) / max(1, len(values)), 6),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data-dir', type=Path, default=DEFAULT_DIR)
    args = ap.parse_args()
    data_dir = args.data_dir
    source_csv = data_dir / 'review_manifest_original.csv'
    out_csv = data_dir / 'audio_annotation.csv'
    report_json = data_dir / 'audio_signal_report.json'
    with source_csv.open('r', encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    results, out_rows = [], []
    for row in rows:
        audio_rel = row.get('audio_file', '')
        path = data_dir / audio_rel
        if not path.is_file():
            # Source manifest path can be normalized to the packaged audio folder.
            path = data_dir / 'audio_mp3_16k' / Path(audio_rel).name
        if not path.is_file():
            row['file_check'] = 'missing_audio'
            out_rows.append(row); continue
        features = analyze(path)
        entry = {'index': row.get('index'), 'audio_file': str(path.relative_to(data_dir)).replace('\\','/'), **features}
        results.append(entry)
        merged = dict(row)
        merged.update(features)
        merged['audio_file'] = entry['audio_file']
        merged['file_check'] = 'ok'
        # Never guess labels from signal statistics.
        merged['transcript'] = merged.get('transcript') or ''
        merged['language'] = merged.get('language') or '待确认'
        merged['speaker_count'] = merged.get('speaker_count') or '待确认'
        merged['human_role_confirmation'] = '待人工确认'
        merged['speech_rate'] = '待转录后计算'
        merged['pause_pattern'] = '待人工复核'
        merged['emotion_expression'] = '待人工复核'
        merged['confidence'] = ''
        merged['review_status'] = '已完成声学测量；待转录与人工复核'
        out_rows.append(merged)
    fields = []
    for row in out_rows:
        for key in row:
            if key not in fields: fields.append(key)
    with out_csv.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(out_rows)
    summary = {
        'tool': 'analyze_audio_review.py',
        'measurement_scope': 'objective signal measurements only; not ASR or speaker identity recognition',
        'manifest_rows': len(rows), 'audio_files_analyzed': len(results),
        'missing_audio_rows': len(rows) - len(results),
        'mean_duration_seconds': round(statistics.mean(x['duration_seconds_measured'] for x in results), 3) if results else None,
        'labels_left_pending': ['transcript', 'human_role_confirmation', 'speech_rate', 'pause_pattern', 'emotion_expression'],
        'audio_features': results,
    }
    report_json.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k != 'audio_features'}, ensure_ascii=False, indent=2))
    print(f'Wrote: {out_csv}\nWrote: {report_json}')

if __name__ == '__main__': main()
