"""Import user-supplied title/URL lists into the local character source library.

This importer deliberately stores links as research leads; it does not download video,
audio, thumbnails, or imply permission to redistribute them.
"""
from __future__ import annotations
import re, sqlite3, zipfile, hashlib, json, sys
from pathlib import Path
from datetime import datetime, timezone
ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / 'character_assets' / 'character_library.db'
DEFAULT_ARCHIVE = Path('/mnt/data/压缩文件.zip')
ROLE_RULES = [
 ('the-herta','大黑塔',['大黑塔']), ('hysilens','海瑟音',['海瑟音']),
 ('aglaea','阿格莱雅',['阿格莱雅']), ('jingliu','镜流',['镜流']),
 ('ruan-mei','阮·梅',['阮•梅','阮·梅','阮梅']), ('fugue','忘归人',['忘归人']),
 ('cipher','刻律德菈',['刻律德菈']), ('march-7th','三月七',['三月七']),
 ('evernight','长夜月',['长夜月']), ('kafka','卡芙卡',['卡芙卡']),
]
def classify(title):
    if '角色PV' in title: return 'character_pv'
    if '动画短片' in title: return 'animated_short'
    if '千星纪游' in title: return 'myriad_celestia'
    if '走近星穹' in title: return 'character_feature'
    if '剧情PV' in title: return 'story_pv'
    if '浮光映影' in title: return 'light_cone_feature'
    return 'official_video'
def role_for(title):
    compact=title.replace(' ','').replace('\u3000','')
    for slug,name,aliases in ROLE_RULES:
        if name.replace(' ','') in compact or any(a.replace(' ','') in compact for a in aliases): return slug,name
    return '', ''
def parse_archive(path):
    rows=[]
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            if not n.lower().endswith('.txt'): continue
            raw=z.read(n).decode('utf-8-sig',errors='replace')
            for line in raw.splitlines():
                m=re.search(r'(https?://[^\s]+)', line)
                if not m: continue
                url=m.group(1).rstrip('，,。；;')
                title=line[:m.start()].strip()
                if title: rows.append((title,url,n))
    dedup={r[1]:r for r in rows}
    return list(dedup.values())
def main(archive=DEFAULT_ARCHIVE):
    rows=parse_archive(Path(archive)); conn=sqlite3.connect(DB)
    conn.execute('''CREATE TABLE IF NOT EXISTS source_materials (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, url TEXT NOT NULL UNIQUE,
      platform TEXT NOT NULL, material_type TEXT NOT NULL, character_slug TEXT NOT NULL DEFAULT '',
      source_file TEXT NOT NULL DEFAULT '', processing_status TEXT NOT NULL DEFAULT 'link_only',
      license_status TEXT NOT NULL DEFAULT 'not_verified', notes TEXT NOT NULL DEFAULT '',
      sha256 TEXT NOT NULL DEFAULT '', added_at TEXT NOT NULL)''')
    now=datetime.now(timezone.utc).isoformat()
    for title,url,src in rows:
        slug,name=role_for(title)
        note='仅有用户提供的标题和链接；未包含视频/音频/图片二进制文件。未验证许可，不用于音频克隆或再分发。'
        conn.execute('''INSERT INTO source_materials(title,url,platform,material_type,character_slug,source_file,processing_status,license_status,notes,sha256,added_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET title=excluded.title,material_type=excluded.material_type,character_slug=excluded.character_slug,source_file=excluded.source_file,notes=excluded.notes''',
        (title,url,'bilibili_short_link',classify(title),slug,src,'link_only','not_verified',note,hashlib.sha256((title+'\n'+url).encode()).hexdigest(),now))
    conn.execute("INSERT INTO library_meta(key,value) VALUES('source_material_imported_at',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(now,))
    conn.commit()
    total=conn.execute('select count(*) from source_materials').fetchone()[0]
    linked=conn.execute("select count(*) from source_materials where character_slug != ''").fetchone()[0]
    print(f'imported={len(rows)} total={total} character_linked={linked} image_assets_added=0 audio_assets_added=0')
    conn.close()
if __name__=='__main__': main(Path(sys.argv[1]) if len(sys.argv)>1 else DEFAULT_ARCHIVE)
