from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from character_library import import_profiles, DB_PATH, list_characters
count = import_profiles(ROOT)
print(f'角色资料已写入 SQLite：{count} 个')
print(f'数据库文件：{DB_PATH}')
for item in list_characters(): print(f"- {item['name']} ({item['slug']})")
