from __future__ import annotations
"""Regenerate detailed prompt_profile.md files from structured role manifests."""
import json
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "bundled_roles"


def render(value, depth=0):
    lines = []
    if isinstance(value, dict):
        for key, child in value.items():
            title = key.replace("_", " ").strip().capitalize()
            if isinstance(child, (dict, list)):
                lines.append("  " * depth + f"- **{title}**")
                lines.extend(render(child, depth + 1))
            else:
                lines.append("  " * depth + f"- **{title}：** {child}")
    elif isinstance(value, list):
        for child in value:
            if isinstance(child, (dict, list)):
                lines.extend(render(child, depth))
            else:
                lines.append("  " * depth + f"- {child}")
    else:
        lines.append("  " * depth + f"- {value}")
    return lines


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate or validate bundled role prompt files")
    parser.add_argument("--check", action="store_true", help="validate generated files without modifying them")
    args = parser.parse_args()
    count = 0
    stale = []
    for manifest in sorted(ROOT.glob("*/manifest.json")):
        data = json.loads(manifest.read_text(encoding="utf-8"))
        profile = data.get("prompt_profile", {})
        name = data.get("name", manifest.parent.name)
        lines = [
            f"# {name}｜自动生成的详细角色提示词", "",
            "> 由 tools/generate_role_prompts.py 根据 manifest.json 自动生成；粉丝向原创互动扩展，不代表官方完整设定。", "",
            "## 1. 角色基础资料", f"- 身份：{data.get('identity', data.get('lore_summary', ''))}",
            f"- 背景：{data.get('background', '')}", f"- 性格：{data.get('personality', '')}",
            f"- 动机：{data.get('motivation', '')}", f"- 优势：{data.get('strengths', '')}",
            f"- 局限：{data.get('vulnerabilities', '')}", "", "## 2. 结构化提示词配置", *render(profile), "",
            "## 3. 运行时总指令", *[f"- {line}" for line in profile.get("prompt_template", [])], "",
            "## 4. 官方事实与原创扩展边界",
            "- 官方公开信息用于核对名称和已公开简介；剧情细节以游戏内文本为准。",
            "- 未核实的剧情、关系、时间线和能力细节不写成确定事实。",
            "- 日常互动、情绪回应与示例对话属于本项目粉丝向原创演绎，不冒充官方台词。", "",
        ]
        output = manifest.parent / "prompt_profile.md"
        expected = "\n".join(lines)
        if args.check:
            if not output.is_file() or output.read_text(encoding="utf-8") != expected:
                stale.append(str(output.relative_to(ROOT.parent)))
        else:
            output.write_text(expected, encoding="utf-8")
        count += 1
    if args.check:
        if stale:
            print("角色提示词文件缺失或过期：\n" + "\n".join(stale))
            return 1
        print(f"角色提示词校验通过：{count} 个文件")
    else:
        print(f"已自动生成 {count} 个详细角色提示词文件")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
