#!/usr/bin/env python3
"""Batch ASR for StarPetFusion audio review using faster-whisper.

Install optional dependency with: pip install -r requirements-asr.txt
First run downloads the selected model unless it is already cached.
"""
from __future__ import annotations
import argparse, csv, json, os, sys, tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CSV = ROOT / "data" / "audio_review" / "audio_annotation.csv"
DEFAULT_AUDIO_DIR = ROOT / "data" / "audio_review"
DEFAULT_SEGMENTS = ROOT / "data" / "audio_review" / "asr_segments.json"


def atomic_write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader(); writer.writerows(rows)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def run_transcription(csv_path: Path, audio_dir: Path, model_name: str = "small",
                      device: str = "cpu", compute_type: str = "int8",
                      language: str | None = None, overwrite: bool = False,
                      model: Any = None) -> dict[str, Any]:
    """Transcribe rows; `model` is injectable for tests."""
    if model is None:
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise RuntimeError("缺少 faster-whisper。请执行：pip install -r requirements-asr.txt") from exc
        model = WhisperModel(model_name, device=device, compute_type=compute_type)
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f); fields = list(reader.fieldnames or []); rows = list(reader)
    if not rows: raise RuntimeError(f"标注 CSV 没有数据：{csv_path}")
    if "transcript" not in fields: raise RuntimeError("CSV 缺少 transcript 列")
    for name in ("asr_model", "asr_status", "asr_language_probability", "asr_text_char_count"):
        if name not in fields: fields.append(name)
    segment_records = []
    completed = failed = skipped = 0
    for i, row in enumerate(rows, 1):
        audio_rel = (row.get("audio_file") or "").strip()
        audio_path = Path(audio_rel)
        if not audio_path.is_absolute(): audio_path = audio_dir / audio_path
        if not audio_path.exists():
            row["asr_status"] = "error: audio file missing"; failed += 1; continue
        if row.get("transcript", "").strip() and not overwrite:
            row["asr_status"] = row.get("asr_status") or "skipped: existing transcript"
            skipped += 1; continue
        try:
            segments, info = model.transcribe(str(audio_path), language=language,
                beam_size=5, vad_filter=True, word_timestamps=True)
            segs = []
            text_parts = []
            for seg in segments:
                text = (getattr(seg, "text", "") or "").strip()
                if text: text_parts.append(text)
                item = {"start": float(seg.start), "end": float(seg.end), "text": text}
                words = getattr(seg, "words", None)
                if words:
                    item["words"] = [{"start": float(w.start), "end": float(w.end),
                        "word": w.word, "probability": getattr(w, "probability", None)} for w in words]
                segs.append(item)
            transcript = " ".join(text_parts).strip()
            lang = getattr(info, "language", None) or language or "unknown"
            lang_prob = getattr(info, "language_probability", None)
            row["transcript"] = transcript
            row["language"] = lang
            row["asr_model"] = f"faster-whisper/{model_name}"
            row["asr_status"] = "completed" if transcript else "completed: no speech detected"
            row["asr_language_probability"] = f"{lang_prob:.4f}" if isinstance(lang_prob, (int, float)) else ""
            row["asr_text_char_count"] = str(len(transcript.replace(" ", "")))
            # Keep speaker identity and emotion explicitly unverified; this model is not diarization.
            if not row.get("human_role_confirmation"): row["human_role_confirmation"] = "待人工确认"
            if not row.get("speaker_count"): row["speaker_count"] = "待人工确认"
            if transcript and row.get("duration_seconds_measured"):
                try:
                    duration = max(float(row["duration_seconds_measured"]), 0.1)
                    row["speech_rate"] = f"{len(transcript.replace(' ', '')) / duration:.2f} 字符/秒（ASR粗估）"
                except (TypeError, ValueError): pass
            row["review_status"] = "ASR已转录；说话者/角色/情绪待复核"
            segment_records.append({"index": row.get("index", i), "audio_file": audio_rel,
                                    "language": lang, "language_probability": lang_prob,
                                    "segments": segs})
            completed += 1
            print(f"[{i}/{len(rows)}] 完成: {audio_path.name} ({lang}, {len(transcript)} chars)", flush=True)
        except Exception as exc:
            row["asr_model"] = f"faster-whisper/{model_name}"
            row["asr_status"] = f"error: {type(exc).__name__}: {exc}"
            failed += 1
            print(f"[{i}/{len(rows)}] 失败: {audio_path.name}: {exc}", file=sys.stderr, flush=True)
        # Save after every item so an interrupted batch preserves progress.
        atomic_write_csv(csv_path, fields, rows)
    segments_path = DEFAULT_SEGMENTS
    segments_path.parent.mkdir(parents=True, exist_ok=True)
    segments_path.write_text(json.dumps(segment_records, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {"total_rows": len(rows), "completed_this_run": completed, "failed": failed,
               "skipped_existing": skipped, "model": f"faster-whisper/{model_name}",
               "csv": str(csv_path), "segments_json": str(segments_path)}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def main() -> int:
    global DEFAULT_SEGMENTS
    p = argparse.ArgumentParser(description="使用 faster-whisper 对音频复核集进行真实 ASR 转录")
    p.add_argument("--csv", type=Path, default=DEFAULT_CSV)
    p.add_argument("--audio-dir", type=Path, default=DEFAULT_AUDIO_DIR)
    p.add_argument("--model", default="small", help="tiny/base/small/medium/large-v3 等")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    p.add_argument("--compute-type", default="int8", help="CPU 推荐 int8；CUDA 可尝试 float16")
    p.add_argument("--language", default=None, help="可选语言代码，例如 zh、ja、en；默认自动检测")
    p.add_argument("--overwrite", action="store_true", help="覆盖已有 transcript")
    p.add_argument("--segments-json", type=Path, default=DEFAULT_SEGMENTS)
    args = p.parse_args()
    DEFAULT_SEGMENTS = args.segments_json
    try:
        run_transcription(args.csv, args.audio_dir, args.model, args.device,
                          args.compute_type, args.language, args.overwrite)
        return 0
    except RuntimeError as exc:
        print(f"错误：{exc}", file=sys.stderr); return 2

if __name__ == "__main__": raise SystemExit(main())
