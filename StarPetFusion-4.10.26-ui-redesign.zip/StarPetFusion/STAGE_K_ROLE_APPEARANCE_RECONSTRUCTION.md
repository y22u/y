# Stage K — Role Appearance Reconstruction (4.8.0)

## Goals
- Restore the expected link between the selected role and the visible desktop-pet image.
- Keep the global fallback appearance separate from role-specific portraits.
- Restore the selected role's portrait whenever a requested animation state has no image asset.
- Never leave the previous character's image displayed after switching to a role without a portrait.

## Changes
- Added `role_portraits` configuration map.
- Added portrait discovery in `character_asset_registry.find_role_portrait`, supporting `character_assets/<role-slug>/portrait.*` and other portrait-like filenames.
- Selecting a role applies its portrait if available, then applies the idle animation state.
- Missing state assets use procedural mood animation and restore the role portrait rather than leaving another state's image displayed.
- Added context-menu action “为当前角色设置专属立绘…”. Imported images are copied into the per-user StarPetFusion data directory and associated with the active role.
- If a role has no portrait, the application clearly notifies the user and uses the configured global appearance or default fish instead of showing a different role's portrait.
- The original general-purpose image selector remains available.

## Asset layout
`character_assets/<role-slug>/portrait.png` is the recommended portrait location. State assets may be named `idle.png`, `happy.png`, `think.png`, and `sleep.png`. Users can also import a portrait from the context menu; it is copied to the app's user data directory.

## Limits
This release does not bundle copyrighted Honkai: Star Rail artwork. The role-to-portrait behavior is restored, but a character's actual appearance requires a local portrait file or a downloaded asset that the user is authorized to use. The `pynvml` FutureWarning shown in a screenshot is unrelated to image selection and is not treated as the cause of the fish fallback.
