@echo off
setlocal
cd /d "%~dp0"
echo Starting StarPetFusion local service on 127.0.0.1:8765...
echo The automation runner is started manually from the Automation page.
if exist ".venv\Scripts\python.exe" (
  .venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8765
) else (
  py -3 -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8765
)
if errorlevel 1 (
  echo.
  echo Service failed. Run setup.bat or install requirements-service.txt first.
  pause
)
