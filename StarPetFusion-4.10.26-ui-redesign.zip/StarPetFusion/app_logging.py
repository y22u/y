from __future__ import annotations

"""Central, privacy-conscious application logging."""
import logging
import re
from logging.handlers import RotatingFileHandler
from pathlib import Path
from config_store import app_data_dir

_SECRET_PATTERNS = (
    re.compile(r"(?i)(authorization\s*[:=]\s*bearer\s+)[^\s,;]+"),
    re.compile(r"(?i)(api[_-]?key\s*[=:]\s*)[^\s,;]+"),
    re.compile(r"(?i)(access[_-]?token\s*[=:]\s*)[^\s,;]+"),
    re.compile(r"(?i)(refresh[_-]?token\s*[=:]\s*)[^\s,;]+"),
)


def redact(text: object) -> str:
    value = str(text)
    for pattern in _SECRET_PATTERNS:
        value = pattern.sub(r"\1[REDACTED]", value)
    return value


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = redact(record.getMessage())
            record.args = ()
        except Exception:
            record.msg = "[log message redacted due to formatting error]"
            record.args = ()
        return True


def configure_logging(level: int = logging.INFO) -> Path:
    """Configure bounded rotating logs under the per-user app data directory."""
    log_path = app_data_dir() / "logs" / "starpetfusion.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.setLevel(level)
    if not any(getattr(handler, "_starpet_handler", False) for handler in root.handlers):
        handler = RotatingFileHandler(log_path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        handler._starpet_handler = True  # type: ignore[attr-defined]
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        handler.addFilter(RedactingFilter())
        root.addHandler(handler)
    return log_path
