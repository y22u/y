# 大肥鱼形象保护说明（4.10.11）

用户明确要求沿用 StarPetFusion 4.10.7 的大肥鱼桌宠形象，不进行随意改版。本版本从 4.10.10 混合语音版继续完善，以下与桌宠外观/资源定位有关的文件均与 4.10.7-clean-architecture ZIP 内对应文件逐字节一致：

- `pet_widget.py`
- `download_dafeiyu_assets.py`
- `install_herta_pet.py`
- `character_assets/ASSET_INDEX.json`
- `character_assets/CHARACTER_ASSET_MANIFEST.json`
- `frontend/assets/app.css`
- `frontend/assets/app.js`
- `frontend/index.html`
- `official_data/character_visual_voice_profiles.json`

`tests/test_visual_preservation.py` 锁定上述文件的 4.10.7 SHA-256，避免后续代码改动时无意改变桌宠外观。除非用户明确提出外观修改要求，否则不要更新这些基线哈希或修改对应视觉文件。

说明：4.10.7 的项目说明指出，完整的大肥鱼图片素材并非直接打包在该 ZIP 中；项目通过既有工具在用户主动执行后获取资源。因此本版本保护的是 4.10.7 的桌宠代码、样式和资源清单，不声称额外下载或捆绑了不存在的图片素材。
