@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m pip install -r requirements-asr.txt
if errorlevel 1 (
  echo ASR 依赖安装失败，请检查 Python 版本和网络连接。
  pause
  exit /b 1
)
echo ASR 依赖安装成功。首次识别时 faster-whisper 可能需要下载模型。
pause
