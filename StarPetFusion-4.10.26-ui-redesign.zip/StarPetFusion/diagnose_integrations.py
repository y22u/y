"""Local-only StarPetFusion integration readiness check (no secrets printed)."""
from __future__ import annotations
import importlib.util, json, os
from pathlib import Path
import requests
from config_store import app_data_dir


def main() -> int:
    rows = []
    rows.append(("Edge TTS dependency", importlib.util.find_spec("edge_tts") is not None, "free online TTS; internet required"))
    checks = [
        ("Qwen3-TTS sidecar", os.environ.get("STAR_PET_QWEN3_TTS_ENDPOINT", "http://127.0.0.1:8766") + "/health"),
        ("IndexTTS sidecar", os.environ.get("STAR_PET_INDEXTTS_ENDPOINT", "http://127.0.0.1:8767") + "/health"),
        ("Ollama local API", os.environ.get("STAR_PET_OLLAMA_ENDPOINT", "http://127.0.0.1:11434/v1").rstrip("/").removesuffix("/v1") + "/api/tags"),
    ]
    for name, url in checks:
        try: rows.append((name, requests.get(url, timeout=(2, 3)).ok, url))
        except requests.RequestException: rows.append((name, False, "service not responding"))
    path = app_data_dir() / "integrations.json"
    try: data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except (OSError, ValueError): data = {}
    cfg = data.get("external_agent", {}) if isinstance(data, dict) else {}
    env = str(cfg.get("api_key_env", "STAR_PET_EXTERNAL_AGENT_KEY"))
    host = "127.0.0.1" if str(cfg.get("endpoint", "")).startswith("http://127.0.0.1") else ""
    auth_ok = bool(os.environ.get(env, "").strip()) or bool(host)
    rows.append(("External Agent config", bool(cfg.get("enabled") and cfg.get("endpoint") and cfg.get("model") and auth_ok), "checks enabled/endpoint/model/key presence only; never prints secret"))
    print("StarPetFusion integration readiness (no inference performed)")
    for name, ok, detail in rows: print(f"{'[OK]' if ok else '[NOT READY]'} {name}: {detail}")
    print("Note: ready means dependency/endpoint/config is present, not that full model inference has succeeded.")
    return 0 if all(ok for _, ok, _ in rows) else 1

if __name__ == "__main__": raise SystemExit(main())
