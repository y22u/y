# StarPetFusion 4.10.11 — Hybrid Voice + Visual Preservation

## 本次增量
- 基于 4.10.10 混合语音版本继续完善，没有重写语音调度器。
- 新增 `tests/test_visual_preservation.py`，校验 9 个与 4.10.7 大肥鱼桌宠形象、前端样式和资源清单相关文件的 SHA-256。
- 新增 `VISUAL_PRESERVATION_4.10.11.md`，明确未经用户要求不得改动大肥鱼外观。
- 补充语音路由回归测试，覆盖过期授权、哈希不匹配、配置优先级过滤与默认隐私策略。
- 保留原有角色卡、skill 恢复工具、Qwen3-TTS / IndexTTS sidecar、Edge TTS 适配和本地优先的隐私设置。

## 验证边界
- 自动化单元测试验证代码路径和视觉文件基线；不代表在目标用户电脑上实测 GPU 推理或物理音频设备。
- 官方授权录音清单默认为空。必须先人工核验授权后，才可登记实际素材。
- 在线 Edge TTS 默认关闭，用户明确启用后才会通过该路由发送文本。
