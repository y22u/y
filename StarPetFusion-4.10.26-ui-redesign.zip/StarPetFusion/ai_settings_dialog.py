from __future__ import annotations

from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QPushButton, QVBoxLayout, QListWidget, QProgressBar,
)

from services import AIClient
from ollama_manager import OllamaManager, normalize_ollama_url


PROVIDERS: dict[str, dict[str, str]] = {
    "deepseek": {
        "label": "DeepSeek 云端",
        "api_base_url": "https://api.deepseek.com",
        "api_model": "deepseek-flash",
        "hint": "需要 DeepSeek 开放平台 API Key 和可用额度。",
    },
    "ollama": {
        "label": "Ollama 本地模型（无需云端 Key）",
        "api_base_url": "http://localhost:11434/v1",
        "api_model": "qwen2.5:3b",
        "hint": "先安装并启动 Ollama，再执行 ollama pull qwen2.5:3b。模型名必须与 ollama list 一致。",
    },
    "openai": {
        "label": "OpenAI API",
        "api_base_url": "https://api.openai.com/v1",
        "api_model": "gpt-4o-mini",
        "hint": "需要 OpenAI API Key；可用模型以账号权限和官方平台为准。",
    },
    "custom": {
        "label": "自定义 OpenAI 兼容接口",
        "api_base_url": "",
        "api_model": "",
        "hint": "适用于支持 /chat/completions 的其他云端或本地服务。",
    },
}


class AISettingsDialog(QDialog):
    """Settings editor for local Ollama and OpenAI-compatible providers."""
    def __init__(self, config: dict[str, Any], parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("AI 模型设置")
        self.setMinimumWidth(520)
        self.setModal(True)
        self._original = dict(config)
        self.result_config: dict[str, Any] | None = None
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 20)
        layout.setSpacing(14)

        title = QLabel("连接你的 AI 搭档")
        title.setObjectName("DialogTitle")
        subtitle = QLabel("支持本地模型与云端接口。API Key 只保存在本机配置中；本地 Ollama 不需要云端密钥。")
        subtitle.setObjectName("MutedText")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)

        form = QFormLayout()
        form.setVerticalSpacing(12)
        form.setHorizontalSpacing(16)
        self.provider = QComboBox()
        for key, value in PROVIDERS.items():
            self.provider.addItem(value["label"], key)
        current_provider = str(config.get("provider", "deepseek"))
        index = self.provider.findData(current_provider)
        self.provider.setCurrentIndex(max(0, index))
        self.base_url = QLineEdit(str(config.get("api_base_url", "https://api.deepseek.com")))
        self.base_url.setPlaceholderText("https://api.example.com/v1")
        self.model = QLineEdit(str(config.get("api_model", "deepseek-flash")))
        self.model.setPlaceholderText("填写服务商提供的模型 ID")
        self.api_key = QLineEdit(str(config.get("api_key", "")))
        self.api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key.setPlaceholderText("本地 Ollama 可留空")
        key_row = QHBoxLayout()
        key_row.addWidget(self.api_key, 1)
        self.reveal_btn = QPushButton("显示")
        self.reveal_btn.setObjectName("SecondaryButton")
        self.reveal_btn.setCheckable(True)
        self.reveal_btn.toggled.connect(self._toggle_key)
        key_row.addWidget(self.reveal_btn)
        key_wrap = QVBoxLayout()
        key_wrap.addLayout(key_row)
        self.hint = QLabel()
        self.hint.setObjectName("MutedText")
        self.hint.setWordWrap(True)
        key_wrap.addWidget(self.hint)
        form.addRow("服务类型", self.provider)
        form.addRow("Base URL", self.base_url)
        form.addRow("模型 ID", self.model)
        form.addRow("API Key", key_wrap)
        layout.addLayout(form)

        # Ollama native HTTP model management. The model list is loaded on demand.
        self.ollama_panel = QVBoxLayout()
        self.ollama_title = QLabel("Ollama 模型管理（通过本机 HTTP API）")
        self.ollama_panel.addWidget(self.ollama_title)
        model_row = QHBoxLayout()
        self.installed_models = QComboBox()
        self.installed_models.setMinimumWidth(220)
        self.refresh_models_btn = QPushButton("刷新模型")
        self.refresh_models_btn.setObjectName("SecondaryButton")
        self.refresh_models_btn.clicked.connect(self.refresh_ollama_models)
        self.use_model_btn = QPushButton("使用所选模型")
        self.use_model_btn.setObjectName("SecondaryButton")
        self.use_model_btn.clicked.connect(self.use_selected_model)
        model_row.addWidget(self.installed_models, 1)
        model_row.addWidget(self.refresh_models_btn)
        model_row.addWidget(self.use_model_btn)
        self.ollama_panel.addLayout(model_row)
        pull_row = QHBoxLayout()
        self.pull_model_name = QLineEdit()
        self.pull_model_name.setPlaceholderText("下载模型，例如 qwen2.5:3b")
        self.pull_model_btn = QPushButton("下载模型")
        self.pull_model_btn.setObjectName("SecondaryButton")
        self.pull_model_btn.clicked.connect(self.pull_ollama_model)
        self.delete_model_btn = QPushButton("删除所选")
        self.delete_model_btn.setObjectName("SecondaryButton")
        self.delete_model_btn.clicked.connect(self.delete_ollama_model)
        pull_row.addWidget(self.pull_model_name, 1)
        pull_row.addWidget(self.pull_model_btn)
        pull_row.addWidget(self.delete_model_btn)
        self.ollama_panel.addLayout(pull_row)
        self.model_progress = QProgressBar()
        self.model_progress.setRange(0, 0)
        self.model_progress.setVisible(False)
        self.ollama_panel.addWidget(self.model_progress)
        self.ollama_panel_widget = QLabel()  # stable placeholder for layout spacing
        layout.addLayout(self.ollama_panel)

        self.status = QLabel("建议先点击“测试连接”，确认模型可用后再保存。")
        self.status.setObjectName("StatusText")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        actions = QHBoxLayout()
        self.test_btn = QPushButton("测试连接")
        self.test_btn.setObjectName("SecondaryButton")
        self.test_btn.clicked.connect(self.test_connection)
        actions.addWidget(self.test_btn)
        actions.addStretch(1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Save)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("保存设置")
        buttons.button(QDialogButtonBox.StandardButton.Save).setObjectName("PrimaryButton")
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self.save_settings)
        actions.addWidget(buttons)
        layout.addLayout(actions)

        self.provider.currentIndexChanged.connect(self._provider_changed)
        self._provider_changed(initial=True)

    def _toggle_key(self, shown: bool) -> None:
        self.api_key.setEchoMode(QLineEdit.EchoMode.Normal if shown else QLineEdit.EchoMode.Password)
        self.reveal_btn.setText("隐藏" if shown else "显示")

    def _provider_changed(self, _index: int = -1, initial: bool = False) -> None:
        provider = str(self.provider.currentData() or "custom")
        preset = PROVIDERS[provider]
        if not initial and provider != "custom":
            self.base_url.setText(preset["api_base_url"])
            self.model.setText(preset["api_model"])
            if provider == "ollama":
                self.api_key.clear()
        self.hint.setText(preset["hint"])
        is_ollama = provider == "ollama"
        for widget in (self.ollama_title, self.installed_models, self.refresh_models_btn, self.use_model_btn,
                       self.pull_model_name, self.pull_model_btn, self.delete_model_btn):
            widget.setVisible(is_ollama)
        self.model_progress.setVisible(False)

    def _ollama_manager(self) -> OllamaManager:
        return OllamaManager(self.base_url.text().strip() or "http://127.0.0.1:11434")

    def refresh_ollama_models(self) -> None:
        try:
            manager = self._ollama_manager()
            models = manager.list_models()
            current = self.model.text().strip()
            self.installed_models.clear()
            for item in models:
                name = str(item.get("name", ""))
                size = item.get("size")
                label = f"{name}  ({int(size) / (1024**3):.1f} GB)" if isinstance(size, (int, float)) else name
                self.installed_models.addItem(label, name)
            idx = self.installed_models.findData(current)
            if idx >= 0:
                self.installed_models.setCurrentIndex(idx)
            if not models:
                self.status.setText("Ollama 已连接，但尚未安装模型。可在下方输入模型名下载。")
            else:
                self.status.setText(f"已读取 {len(models)} 个 Ollama 模型。")
        except Exception as exc:
            self.status.setText(f"无法读取 Ollama 模型列表：{str(exc)[:300]}。请确认 Ollama 已启动，地址通常为 http://127.0.0.1:11434。")

    def use_selected_model(self) -> None:
        name = str(self.installed_models.currentData() or "").strip()
        if not name:
            self.status.setText("请先刷新并选择一个已安装模型。")
            return
        self.provider.setCurrentIndex(max(0, self.provider.findData("ollama")))
        self.base_url.setText("http://127.0.0.1:11434/v1")
        self.model.setText(name)
        self.api_key.clear()
        self.status.setText(f"已选择模型 {name}；点击“测试连接”验证后保存。")

    def pull_ollama_model(self) -> None:
        name = self.pull_model_name.text().strip()
        if not name:
            self.status.setText("请填写模型名称，例如 qwen2.5:3b。")
            return
        from PySide6.QtCore import QThread, Signal
        manager = self._ollama_manager()
        self.pull_model_btn.setEnabled(False)
        self.refresh_models_btn.setEnabled(False)
        self.model_progress.setVisible(True)
        class PullWorker(QThread):
            progress = Signal(str)
            result = Signal(bool, str)
            def run(worker_self):
                try:
                    def report(event):
                        status = str(event.get("status", "下载中"))
                        total, completed = event.get("total"), event.get("completed")
                        if isinstance(total, (int, float)) and total > 0 and isinstance(completed, (int, float)):
                            status += f" {completed / total * 100:.0f}%"
                        worker_self.progress.emit(status[:160])
                    manager.pull_model(name, report)
                    worker_self.result.emit(True, f"模型 {name} 下载完成。")
                except Exception as exc:
                    worker_self.result.emit(False, f"模型下载失败：{str(exc)[:350]}")
        self._pull_worker = PullWorker(self)
        self._pull_worker.progress.connect(self.status.setText)
        self._pull_worker.result.connect(self._pull_result)
        self._pull_worker.start()

    def _pull_result(self, ok: bool, message: str) -> None:
        self.status.setText(message)
        self.pull_model_btn.setEnabled(True)
        self.refresh_models_btn.setEnabled(True)
        self.model_progress.setVisible(False)
        if ok:
            self.refresh_ollama_models()

    def delete_ollama_model(self) -> None:
        name = str(self.installed_models.currentData() or "").strip()
        if not name:
            self.status.setText("请先选择要删除的模型。")
            return
        answer = QMessageBox.question(self, "确认删除模型", f"确定从本机 Ollama 删除模型 {name}？此操作会释放磁盘空间，之后需要重新下载才能使用。")
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self._ollama_manager().delete_model(name)
            self.status.setText(f"已删除模型 {name}。")
            self.refresh_ollama_models()
        except Exception as exc:
            self.status.setText(f"删除失败：{str(exc)[:300]}")

    def _form_config(self) -> dict[str, Any]:
        result = dict(self._original)
        result.update({
            "provider": str(self.provider.currentData() or "custom"),
            "api_base_url": self.base_url.text().strip().rstrip("/"),
            "api_model": self.model.text().strip(),
            "api_key": self.api_key.text().strip(),
        })
        return result

    def test_connection(self) -> None:
        config = self._form_config()
        if not config["api_base_url"] or not config["api_model"]:
            self.status.setText("请先填写 Base URL 和模型 ID。")
            return
        self.test_btn.setEnabled(False)
        self.status.setText("正在测试连接，请稍候……")
        from PySide6.QtCore import QThread, Signal, QObject

        class TestWorker(QThread):
            result = Signal(bool, str)
            def run(worker_self):
                try:
                    answer = AIClient(config).chat([
                        {"role": "system", "content": "你是连接测试助手。只用中文简短回复。"},
                        {"role": "user", "content": "请只回复：连接成功"},
                    ], timeout=20)
                    worker_self.result.emit(True, answer[:180])
                except Exception as exc:
                    worker_self.result.emit(False, str(exc)[:500])

        self._worker = TestWorker(self)
        self._worker.result.connect(self._test_result)
        self._worker.finished.connect(lambda: self.test_btn.setEnabled(True))
        self._worker.start()

    def _test_result(self, ok: bool, message: str) -> None:
        self.status.setText(("连接成功：" if ok else "连接失败：") + message)
        self.status.setProperty("success", ok)
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)

    def save_settings(self) -> None:
        config = self._form_config()
        if not config["api_base_url"] or not config["api_model"]:
            QMessageBox.warning(self, "配置不完整", "请填写 Base URL 和模型 ID。")
            return
        is_local = config["provider"] == "ollama" or "localhost" in config["api_base_url"] or "127.0.0.1" in config["api_base_url"]
        if not is_local and not config["api_key"] and not (self._original.get("api_key") or ""):
            QMessageBox.information(self, "提示", "尚未填写 API Key。保存后仍可使用桌宠，但云端 AI 请求需要有效密钥。")
        self.result_config = config
        self.accept()
