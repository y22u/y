# 角色 Skill 文件恢复（4.10.9）

如果 `vendor/hsr-skills/` 或 `bundled_roles/` 中的角色 `SKILL.md` 丢失，请先退出程序，并备份整个工程目录与 `%APPDATA%\\StarPetFusion\\`。

## 诊断并恢复内置角色卡
在工程根目录执行：

```powershell
python restore_character_skills.py
```

脚本会从 `skill_recovery/bundled_roles/` 中的随包恢复快照补回缺失的 `bundled_roles/<slug>/SKILL.md` 和缺失的 `manifest.json`。已有文件不会被覆盖。

## 同时补齐外部角色资料目录
如需要把内置角色卡补入 `vendor/hsr-skills/`，执行：

```powershell
python restore_character_skills.py --restore-vendor
```

此模式只会为缺少 `SKILL.md` 的 slug 新建资料，不覆盖已有的上游角色资料。注意：内置角色卡是项目整理的风格设定，不等于外部 `hsr-skills` 仓库的完整原始内容。

## 重新下载完整上游资料
如果需要上游仓库中的全部人物与额外资料，确认网络可访问 GitHub 后运行：

```powershell
python prepare.py --force
```

**警告：** `--force` 会替换 `vendor/` 中准备脚本管理的上游目录。先备份自定义修改；不要为了修复角色资料而删除 `%APPDATA%\\StarPetFusion\\` 或角色数据库。
