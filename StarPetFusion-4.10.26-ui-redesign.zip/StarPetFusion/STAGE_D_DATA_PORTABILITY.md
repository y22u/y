# Stage D — Data portability, migration and diagnostics (3.12)

## Three iteration passes
1. **Portability foundation:** create a versioned ZIP format for `config.json`, `integrations.json`, and `growth.sqlite3`; default export recursively redacts fields whose names resemble keys, tokens, secrets, passwords, credentials, or authorization headers.
2. **Restore safety:** validate archive size, exact allow-listed paths, format/version, SHA-256 manifest, JSON structure, and SQLite integrity before writing. Existing files are copied to `backups/stage-d-import/<timestamp>/`; each target is replaced atomically. Import requires UI confirmation and warns that redacted credentials must be reconfigured.
3. **Diagnostics and UI integration:** add a secret-free local diagnostic report and a UI entry for export, archive validation, import/restore, and report refresh. Add automated tests for redaction, round-trip restore, hash tampering, path traversal, and diagnostics.

## Safety notes
- The default export is redacted and recommended. Opting into sensitive export is an explicit UI checkbox with a second confirmation.
- The archive is local; this feature does not upload it anywhere.
- Import only accepts the three allow-listed data files and does not import executable files or role assets.
- Import while another StarPetFusion instance is running is discouraged. Restart the app after import so in-memory settings reload.
- Import creates rollback copies for files that existed before import. Keep a separate copy of important backups.
- Diagnostic reports intentionally omit prompt content, memory text, API keys, and full endpoint URLs.
