@echo off
setlocal
cd /d "%~dp0"
start "StarPetFusion Qwen3-TTS isolated service" "%ComSpec%" /k ""%~dp0start_qwen3_sidecar.bat""
start "StarPetFusion IndexTTS isolated service" "%ComSpec%" /k ""%~dp0start_indextts_sidecar.bat""
echo Two isolated service windows have been opened. Wait for both services to finish loading.
echo Qwen3 endpoint: http://127.0.0.1:8766/health
echo IndexTTS endpoint: http://127.0.0.1:8767/health
pause
