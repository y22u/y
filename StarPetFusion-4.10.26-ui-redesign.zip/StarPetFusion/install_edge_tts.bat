@echo off
setlocal
cd /d "%~dp0"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Edge TTS dependency installation failed. Check your network, proxy and Python environment.
  pause
  exit /b 1
)
echo.
echo Dependencies installed. Start with: python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8765
pause
