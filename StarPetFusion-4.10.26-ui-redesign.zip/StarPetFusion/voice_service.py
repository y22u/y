from __future__ import annotations
import json, threading
from pathlib import Path
from voice_pipeline import distilled_voice_profile

ROOT = Path(__file__).resolve().parent
PROFILE_PATH = ROOT / "voice_profiles.json"

def load_profiles() -> dict:
    try:
        data = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {"default": {"rate": 1.0, "volume": 0.9, "language": "zh-CN"}}

def speak_text(text: str, role_slug: str = "default", enabled: bool = True) -> None:
    """Speak with installed system TTS. Voice profiles tune delivery, not clone actors.

    pyttsx3 is optional. If missing, voice output safely becomes a no-op. Call this
    from a worker thread because platform speech engines may block.
    """
    if not enabled or not str(text).strip():
        return
    profiles = load_profiles()
    profile = distilled_voice_profile(profiles.get(role_slug, profiles.get("default", {})))
    # Hybrid route: licensed exact-match audio, local model sidecars, and opt-in online Edge.
    # The router never sends text online unless allow_online is explicitly enabled.
    try:
        from voice_router import route_and_play
        if route_and_play(str(text), role_slug, profile):
            return
    except Exception:
        # Voice routing must never break chat or desktop-pet behavior.
        pass
    # Preserve the existing explicitly configured third-party integration path.
    try:
        from integrations import external_tts
        if external_tts(str(text), role_slug):
            return
    except Exception:
        pass
    try:
        import pyttsx3  # optional dependency
        engine = pyttsx3.init()
        base = int(engine.getProperty("rate") or 180)
        rate = max(100, min(260, int(base * float(profile.get("rate", 1.0)))))
        volume = max(0.0, min(1.0, float(profile.get("volume", 0.9))))
        engine.setProperty("rate", rate)
        engine.setProperty("volume", volume)
        # Use the OS-installed voice; do not claim it is the official character voice.
        engine.say(str(text)[:1200])
        engine.runAndWait()
        engine.stop()
    except (ImportError, RuntimeError, ValueError, TypeError):
        return

def speak_async(text: str, role_slug: str = "default", enabled: bool = True) -> threading.Thread | None:
    if not enabled or not str(text).strip():
        return None
    thread = threading.Thread(target=speak_text, args=(text, role_slug, enabled), daemon=True)
    thread.start()
    return thread
