#!/usr/bin/env python3
"""Stage A readiness diagnostics for StarPetFusion.

Default mode is offline and never prints secrets. --live-tts performs one real
synthesis request using the configured provider; it may consume API quota.
"""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
import platform
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def _result(name: str, status: str, detail: str) -> dict[str, str]:
    return {"check": name, "status": status, "detail": detail}


def run_checks(live_tts: bool = False) -> list[dict[str, str]]:
    from config_store import app_data_dir
    checks: list[dict[str, str]] = []
    checks.append(_result("python", "PASS" if sys.version_info >= (3, 10) else "WARN", platform.python_version()))
    checks.append(_result("platform", "INFO", platform.platform()))
    for module in ("PySide6", "requests", "google.auth", "pyttsx3"):
        available = importlib.util.find_spec(module) is not None
        required = module in {"PySide6", "requests"}
        checks.append(_result(f"dependency:{module}", "PASS" if available else ("FAIL" if required else "WARN"), "installed" if available else "not installed"))

    roles_dir = ROOT / "bundled_roles"
    role_files = list(roles_dir.glob("*/manifest.json")) if roles_dir.exists() else []
    valid_roles = 0
    invalid_roles = []
    for path in role_files:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data:
                valid_roles += 1
            else:
                invalid_roles.append(path.parent.name)
        except (OSError, ValueError):
            invalid_roles.append(path.parent.name)
    checks.append(_result("bundled_roles", "PASS" if role_files and not invalid_roles else "FAIL", f"valid={valid_roles}, invalid={len(invalid_roles)}"))

    data_path = app_data_dir() / "integrations.json"
    try:
        cfg = json.loads(data_path.read_text(encoding="utf-8")) if data_path.exists() else {}
        if not isinstance(cfg, dict):
            raise ValueError("root must be an object")
        checks.append(_result("integrations_config", "PASS", "exists and valid JSON" if data_path.exists() else "not created yet; defaults apply"))
    except (OSError, ValueError) as exc:
        cfg = {}
        checks.append(_result("integrations_config", "FAIL", f"invalid or unreadable: {type(exc).__name__}"))

    tts = cfg.get("tts", {}) if isinstance(cfg, dict) else {}
    tts = tts if isinstance(tts, dict) else {}
    provider = str(tts.get("provider", "external")).lower()
    enabled = bool(tts.get("enabled", False))
    checks.append(_result("tts_configuration", "INFO" if not enabled else "PASS", f"enabled={enabled}; provider={provider}"))
    if enabled and provider == "gemini_api":
        env_name = str(tts.get("api_key_env", "GEMINI_API_KEY"))
        present = bool(os.environ.get(env_name, "").strip()) if env_name.isidentifier() else False
        checks.append(_result("gemini_api_key", "PASS" if present else "FAIL", f"environment variable {env_name}: {'set' if present else 'not set'}; value hidden"))
    elif enabled and provider == "google_cloud":
        try:
            import google.auth
            credentials, project = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
            checks.append(_result("google_cloud_adc", "PASS", f"ADC available; project discovery={'yes' if project else 'no'}; token value hidden"))
        except Exception as exc:
            checks.append(_result("google_cloud_adc", "FAIL", f"ADC unavailable: {type(exc).__name__}; configure Application Default Credentials"))
    elif enabled and provider not in {"external", "generic_json", "openai_compatible"}:
        checks.append(_result("tts_provider", "WARN", "unknown provider name; verify settings"))

    if os.name == "nt":
        checks.append(_result("audio_player", "PASS", "Windows default WAV association will be used"))
    else:
        player = shutil.which("xdg-open") if sys.platform != "darwin" else shutil.which("open")
        checks.append(_result("audio_player", "PASS" if player else "WARN", player or "open/xdg-open not found"))

    if live_tts:
        if not enabled:
            checks.append(_result("live_tts", "SKIP", "TTS is disabled in integrations.json"))
        else:
            try:
                from integrations import external_tts
                # The adapter synthesizes into a temporary WAV. Prevent launching a player
                # during diagnostics by testing adapters directly instead of external_tts.
                from tts_adapters import GoogleGeminiTTSAdapter, GoogleCloudTTSAdapter, ExternalTTSAdapter
                common = dict(voice=str(tts.get("voice", "Kore")), language=str(tts.get("language", "zh-CN")), style="StarPetFusion stage A connection test", speed=1.0)
                with tempfile.TemporaryDirectory(prefix="starpet-stage-a-") as temp:
                    target = Path(temp) / "tts-check.wav"
                    timeout = int(tts.get("timeout", 60))
                    if provider == "gemini_api":
                        adapter = GoogleGeminiTTSAdapter(str(tts.get("api_key_env", "GEMINI_API_KEY")), str(tts.get("model", "gemini-2.5-flash-preview-tts")), timeout)
                    elif provider == "google_cloud":
                        adapter = GoogleCloudTTSAdapter(str(tts.get("project_env", "GOOGLE_CLOUD_PROJECT")), str(tts.get("model", "gemini-2.5-flash-tts")), timeout, str(tts.get("location", "global")))
                    else:
                        adapter = ExternalTTSAdapter(str(tts.get("endpoint", "")), str(tts.get("api_key_env", "STAR_PET_TTS_API_KEY")), str(tts.get("mode", "openai_compatible")), str(tts.get("model", "")), timeout)
                    adapter.synthesize("StarPetFusion语音服务连接测试。", target, **common)
                    with target.open("rb") as audio:
                        header = audio.read(12)
                    valid = len(header) >= 12 and header[:4] == b"RIFF" and header[8:12] == b"WAVE"
                    checks.append(_result("live_tts", "PASS" if valid else "FAIL", f"audio file generated; WAV header {'valid' if valid else 'invalid'}; playback not attempted"))
            except Exception as exc:
                checks.append(_result("live_tts", "FAIL", f"{type(exc).__name__}: {str(exc)[:220]}"))
    return checks


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live-tts", action="store_true", help="make one real TTS request; may consume quota")
    parser.add_argument("--json", action="store_true", help="emit JSON report")
    args = parser.parse_args()
    checks = run_checks(args.live_tts)
    if args.json:
        print(json.dumps({"version": "3.9-stage-a", "checks": checks}, ensure_ascii=False, indent=2))
    else:
        print("StarPetFusion Stage A readiness check")
        print("=" * 42)
        for item in checks:
            print(f"[{item['status']:<4}] {item['check']}: {item['detail']}")
        print("\nSecrets are not printed. --live-tts sends a short test phrase to the configured provider.")
    return 1 if any(x["status"] == "FAIL" for x in checks) else 0

if __name__ == "__main__":
    raise SystemExit(main())
