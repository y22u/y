"""Import local fan art / character images into the StarPetFusion SQLite library."""
import argparse
from character_database import CharacterDatabase

def main():
    p=argparse.ArgumentParser(description='导入本地有权使用的角色形象至数字库')
    p.add_argument('--character',required=True,help='角色 slug，例如 the-herta/aglaea/hysilens')
    p.add_argument('--file',required=True,help='本地图片文件路径')
    p.add_argument('--kind',default='portrait',choices=['portrait','idle','happy','think','sleep'])
    p.add_argument('--source-name',default='user import'); p.add_argument('--source-url',default='')
    p.add_argument('--license',default='user-provided / permission confirmed by user'); p.add_argument('--attribution',default='')
    a=p.parse_args(); db=CharacterDatabase()
    try:
        path=db.import_asset(a.character,a.file,a.kind,a.source_name,a.source_url,a.license,a.attribution)
        print('已导入数字库：',path); print('数据库：',db.path)
    finally: db.close()
    return 0
if __name__=='__main__': raise SystemExit(main())
