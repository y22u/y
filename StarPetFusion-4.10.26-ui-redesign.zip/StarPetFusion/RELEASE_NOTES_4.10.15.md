# StarPetFusion 4.10.15 — External Agent Low-Latency

## Changes
- Reuse a pooled HTTP session for external Agent calls to reduce repeated connection/TLS setup overhead.
- Add `fast`, `balanced`, and `deep` response modes. Fast mode bounds retained conversation history and message length and uses a concise response instruction.
- Add an optional `max_tokens` request limit (`0` leaves provider defaults unchanged).
- Add response strategy, history count, and generation cap controls to the external Agent settings dialog.
- Keep connection/read timeouts separate, keep credentials in environment variables, preserve HTTPS/loopback-only endpoint validation, and avoid leaking upstream response bodies.

## Validation
- Full Python test suite: 131 tests, OK, 1 skipped.
- Python compilation and JavaScript syntax checks are run before packaging.
- This is a client-side latency optimization; real response time still depends on network RTT, provider queueing, model inference, and provider support for optional request parameters. No fixed latency guarantee is made.
