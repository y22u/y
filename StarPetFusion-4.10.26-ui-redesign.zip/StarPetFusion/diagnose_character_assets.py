"""Read-only diagnostic for missing StarPetFusion character images/animations.

This script never writes to configuration, role databases, or asset directories.
It lists candidate assets and reports whether expected The Herta files exist.
Run: python diagnose_character_assets.py [optional-extra-root ...]
"""
from __future__ import annotations
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.apng'}
KEYWORDS = ('herta', 'the-herta', 'the_herta', '大黑塔', 'sprite', 'portrait', 'idle', 'happy', 'think', 'sleep')

def roots_to_scan() -> list[Path]:
    home = Path.home()
    roots = [
        ROOT / 'character_assets', ROOT / 'frontend' / 'assets' / 'characters',
        ROOT / 'vendor' / 'TheHerta-CodexPet', ROOT / 'vendor' / 'dafeiyu-pet',
        home / '.codex' / 'pets' / 'the-herta', home / 'Downloads',
        home / 'Desktop', home / 'Documents',
    ]
    appdata = os.environ.get('APPDATA')
    if appdata:
        roots.append(Path(appdata) / 'StarPetFusion' / 'role_portraits')
    roots.extend(Path(x).expanduser() for x in sys.argv[1:])
    unique = []
    seen = set()
    for root in roots:
        key = str(root.resolve(strict=False)).casefold()
        if key not in seen:
            unique.append(root); seen.add(key)
    return unique

def main() -> int:
    print('StarPetFusion 大黑塔形象资源只读诊断')
    print('说明：仅列出文件，不修改配置、数据库或素材。')
    found = 0
    for root in roots_to_scan():
        if not root.exists():
            continue
        print(f'\n[目录] {root}')
        try:
            files = root.rglob('*') if root.is_dir() else [root]
            for path in files:
                try:
                    if not path.is_file() or path.suffix.lower() not in IMAGE_EXTS:
                        continue
                    name = (path.name + ' ' + str(path.parent)).casefold()
                    if any(word.casefold() in name for word in KEYWORDS):
                        print(f'  {path} | {path.stat().st_size:,} bytes')
                        found += 1
                except OSError:
                    continue
        except OSError as exc:
            print(f'  [跳过] 无法读取：{exc}')
    print(f'\n候选资源数：{found}')
    print('关键文件检查：')
    expected = [
        ROOT / 'vendor' / 'TheHerta-CodexPet' / 'the-herta' / 'pet.json',
        ROOT / 'vendor' / 'TheHerta-CodexPet' / 'the-herta' / 'spritesheet.webp',
    ]
    for path in expected:
        print(f'  {"存在" if path.is_file() else "缺失"}: {path}')
    print('若只发现 spritesheet.webp，请勿将整张图集当成立绘；需依据上游 pet.json 的帧布局解析。')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
