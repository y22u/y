# StarPetFusion 3.14 Stage F — 自动角色资料与提示词生成

## 三轮迭代

### Iteration 1 — 角色资料结构扩展
- 对全部 24 个内置角色的 `manifest.json` 自动增加 `prompt_profile` 结构。
- 补充身份锚点、性格与价值、语言风格、互动协议、情绪适配、任务适配、事实边界、安全能力边界及回复自检清单。
- 保留现有角色资料和示例；将扩展部分标记为粉丝向原创互动，不冒充官方资料。

### Iteration 2 — 自动填充提示词文件并接入运行时
- 为每个角色生成 `prompt_profile.md`，不需要用户手工填入设定。
- 新增 `tools/generate_role_prompts.py`，可从 manifest 中的 `prompt_profile.prompt_template` 批量重建提示词文件。
- `skills.py` 将提示词文件纳入现有角色提示构建流程；仍受现有上下文预算限制。

### Iteration 3 — 自动化质量门禁
- 新增 `tests/test_stage_f_persona_profiles.py`，验证每个角色文件、关键设定字段、运行时提示词拼装及官方/原创边界声明。
- 继续保留已有阶段 A–E 的诊断、数据安全、角色来源和既有功能。

## 再生成命令

```bash
python tools/generate_role_prompts.py
python -m compileall -q .
python -m unittest discover -s tests -q
```

## 注意事项
- 角色扩写是结构化粉丝向演绎，并不等于官方完整设定；剧情细节应以官方游戏内文本为准。
- `prompt_profile.md` 被加入角色提示拼装流程，但最终实际送入模型的长度仍受 `skills.py` 的总字符预算约束。完整资料保存在文件中，运行时按预算截取。
- 本阶段的自动测试不等同于 Windows GUI、云端模型、语音设备实机验收。
