from __future__ import annotations

import math
import random

from PySide6.QtCore import QPoint, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import QWidget


class PetWidget(QWidget):
    petClicked = Signal()
    petDoubleClicked = Signal()
    petDropped = Signal()
    modeChanged = Signal(str)

    def __init__(self, config: dict, parent=None) -> None:
        flags = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if config.get("topmost", True):
            flags |= Qt.WindowType.WindowStaysOnTopHint
        super().__init__(parent, flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle("星穹桌宠")
        self.setMinimumSize(110, 130)
        self.pet_size = max(100, min(int(config.get("size", 190)), 320))
        self.bubble = ""
        self.bubble_until = 0
        self.mode = config.get("mode", "wander") if config.get("mode") in ("wander", "follow", "still") else "wander"
        self.passthrough = bool(config.get("passthrough", False))
        self.topmost = bool(config.get("topmost", True))
        self.facing = 1
        self.direction = "down"
        self.dragging = False
        self._drag_offset = QPoint()
        self._drag_start = QPoint()
        self._last_position = self.pos()
        self._suppress_release_click = False
        self._click_timer = QTimer(self)
        self._click_timer.setSingleShot(True)
        self._click_timer.setInterval(260)
        self._click_timer.timeout.connect(self.petClicked.emit)
        self._tick = 0
        self._target = None
        self._rest_ticks = 0
        self.animations_enabled = bool(config.get("animations_enabled", True))
        self.animation_style = str(config.get("animation_style", "gentle"))
        if self.animation_style not in ("gentle", "bouncy", "subtle"):
            self.animation_style = "gentle"
        self.idle_chatter = bool(config.get("idle_chatter", False))
        self.mood = "idle"
        self.mood_until = 0
        self._blink_ticks = random.randint(75, 150)
        self._blink_closed = 0
        self._is_hovered = False
        # Native desktop-pet appearance is intentionally image-free. Keep the
        # legacy config key for migration compatibility, but never load portraits,
        # sprite sheets, GIFs or other image assets into the floating widget.
        self.appearance_path = ""
        self.setFixedSize(max(160, min(self.pet_size + 30, 260)), 96)
        screen = self.screen().availableGeometry() if self.screen() else None
        x = config.get("x")
        y = config.get("y")
        if screen:
            self.move(int(x if x is not None else screen.right() - self.width() - 40),
                      int(y if y is not None else screen.bottom() - self.height() - 40))
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_tick)
        self.timer.start(35)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)
        if self.passthrough:
            self.set_passthrough(True)

    def say(self, message: str, duration_ms: int = 4200) -> None:
        self.bubble = (message or "").strip()[:180]
        self.bubble_until = self._tick + max(10, duration_ms // 35)
        self.update()

    def react(self, action: str) -> str:
        """Trigger a lightweight procedural emote without requiring animation assets."""
        reactions = {
            "wave": ("wave", ["哼，注意到我了？", "我在这里。", "有什么新发现吗？"]),
            "dance": ("happy", ["来点节奏！", "今天心情不错。", "看好了——特别表演。"]),
            "think": ("curious", ["让我想想。", "有意思，值得分析。", "先把问题拆开。"]),
            "sleep": ("sleepy", ["休息五分钟……大概。", "安静一会儿也不错。", "我只是在闭目养神。"]),
            "cheer": ("happy", ["不错，继续保持。", "这一步做得很好。", "再接再厉。"]),
        }
        mood, lines = reactions.get(action, reactions["wave"])
        self.mood = mood
        self.mood_until = self._tick + 105
        message = random.choice(lines)
        self.say(message, 3600)
        return message

    def set_animations_enabled(self, enabled: bool) -> None:
        self.animations_enabled = bool(enabled)
        self.update()

    def set_animation_style(self, style: str) -> None:
        """Choose a procedural motion profile; no external animation assets required."""
        if style not in ("gentle", "bouncy", "subtle"):
            return
        self.animation_style = style
        self.update()

    def set_idle_chatter(self, enabled: bool) -> None:
        self.idle_chatter = bool(enabled)
        self.update()

    def set_mode(self, mode: str) -> None:
        if mode not in ("wander", "follow", "still"):
            return
        self.mode = mode
        self._target = None
        self.modeChanged.emit(mode)
        self.update()

    def set_size(self, size: int) -> None:
        self.pet_size = max(100, min(int(size), 320))
        self.setFixedSize(max(160, min(self.pet_size + 30, 260)), 96)
        self.update()

    def set_appearance(self, image_path: str | None, announce: bool = True) -> bool:
        """Compatibility shim: desktop-pet image rendering has been removed."""
        self.appearance_path = ""
        self.update()
        if announce:
            self.say("桌宠已使用无图片文字徽标外观。")
        return True

    def set_topmost(self, enabled: bool) -> None:
        self.topmost = bool(enabled)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, self.topmost)
        self.show()

    def set_passthrough(self, enabled: bool) -> None:
        self.passthrough = bool(enabled)
        self.setWindowFlag(Qt.WindowType.WindowTransparentForInput, self.passthrough)
        self.show()

    def _on_tick(self) -> None:
        self._tick += 1
        bubble_expired = bool(self.bubble and self._tick > self.bubble_until)
        if bubble_expired:
            self.bubble = ""
        if self.mood != "idle" and self._tick > self.mood_until:
            self.mood = "idle"
        self._blink_ticks -= 1
        if self._blink_closed > 0:
            self._blink_closed -= 1
        if self._blink_ticks <= 0:
            self._blink_closed = 4
            self._blink_ticks = random.randint(90, 190)
        # Optional, deliberately infrequent idle chatter; disabled by default.
        if self.idle_chatter and not self.bubble and not self.dragging and random.random() < 0.00045:
            self.say(random.choice(["嗯？", "今天也要好好加油。", "有什么新鲜事吗？", "我在听。"]), 2800)
        if self.animations_enabled or bubble_expired:
            self.update()
        if self.dragging or self.mode == "still":
            return
        screen = self.screen().availableGeometry() if self.screen() else None
        if not screen:
            return
        cx, cy = self.x() + self.width() // 2, self.y() + self.height() // 2
        target_x = target_y = None
        if self.mode == "follow":
            from PySide6.QtGui import QCursor
            p = QCursor.pos()
            target_x, target_y = p.x(), p.y()
        else:
            if self._rest_ticks > 0:
                self._rest_ticks -= 1
                return
            if self._target is None or math.hypot(self._target[0] - cx, self._target[1] - cy) < 30:
                if random.random() < 0.025:
                    self._rest_ticks = random.randint(18, 90)
                    return
                self._target = (random.randint(screen.left() + 60, screen.right() - 60),
                                random.randint(screen.top() + 70, screen.bottom() - 60))
            target_x, target_y = self._target
        dx, dy = target_x - cx, target_y - cy
        if abs(dx) + abs(dy) < 8:
            return
        self.facing = 1 if dx >= 0 else -1
        if abs(dy) > abs(dx) * 1.1:
            self.direction = "up" if dy < 0 else "down"
        else:
            self.direction = "side"
        factor = 0.028 if self.mode == "follow" else 0.012
        mx = max(-5, min(5, int(dx * factor)))
        my = max(-4, min(4, int(dy * factor)))
        nx = max(screen.left(), min(screen.right() - self.width(), self.x() + mx))
        ny = max(screen.top(), min(screen.bottom() - self.height(), self.y() + my))
        self.move(nx, ny)

    def paintEvent(self, event) -> None:  # noqa: N802
        """Draw a lightweight text badge; deliberately never renders image assets."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        profile = {"gentle": (0.12, 0.075, 4.0), "bouncy": (0.17, 0.11, 7.0), "subtle": (0.075, 0.045, 2.0)}[self.animation_style]
        breath = 1.0 + math.sin(self._tick * profile[1]) * (0.009 if self.animation_style == "subtle" else 0.018) if self.animations_enabled else 1.0
        sway = math.sin(self._tick * 0.18) * profile[2] if self.animations_enabled and self.mood in ("wave", "happy") and not self.dragging else 0.0
        badge = QRectF(8, 58, self.width() - 16, 30)
        center = badge.center()
        painter.save()
        painter.translate(center.x() + sway, center.y())
        painter.scale(breath, breath)
        painter.translate(-center.x(), -center.y())
        from PySide6.QtGui import QLinearGradient
        gradient = QLinearGradient(badge.topLeft(), badge.bottomRight())
        gradient.setColorAt(0.0, QColor(244, 248, 255, 238))
        gradient.setColorAt(1.0, QColor(214, 229, 250, 238))
        border = QColor(117, 148, 192, 225)
        if self.mood in ("happy", "curious"):
            border = QColor(146, 115, 220, 235)
        elif self.mood == "sleepy":
            border = QColor(115, 139, 171, 220)
        painter.setPen(QPen(border, 1.4))
        painter.setBrush(gradient)
        painter.drawRoundedRect(badge, 14, 14)
        # A tiny procedural status dot replaces the former character image.
        dot_color = QColor(94, 184, 145)
        if self.mood in ("happy", "curious", "wave"):
            dot_color = QColor(151, 117, 230)
        elif self.mood in ("sleepy", "sleep"):
            dot_color = QColor(130, 151, 181)
        painter.setPen(QPen(Qt.PenStyle.NoPen))
        painter.setBrush(dot_color)
        painter.drawEllipse(QRectF(18, 68, 10, 10))
        painter.setPen(QColor(35, 49, 70))
        painter.setFont(QFont("Microsoft YaHei UI", 9, QFont.Weight.DemiBold))
        painter.drawText(QRectF(33, 61, self.width() - 45, 24), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, "星穹桌宠 · 文字模式")
        painter.restore()
        if self.bubble:
            self._draw_bubble(painter)
        painter.end()

    def _draw_bubble(self, painter: QPainter) -> None:
        text = self.bubble.replace("\n", " ")
        max_chars = max(8, min(22, (self.width() - 20) // 14))
        if len(text) > max_chars:
            text = text[:max_chars - 1] + "…"
        rect = QRectF(5, 4, self.width() - 10, 46)
        painter.setPen(QPen(QColor(180, 192, 210, 220), 1))
        painter.setBrush(QColor(255, 255, 255, 238))
        painter.drawRoundedRect(rect, 14, 14)
        painter.setPen(QColor(38, 48, 66))
        painter.setFont(QFont("Microsoft YaHei UI", 9))
        painter.drawText(rect.adjusted(8, 3, -8, -3), Qt.AlignmentFlag.AlignCenter, text)

    def enterEvent(self, event) -> None:  # noqa: N802
        self._is_hovered = True
        if not self.passthrough and not self.bubble:
            self.mood = "curious"
            self.mood_until = self._tick + 45
            self.say(random.choice(["嗯？", "找我吗？", "怎么了？"]), 2200)
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._is_hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = True
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self._drag_start = event.globalPosition().toPoint()
            self._last_position = self.pos()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self.dragging and event.buttons() & Qt.MouseButton.LeftButton:
            new_pos = event.globalPosition().toPoint() - self._drag_offset
            dx = new_pos.x() - self.x()
            if abs(dx) > 1:
                self.facing = 1 if dx > 0 else -1
                self.direction = "side"
            self.move(new_pos)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        moved = (event.globalPosition().toPoint() - self._drag_start).manhattanLength() > 8
        self.dragging = False
        self.petDropped.emit()
        if event.button() == Qt.MouseButton.LeftButton and not moved:
            if self._suppress_release_click:
                self._suppress_release_click = False
            else:
                self.mood = "curious"
                self.mood_until = self._tick + 45
                # Delay the single click so a double-click can cancel it cleanly.
                self._click_timer.start()
        event.accept()

    def mouseDoubleClickEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._click_timer.stop()
            self._suppress_release_click = True
            self.petDoubleClicked.emit()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)

    def contextMenuEvent(self, event) -> None:  # noqa: N802
        # Preserve QWidget's handling so CustomContextMenu emits its signal.
        super().contextMenuEvent(event)
