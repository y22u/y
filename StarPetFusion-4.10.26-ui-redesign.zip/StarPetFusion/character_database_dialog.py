from __future__ import annotations
from pathlib import Path
from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QComboBox, QLineEdit, QTextEdit, QPushButton, QLabel, QFileDialog, QMessageBox, QListWidget, QSplitter, QWidget
from character_database import CharacterDatabase

class CharacterDatabaseDialog(QDialog):
    """Edit character persona and import local images into the SQLite library."""
    def __init__(self, controller, parent=None):
        super().__init__(parent); self.controller=controller; self.db=CharacterDatabase()
        self.setWindowTitle('角色形象与设定数据库'); self.resize(780,560)
        root=QVBoxLayout(self); top=QHBoxLayout(); self.character=QComboBox()
        for c in self.db.characters(): self.character.addItem(c['name'],c['slug'])
        top.addWidget(QLabel('角色')); top.addWidget(self.character,1); root.addLayout(top)
        splitter=QSplitter(); left_widget=QWidget(); left=QVBoxLayout(left_widget); self.assets=QListWidget(); left.addWidget(QLabel('已导入素材')); left.addWidget(self.assets)
        right_widget=QWidget(); right=QVBoxLayout(right_widget); form=QFormLayout()
        self.setting=QTextEdit(); self.setting.setMaximumHeight(120); self.personality=QTextEdit(); self.personality.setMaximumHeight(100); self.voice=QLineEdit()
        form.addRow('角色设定',self.setting); form.addRow('性格标签',self.personality); form.addRow('语气风格',self.voice); right.addLayout(form)
        self.notice=QLabel('素材保存在用户数据目录；导入前请确认作者许可。'); self.notice.setWordWrap(True); right.addWidget(self.notice)
        btns=QHBoxLayout(); self.import_btn=QPushButton('导入角色图片…'); self.apply_btn=QPushButton('应用当前角色形象'); self.save_btn=QPushButton('保存设定')
        btns.addWidget(self.import_btn); btns.addWidget(self.apply_btn); btns.addWidget(self.save_btn); right.addLayout(btns)
        splitter.addWidget(left_widget); splitter.addWidget(right_widget); root.addWidget(splitter)
        self.character.currentIndexChanged.connect(self.load_character); self.import_btn.clicked.connect(self.import_asset); self.apply_btn.clicked.connect(self.apply_asset); self.save_btn.clicked.connect(self.save_profile); self.load_character()
    def closeEvent(self,event): self.db.close(); super().closeEvent(event)
    def slug(self): return str(self.character.currentData() or '')
    def load_character(self,*_):
        c=self.db.get_character(self.slug())
        if not c:return
        self.setting.setPlainText(c['setting']); self.personality.setPlainText(c['personality']); self.voice.setText(c['voice_style']); self.refresh_assets()
    def refresh_assets(self):
        self.assets.clear()
        for a in self.db.assets(self.slug()): self.assets.addItem(f"{'● ' if a['is_active'] else ''}{a['kind']} · {Path(a['path']).name} · {a['license']}")
    def import_asset(self):
        path,_=QFileDialog.getOpenFileName(self,'选择有权使用的角色图片',str(Path.home()),'图片 (*.png *.jpg *.jpeg *.webp *.bmp *.gif)')
        if not path:return
        try:
            dest=self.db.import_asset(self.slug(),path,kind='portrait',source_name='local import',license='user-provided / permission confirmed by user')
            portraits=self.controller.config.get('role_portraits',{}); portraits=dict(portraits) if isinstance(portraits,dict) else {}; portraits[self.slug()]=dest
            self.controller.config.set('role_portraits',portraits)
            self.notice.setText(f'已导入数据库：{dest}。来源和授权记录已写入 SQLite。'); self.refresh_assets()
        except Exception as exc: QMessageBox.warning(self,'导入失败',str(exc))
    def apply_asset(self):
        path=self.db.active_asset(self.slug(),'portrait')
        if not path: QMessageBox.information(self,'尚无形象','请先导入该角色的立绘/头像。'); return
        if self.controller.pet.set_appearance(path,announce=False):
            self.controller.active_role_slug=self.slug(); self.controller.config.set('default_role',self.slug()); self.controller.config.set('appearance_path',path); self.notice.setText('已应用当前角色形象。')
        else: QMessageBox.warning(self,'应用失败','图片格式无法读取，请尝试 PNG 或 WEBP。')
    def save_profile(self):
        self.db.update_profile(self.slug(),self.setting.toPlainText().strip(),self.personality.toPlainText().strip(),self.voice.text().strip())
        self.notice.setText('角色设定已保存到本地 SQLite 数据库。')
