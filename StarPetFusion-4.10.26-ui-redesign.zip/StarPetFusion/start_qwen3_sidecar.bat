@echo off
setlocal
cd /d "%~dp0"
if not exist ".venvs\qwen3\Scripts\python.exe" (
  echo Run install_isolated_tts.bat first.
  pause
  exit /b 1
)
set STAR_PET_TTS_SIDECAR_PROVIDER=qwen3
set STAR_PET_TTS_SIDECAR_PORT=8766
if not defined STAR_PET_QWEN3_TTS_MODEL set STAR_PET_QWEN3_TTS_MODEL=Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice
".venvs\qwen3\Scripts\python.exe" -m uvicorn isolated_tts.worker:app --app-dir "%CD%" --host 127.0.0.1 --port 8766
