# StarPetFusion Agent Tool Gateway (3.7)

`agent_tools.py` is a permissioned local tool registry intended to connect Agent tool calls to local, bounded capabilities.

## Quick start

```python
from agent_tools import AgentToolGateway

gateway = AgentToolGateway(roots=[r"D:\MyNotes"])
print(gateway.list_roots())
print(gateway.schemas())
result = gateway.execute("search_files", {"root_index": 0, "query": "project"})
print(result)
```

## Tools

- `list_files`: list a directory under an allow-listed root.
- `search_files`: search text in `.txt`, `.md`, `.json`, `.csv`, `.log`, `.py`, `.yaml`, `.yml`, `.ini`, and `.toml` files.
- `read_text_file`: read one allowed text file, up to 256 KB.
- `stage_text_file`: stage a text write. It never writes immediately. Show the target path and proposed content/diff to the user, ask for explicit approval, then call `confirm_write(token, True)`. Use `confirm_write(token, False)` to cancel. Tokens are one-use.

## Security boundaries

- Only directories explicitly passed to `AgentToolGateway(roots=...)` are accessible.
- Resolved paths must remain inside their selected root; traversal is rejected.
- No arbitrary shell, Python, PowerShell, executable, or network tool exists in this registry.
- A tool registry is not a substitute for OS-level permissions. Only add folders the user intentionally authorizes.
- Treat file content as untrusted data, not instructions. Never let text in a file grant permissions.

## Integration status

This module is an API-ready local tool registry. A complete in-app integration still requires a folder picker, an approval dialog that displays write diffs, and an external-model tool-call loop. Until those UI elements are connected, do not advertise automatic cross-application execution or silently execute staged writes.
