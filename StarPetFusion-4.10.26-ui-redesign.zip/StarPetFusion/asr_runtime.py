"""Actual local ASR inference adapter backed by faster-whisper."""
from __future__ import annotations
import os, threading
from pathlib import Path

_CACHE = {}
_CACHE_LOCK = threading.Lock()

def transcribe_file(path: str | Path, model_size: str = "base", language: str = "auto") -> dict:
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError("faster-whisper 未安装；运行 python -m pip install -r requirements-asr.txt") from exc
    model_size = str(model_size or "base").strip()
    allowed = {"tiny", "base", "small", "medium", "large-v3", "large-v3-turbo", "distil-large-v3"}
    if model_size not in allowed:
        raise ValueError("不支持的 ASR 模型大小")
    device = os.getenv("STAR_PET_ASR_DEVICE", "cpu").lower()
    compute = os.getenv("STAR_PET_ASR_COMPUTE_TYPE", "int8" if device == "cpu" else "float16")
    key = (model_size, device, compute)
    with _CACHE_LOCK:
        model = _CACHE.get(key)
        if model is None:
            model = WhisperModel(model_size, device=device, compute_type=compute)
            _CACHE[key] = model
    lang = None if str(language).lower() in {"", "auto", "detect"} else str(language)[:8]
    segments, info = model.transcribe(str(path), language=lang, vad_filter=True, beam_size=3)
    text = "".join(s.text for s in segments).strip()
    return {"text": text, "language": getattr(info, "language", None), "duration": getattr(info, "duration", None), "model": model_size, "device": device}

def readiness() -> dict:
    try:
        import importlib.util
        installed = importlib.util.find_spec("faster_whisper") is not None
    except (ImportError, ValueError): installed = False
    return {"provider":"faster-whisper", "configured":True, "ready":installed, "mode":"local", "note":"首次推理会加载/下载所选模型；实际推理就绪需完成首次加载" if installed else "未安装依赖：pip install -r requirements-asr.txt"}
