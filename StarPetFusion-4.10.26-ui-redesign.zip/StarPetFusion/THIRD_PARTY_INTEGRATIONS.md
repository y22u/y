# StarPetFusion 2.9：大模型成长与第三方接入

## 大模型
现有 AI 设置支持 OpenAI-compatible `/chat/completions` 接口，可连接云端模型或本地 Ollama。模型供应商、模型名和 API Key 应以服务商当前文档为准。API Key 建议使用 `STAR_PET_API_KEY` 环境变量，不要提交到 Git。

## 可审核的角色成长
- 角色记忆与反馈保存在用户配置目录的 `growth.sqlite3`，不写入角色原始资料。
- 用户可手动添加/删除记忆；只有开启 `learning_enabled` 才会将记忆上下文附加到模型请求。
- 用户可对回答反馈“有帮助/需要改进”；大模型据近期对话和反馈生成改进建议。
- 建议必须手动确认，并需复制到角色补充设定后才会影响角色；不会自动改写代码、安装依赖或扩大权限。
- 关闭联网权限后，不应向远程模型发送对话。云端模型会接收请求中的上下文，请勿发送密码、令牌或不愿外传的个人信息。

## 第三方 TTS / 动画 webhook（默认关闭）
首次运行前，用户可以在应用配置目录创建 `integrations.json`。只允许 HTTPS 或 localhost/127.0.0.1 的 HTTP 地址；外部集成默认禁用。

```json
{
  "tts": {
    "enabled": false,
    "endpoint": "https://your-tts-provider.example/v1/speech",
    "api_key_env": "STAR_PET_TTS_API_KEY"
  },
  "animation": {
    "enabled": false,
    "webhook_url": "http://127.0.0.1:8765/starpet/animation"
  }
}
```

TTS endpoint 需接受 `POST` JSON `{ "text": "...", "role": "..." }` 并返回 `audio/mpeg`、`audio/wav`、`audio/ogg` 或 `audio/mp4` 二进制音频；应用会调用系统默认播放器打开返回音频。设置 `STAR_PET_TTS_API_KEY` 环境变量可添加 Bearer Token。启用前请确认服务商的隐私与计费规则，因为文本会发送到配置的服务端。

动画 webhook 仅发送 `{ "event": "character_animation_state", "role": "...", "state": "..." }`，不发送聊天文本或本地文件路径。接收端需由用户自行安装和配置，建议只绑定回环地址并校验请求来源。

## 权限边界
应用内权限是功能开关，不是系统级沙箱。第三方插件不应自动执行任意命令、读取任意目录或自行下载运行代码。外部操作需逐项授权并在执行前确认。
