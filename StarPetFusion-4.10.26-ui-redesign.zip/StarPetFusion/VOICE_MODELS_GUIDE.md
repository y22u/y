# StarPetFusion 4.2 — Edge TTS / Qwen3-TTS / IndexTTS 接入指南

## 先立即使用：Edge TTS（无需 API Key）

Edge TTS 使用 Microsoft Edge 在线语音服务，需网络连接；它不是离线模型，服务可用性由服务提供方控制。

在 StarPetFusion 项目根目录、与后端相同的 Python 环境中执行：

```powershell
python -m pip install -r requirements.txt
```

启动服务：

```powershell
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8765
```

浏览器打开 `http://127.0.0.1:8765/`，进入“语音与 TTS”，选择“Edge TTS（免费在线，无 API Key）”，音色默认 `zh-CN-XiaoxiaoNeural`，输入文字后点击生成并播放。其他常见中文音色可先用 `edge-tts --list-voices` 查看当前可用清单。

## Qwen3-TTS（开源本地模型）

Qwen3-TTS 的模型权重体积较大，需要下载模型并具备足够的内存/显存。建议创建独立测试环境，按官方仓库说明安装 `qwen-tts` 与 `soundfile`，确认官方示例可运行后，再将依赖安装到 StarPetFusion 服务环境；不要在未备份环境的情况下覆盖现有 PyTorch/CUDA 依赖。

官方项目：<https://github.com/QwenLM/Qwen3-TTS>

本适配器默认模型 ID：`Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`，可通过环境变量 `STAR_PET_QWEN3_TTS_MODEL` 覆盖。常见内置说话人包括 `Vivian`，以模型实际支持列表为准。首次生成可能触发权重下载，不能保证首次启动即离线可用。

安装（按官方指南确认当前硬件和 PyTorch 版本后再执行）：

```powershell
python -m pip install -U qwen-tts soundfile
```

## IndexTTS（开源本地模型）

IndexTTS 需要下载模型权重，并提供一段你有权使用的 WAV 参考音频。推荐按官方仓库的 `uv sync --all-extras` / `uv run webui.py` 工作流建立独立环境，先确认官方 WebUI 能成功合成，再配置本项目适配器。不同 IndexTTS 版本的 Python API 和硬件依赖可能不同；如遇依赖冲突，不要强行将其装进桌宠现有环境，建议改为独立本地 API 服务接入。

官方项目：<https://github.com/index-tts/index-tts>

配置环境变量示例（按实际路径修改）：

```powershell
$env:STAR_PET_INDEXTTS_MODEL_DIR="D:\Models\IndexTTS-2.5"
$env:STAR_PET_INDEXTTS_CONFIG="D:\Models\IndexTTS-2.5\config.yaml"
$env:STAR_PET_INDEXTTS_REFERENCE_WAV="D:\Voice\reference.wav"
```

也可在 TTS 页面“音色 / 参考音频路径”输入参考 WAV 的完整路径。请只使用自己录制或已获授权的参考声音；不要冒充真实人物或未经许可克隆他人声音。

## API 说明

`POST /api/v1/tts` 的 `provider` 支持：

- `edge`：在线 Edge TTS，返回 MP3。
- `qwen3`：本地 Qwen3-TTS，返回 WAV。
- `indextts`：本地 IndexTTS，返回 WAV。
- `google_cloud`、`gemini`、`external`：原有服务保持不变。

Edge TTS 最适合立即测试。Qwen3-TTS / IndexTTS 是本地模型接入，不会随项目 ZIP 自动携带大型模型权重，也不会在未安装模型依赖、下载权重或配置参考音频时自动可用。

## 角色专属音色预设（4.10.24）

`voice_profiles.json` 为每个内置角色维护独立的语速、音量、表达指令，以及 `engine_voices.edge` / `engine_voices.qwen3` 映射。角色聊天走混合语音路由时会优先读取这些设置；Qwen3-TTS 会收到完整的角色化表达指令，而不是仅收到 `elegant` / `warm` 这样的内部标签。角色、文本、语音引擎和表达指令都会参与音频缓存键，避免同一句文本误用另一角色的缓存音频。

- **Edge TTS**：在线合成；各角色选择不同的通用中文神经音色与语速。需要在隐私设置中显式开启在线 TTS，默认关闭。
- **Qwen3-TTS**：本地合成；角色使用模型支持的内置 speaker，并结合自然语言表达指令做风格区分。实际可用 speaker 名称以已安装模型版本为准。
- **IndexTTS**：支持通过角色 `engine_voices.indextts` 指向有权使用的本地参考 WAV；没有每角色独立参考音频时会使用环境变量配置的通用参考音频，不会假装每个角色已经拥有独立训练模型。
- **授权音频**：精确文本匹配的音频只有在 manifest 标记授权、SHA-256 一致且授权未过期时才会使用。

这些设置是通用合成声音的差异化演绎，不是游戏官方语音包，也不复制或冒充真实配音演员。若要更进一步实现每个角色稳定的音色克隆，需要为每个角色准备合法授权的参考音频、按对应模型的流程单独配置/训练，并逐个进行听感与授权审核；当前 ZIP 不包含大型 TTS 权重或未授权参考音频。
