@echo off
setlocal
cd /d "%~dp0"
if not exist "isolated_tts\IndexTTS\pyproject.toml" (
  echo Run install_isolated_tts.bat first.
  pause
  exit /b 1
)
set STAR_PET_TTS_SIDECAR_PROVIDER=indextts
set STAR_PET_TTS_SIDECAR_PORT=8767
if not defined STAR_PET_INDEXTTS_MODEL_DIR set STAR_PET_INDEXTTS_MODEL_DIR=%CD%\isolated_tts\IndexTTS\checkpoints
if not defined STAR_PET_INDEXTTS_CONFIG set STAR_PET_INDEXTTS_CONFIG=%STAR_PET_INDEXTTS_MODEL_DIR%\config.yaml
if not defined STAR_PET_INDEXTTS_REFERENCE_WAV set STAR_PET_INDEXTTS_REFERENCE_WAV=%CD%\isolated_tts\IndexTTS\examples\voice_01.wav
cd /d "%CD%\isolated_tts\IndexTTS"
uv run --project . python "%~dp0isolated_tts\worker.py"
