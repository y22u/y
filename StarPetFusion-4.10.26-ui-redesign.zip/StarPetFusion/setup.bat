@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher py was not found. Install Python 3.10+ and retry.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 goto :fail
)
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :fail
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :fail
.venv\Scripts\python.exe -m pip install -r requirements-service.txt
if errorlevel 1 goto :fail
.venv\Scripts\python.exe prepare.py
if errorlevel 1 (
  echo.
  echo WARNING: Optional character packs/images could not be downloaded.
  echo The default pet and local AI settings can still be used. Retry prepare.py when network is available.
)
echo.
echo Setup complete. Run start.bat to launch StarPetFusion.
pause
exit /b 0
:fail
echo Setup failed. Read the error above, check network access, and retry.
pause
exit /b 1
