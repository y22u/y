# StarPetFusion 4.10.19 — Ollama HTTP 模型中心

- 增加 Ollama 原生 HTTP 模型管理器：列出本地模型、查看管理端点、流式下载模型、确认后删除模型。
- AI 设置对话框加入模型刷新、选择、下载进度和删除操作；下载在后台线程执行，避免阻塞界面。
- 聊天推理继续使用 Ollama OpenAI-compatible HTTP API，按模型标签调用已安装模型；保留 DeepSeek、OpenAI 和自定义兼容服务。
- 模型管理端点限制为 localhost/127.0.0.1/::1 HTTP，防止模型管理操作误发到远程地址。
- 明确区分 Ollama LLM 管理和 TTS 语音适配器；角色音色档案仍与角色 ID 绑定，语音输出通过各自的 HTTP/本地适配器调用。
- 新增 Ollama URL 安全、模型列表与流式下载进度测试。
