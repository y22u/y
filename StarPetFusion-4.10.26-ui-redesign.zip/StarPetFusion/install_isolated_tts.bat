@echo off
setlocal
cd /d "%~dp0"
echo =====================================================
echo StarPetFusion 4.3 - isolated TTS environments
echo Qwen3-TTS and IndexTTS will use separate environments.
echo =====================================================
where py >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python Launcher 'py' not found. Install Python 3.12 and retry.
  pause
  exit /b 1
)
where git >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Git not found. Install Git for Windows and retry.
  pause
  exit /b 1
)
where uv >nul 2>nul
if errorlevel 1 (
  echo [INFO] Installing uv with pip...
  py -3.12 -m pip install --user uv
  if errorlevel 1 goto :fail
  set "PATH=%PATH%;%APPDATA%\Python\Python312\Scripts"
)
if not exist ".venvs\qwen3" (
  py -3.12 -m venv ".venvs\qwen3"
  if errorlevel 1 goto :fail
)
echo [1/4] Installing Qwen3-TTS only into .venvs\qwen3 ...
".venvs\qwen3\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail
".venvs\qwen3\Scripts\python.exe" -m pip install "qwen-tts" "fastapi" "uvicorn[standard]" "requests" "soundfile"
if errorlevel 1 goto :fail
if not exist "isolated_tts\IndexTTS\.git" (
  echo [2/4] Cloning official IndexTTS repository into isolated_tts\IndexTTS ...
  git clone https://github.com/index-tts/index-tts.git "isolated_tts\IndexTTS"
  if errorlevel 1 goto :fail
) else (
  echo [2/4] IndexTTS repository already exists; leaving it unchanged.
)
echo [3/4] Syncing IndexTTS dependencies in its own uv environment ...
cd /d "%~dp0isolated_tts\IndexTTS"
uv sync --extra webui
if errorlevel 1 (
  echo [WARN] uv sync --extra webui failed; trying documented default sync.
  uv sync
  if errorlevel 1 goto :fail
)
cd /d "%~dp0"
echo [4/4] Installation complete. Model weights may still need downloading.
echo Read isolated_tts\README.md before starting the services.
pause
exit /b 0
:fail
echo [ERROR] Installation failed. See the command output above. No existing project environment was modified intentionally.
pause
exit /b 1
