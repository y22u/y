# 开源形象项目调研与 StarPetFusion 接入方案

检索日期：2026-10-25。此文档记录可复查的公开仓库入口。代码许可与角色图像/模型许可必须分别判断；下载到本地不代表获得再分发授权。

## 1. 大肥鱼（鲸鱼娘）形象来源

### 推荐：1190fasheqi/dafeiyu-pet
- 仓库：https://github.com/1190fasheqi/dafeiyu-pet
- 说明：Python + PySide6 桌宠，提供正面/侧面/背面三视图流程和互动设计，可用于研究替换桌宠的呈现方式。
- 使用边界：仓库代码和形象素材要分别查看 LICENSE/README；StarPetFusion 不直接复制其图片到发行包。运行 `python download_dafeiyu_assets.py` 会从已登记来源取得一个社区预览 GIF，并在用户数据目录记录来源和 SHA-256。

### 可参考：PC2005-cloud/dsh-pet
- 仓库：https://github.com/PC2005-cloud/dsh-pet
- 说明：透明动画桌宠及 DIY 素材链；README 对代码与素材分别说明许可。当前下载器只获取单个预览 GIF，不会整仓复制素材。
- 形象来源和许可声明：社区二创形象并非 DeepSeek 官方形象。下载器写入 `ASSET_NOTICE.txt`，保留来源、许可提示和哈希。

### 可参考：C2006L/dafeiyu
- 仓库：https://github.com/C2006L/dafeiyu
- 说明：Electron/TypeScript 版大肥鱼桌宠，可参考其透明动画与 AI 后端接入设计。代码采用 MIT；其形象资产仍应单独确认来源与授权。

## 2. 崩坏：星穹铁道角色形象

### 角色图片索引：Mar-7th/StarRailRes
- 仓库：https://github.com/Mar-7th/StarRailRes
- 用途：通过 `download_hsr_assets.py` 按角色 slug 搜索公开仓库树并下载少量图片候选；默认是大黑塔、阿格莱雅、海瑟音。
- 接入方式：下载后保存在 `character_assets/<角色slug>/`；桌宠右键 →「切换桌宠外观」可选择图片，或为当前角色设置专属立绘。
- 注意：该仓库中游戏相关图像不因代码仓库公开而自动变成可任意再分发素材。下载器只做本地候选导入，并将 `license_review_required=true`、`redistribution_allowed=false` 写入索引。对外分发前需核查每个素材来源与适用规则。

### 3D 模型浏览参考：YCL0609/HSR-model-show
- 仓库：https://github.com/YCL0609/HSR-model-show
- 用途：浏览/研究角色模型展示方式。仓库说明官方模型和角色插画权利属于 HoYoverse；MIT 等代码许可不覆盖游戏角色资产。StarPetFusion 不会自动抓取模型或将模型转换成桌宠贴图。

### 3D 资源工具参考：HoyoToon-Assets
- 仓库：https://github.com/Hoyotoon/HoyoToon-Assets
- 用途：研究模型渲染与资源组织。仓库已归档，页面提示资源存在法律相关限制；不作为默认自动下载来源，也不将其拆包资源纳入发行包。

## 3. 在 StarPetFusion 中应用

### 下载并启用大肥鱼预览形象
```powershell
python download_dafeiyu_assets.py
```

成功后下载器会：
1. 将 GIF 保存到用户数据目录 `%APPDATA%/StarPetFusion/character_assets/dafeiyu/`（非 Windows 系统使用 `~/.config/StarPetFusion/`）。
2. 写入 `ASSET_NOTICE.txt` 与 SHA-256。
3. 登记到角色素材数据库并设置 `appearance_path` 和 `default_role=dafeiyu`。
4. 提示重启应用。若网络或上游路径变化导致下载失败，程序会保留当前形象，不会伪称替换成功。

### 下载崩铁角色图片候选
```powershell
python download_hsr_assets.py --character the-herta --character aglaea --character hysilens --limit-per-character 2
```

其他受支持 slug 见脚本中的 `ALIASES`。下载后在桌宠右键菜单中选择图片。想使用自己制作或明确获授权的立绘，也可以通过「为当前角色设置专属立绘…」导入本地 PNG/JPG/GIF。

## 4. 重要说明
- 本次发行包不内嵌任何新下载的第三方大肥鱼/崩铁立绘；素材需要用户主动下载或导入。这避免将授权不清楚的素材再分发。
- 大肥鱼的 CC BY-NC-SA 等条件可能限制商业用途，并要求署名及相同方式共享；分享改编素材前应阅读对应仓库的当前许可声明。
- 《崩坏：星穹铁道》官方角色、立绘和模型并不因“开源项目”而成为公有领域内容。优先使用自制、授权明确或仅在当地规则允许范围内的个人本地素材。
