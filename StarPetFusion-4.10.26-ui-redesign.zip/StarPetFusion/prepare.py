from __future__ import annotations

import argparse
import http.client
import io
import json
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / "vendor"
SOURCES = {
    "TheHerta-CodexPet": "https://codeload.github.com/UniquenlOvE/TheHerta-CodexPet/zip/refs/heads/main",
    "hsr-skills": (
        "https://codeload.github.com/gblw2233/hsr-skills/zip/refs/heads/master",
        "https://codeload.github.com/gblw2233/hsr-skills/zip/refs/heads/main",
    ),
    "dafeiyu-pet": "https://codeload.github.com/1190fasheqi/dafeiyu-pet/zip/refs/heads/main",
}


def download(url: str, timeout: int = 90, retries: int = 4) -> bytes:
    """Download an archive with bounded retries for transient/truncated connections."""
    last_error: Exception | None = None
    for attempt in range(1, retries + 1):
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": "StarPetFusion-setup/1.2",
                "Accept": "application/zip, application/octet-stream, */*",
                "Connection": "close",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                payload = response.read()
                if not payload:
                    raise RuntimeError("服务器返回了空文件。")
                # GitHub codeload archives must be valid ZIP files; detect incomplete reads
                # before they can replace an existing local vendor pack.
                with zipfile.ZipFile(io.BytesIO(payload)) as archive:
                    if not archive.infolist():
                        raise RuntimeError("下载结果是空压缩包。")
                return payload
        except (urllib.error.URLError, TimeoutError, http.client.IncompleteRead,
                ConnectionError, OSError, zipfile.BadZipFile, RuntimeError) as exc:
            last_error = exc
            if attempt >= retries:
                break
            delay = min(2 ** (attempt - 1), 8)
            print(f"[重试] 下载中断或文件不完整（{attempt}/{retries}）：{exc}；{delay} 秒后重试。", file=sys.stderr)
            time.sleep(delay)
    raise RuntimeError(f"连续 {retries} 次下载未成功：{last_error}")


def source_urls(source: str | tuple[str, ...]) -> tuple[str, ...]:
    return (source,) if isinstance(source, str) else tuple(source)


def validate_role_pack(path: Path, required: bool = False) -> int:
    """Count role cards and optionally reject empty/incomplete hsr-skills downloads."""
    role_dirs = [p for p in path.iterdir() if p.is_dir() and (p / "SKILL.md").is_file()]
    if not role_dirs and required:
        raise RuntimeError("压缩包已下载，但没有找到任何包含 SKILL.md 的角色资料；保留原有资料不变。")
    return len(role_dirs)


def safe_extract(zip_bytes: bytes, target: Path) -> None:
    """Extract a GitHub archive while rejecting absolute/path-traversal members."""
    if len(zip_bytes) > 80 * 1024 * 1024:
        raise RuntimeError("下载包超过 80 MiB，已停止解压。")
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
        members = archive.infolist()
        if not members:
            raise RuntimeError("下载到的压缩包为空。")
        total_unpacked = sum(member.file_size for member in members)
        if total_unpacked > 200 * 1024 * 1024:
            raise RuntimeError("压缩包展开后超过 200 MiB，已停止解压。")
        first_parts = PurePosixPath(members[0].filename).parts
        prefix = first_parts[0] if first_parts else ""
        target_resolved = target.resolve()
        for item in members:
            source_path = PurePosixPath(item.filename)
            parts = source_path.parts
            if source_path.is_absolute() or ".." in parts:
                raise RuntimeError(f"压缩包含不安全路径：{item.filename}")
            if not parts or parts[0] != prefix or len(parts) == 1:
                continue
            relative = Path(*parts[1:])
            if not relative.parts:
                continue
            destination = (target / relative).resolve()
            if destination != target_resolved and target_resolved not in destination.parents:
                raise RuntimeError(f"压缩包路径超出目标目录：{item.filename}")
            if item.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(item, "r") as src, destination.open("wb") as dst:
                shutil.copyfileobj(src, dst)


def main() -> int:
    parser = argparse.ArgumentParser(description="下载并准备三个上游开源项目的本地素材与角色资料")
    parser.add_argument("--force", action="store_true", help="替换已存在的 vendor 目录（会删除该目录后重新下载）")
    args = parser.parse_args()
    VENDOR.mkdir(parents=True, exist_ok=True)
    failed: list[str] = []
    summaries: list[str] = []
    for name, source in SOURCES.items():
        target = VENDOR / name
        if target.exists() and any(target.iterdir()) and not args.force:
            try:
                count = validate_role_pack(target, required=(name == "hsr-skills"))
                suffix = f"（识别到 {count} 个角色）" if name == "hsr-skills" else ""
                print(f"[跳过] {name} 已存在{suffix}；需要更新请使用 --force。")
                summaries.append(f"{name}: 已使用本地缓存{suffix}")
                continue
            except Exception as exc:
                print(f"[警告] {name} 本地缓存不完整：{exc}；尝试重新下载。", file=sys.stderr)
        succeeded = False
        last_error: Exception | None = None
        for url in source_urls(source):
            print(f"[下载] {name}（{url.rsplit('/', 1)[-1]}）...")
            staging: Path | None = None
            try:
                payload = download(url)
                staging = Path(tempfile.mkdtemp(prefix=f".{name}-staging-", dir=VENDOR))
                safe_extract(payload, staging)
                count = validate_role_pack(staging, required=True) if name == "hsr-skills" else 0
                # Keep the previous usable data until the new archive is downloaded and validated.
                backup = VENDOR / f".{name}-previous"
                if backup.exists():
                    shutil.rmtree(backup, ignore_errors=True)
                if target.exists():
                    target.rename(backup)
                try:
                    staging.rename(target)
                    staging = None
                except Exception:
                    if backup.exists() and not target.exists():
                        backup.rename(target)
                    raise
                if backup.exists():
                    shutil.rmtree(backup, ignore_errors=True)
                suffix = f"；识别到 {count} 个角色" if name == "hsr-skills" else ""
                print(f"[完成] {name}：{target}{suffix}")
                summaries.append(f"{name}: 下载成功{suffix}")
                succeeded = True
                break
            except Exception as exc:
                last_error = exc
                print(f"[失败] {name} 来源 {url}: {exc}", file=sys.stderr)
            finally:
                if staging is not None and staging.exists():
                    shutil.rmtree(staging, ignore_errors=True)
        if not succeeded:
            failed.append(f"{name}: {last_error or '所有下载源均失败'}")
    if failed:
        print("\n部分来源下载失败：\n- " + "\n- ".join(failed), file=sys.stderr)
        print("请检查网络后重新运行 python prepare.py。", file=sys.stderr)
        return 1
    print("\n准备结果：\n- " + "\n- ".join(summaries))
    print("素材与角色资料已准备好。下一步运行：python main.py")
    print("若只想安装大黑塔到 Codex，可运行：python install_herta_pet.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
