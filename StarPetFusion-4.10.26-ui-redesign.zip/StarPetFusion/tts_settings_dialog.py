from __future__ import annotations
import json
from PySide6.QtWidgets import QDialog,QVBoxLayout,QFormLayout,QComboBox,QLineEdit,QCheckBox,QSpinBox,QDoubleSpinBox,QPushButton,QHBoxLayout,QLabel,QMessageBox
from PySide6.QtCore import QObject, Signal, QThread, QUrl
from PySide6.QtGui import QDesktopServices
from config_store import app_data_dir
from pathlib import Path
import tempfile

class _EdgeTestWorker(QThread):
    finished_result = Signal(bool, str)
    def __init__(self, voice, language, speed, timeout, parent=None):
        super().__init__(parent); self.voice=voice; self.language=language; self.speed=speed; self.timeout=timeout
    def run(self):
        try:
            from tts_adapters import EdgeTTSAdapter
            target = Path(tempfile.gettempdir()) / 'starpetfusion-edge-tts-test.mp3'
            result = EdgeTTSAdapter(timeout=self.timeout).synthesize('你好，这是 StarPetFusion 的 Edge TTS 服务测试。', target, voice=self.voice, language=self.language, speed=self.speed)
            self.finished_result.emit(True, str(result))
        except Exception as exc:
            self.finished_result.emit(False, str(exc))

class TTSSettingsDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle('语音 TTS 服务设置'); self.resize(620,500)
        self.path=app_data_dir()/'integrations.json'
        try: self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
        except (OSError,ValueError): self.data={}
        cfg=self.data.get('tts',{}) if isinstance(self.data,dict) else {}
        root=QVBoxLayout(self); root.addWidget(QLabel('选择已接入的 TTS 服务。Edge TTS 免费在线使用、无需 API Key，但需要联网；本地模型需先启动对应服务。云端服务的密钥仅通过系统环境变量读取。'))
        form=QFormLayout(); root.addLayout(form)
        self.enabled=QCheckBox('启用所选 TTS 服务'); self.enabled.setChecked(bool(cfg.get('enabled',True))); form.addRow('状态',self.enabled)
        self.provider=QComboBox(); self.provider.addItem('Edge TTS（免费在线，无 API Key）','edge'); self.provider.addItem('Qwen3-TTS（本地开源模型服务）','qwen3'); self.provider.addItem('IndexTTS（本地开源模型服务）','indextts'); self.provider.addItem('Gemini API · gemini-2.5-flash-preview-tts','gemini_api'); self.provider.addItem('Google Cloud TTS（ADC，可能收费）','google_cloud'); self.provider.addItem('通用第三方接口','external'); idx=self.provider.findData(cfg.get('provider','edge')); self.provider.setCurrentIndex(max(0,idx)); form.addRow('服务类型',self.provider)
        self.model=QLineEdit(str(cfg.get('model',''))); form.addRow('模型 ID（本地/云端服务可选）',self.model)
        self.keyenv=QLineEdit(str(cfg.get('api_key_env','GEMINI_API_KEY'))); form.addRow('API Key 环境变量',self.keyenv)
        self.projectenv=QLineEdit(str(cfg.get('project_env','GOOGLE_CLOUD_PROJECT'))); form.addRow('Cloud 项目环境变量',self.projectenv)
        self.location=QComboBox(); self.location.addItems(['global','us','eu','northamerica-northeast1']); self.location.setCurrentText(str(cfg.get('location','global'))); form.addRow('Cloud 区域',self.location)
        self.endpoint=QLineEdit(str(cfg.get('endpoint','https://YOUR_TTS_HOST/v1/audio/speech'))); form.addRow('第三方接口地址',self.endpoint)
        self.voice=QLineEdit(str(cfg.get('voice','Kore'))); form.addRow('音色名称',self.voice)
        self.language=QLineEdit(str(cfg.get('language','zh-CN'))); form.addRow('语言代码',self.language)
        self.style=QLineEdit(str(cfg.get('style','Speak naturally'))); form.addRow('语音风格提示',self.style)
        self.speed=QDoubleSpinBox(); self.speed.setRange(.5,2.0); self.speed.setSingleStep(.1); self.speed.setValue(float(cfg.get('speed',1.0))); form.addRow('语速倍率',self.speed)
        self.timeout=QSpinBox(); self.timeout.setRange(5,180); self.timeout.setValue(int(cfg.get('timeout',60))); form.addRow('请求超时（秒）',self.timeout)
        self.status=QLabel('Edge TTS：无需密钥，需联网和 edge-tts 依赖。Gemini API 需 GEMINI_API_KEY；Google Cloud 使用 ADC，可能产生费用。Qwen3/IndexTTS 需先启动各自独立服务。'); self.status.setWordWrap(True); root.addWidget(self.status)
        row=QHBoxLayout(); root.addLayout(row); self.test_button=QPushButton('测试 Edge TTS'); self.test_button.clicked.connect(self.test_edge_tts); row.addWidget(self.test_button); save=QPushButton('保存设置'); save.clicked.connect(self.save); row.addStretch(1); row.addWidget(save)
        if not cfg.get('voice') and self.provider.currentData() == 'edge':
            self.voice.setText('zh-CN-XiaoxiaoNeural')
        self.provider.currentIndexChanged.connect(self._defaults)
        self._update_test_button()
    def test_edge_tts(self):
        if self.provider.currentData() != 'edge':
            QMessageBox.information(self, 'Edge TTS 测试', '请先将服务类型切换为 Edge TTS。')
            return
        self.test_button.setEnabled(False)
        self.status.setText('正在连接 Edge TTS 并生成测试语音…请保持联网。')
        self._test_worker = _EdgeTestWorker(
            self.voice.text().strip() or 'zh-CN-XiaoxiaoNeural',
            self.language.text().strip() or 'zh-CN', self.speed.value(), self.timeout.value(), self)
        self._test_worker.finished_result.connect(self._finish_edge_test)
        self._test_worker.start()

    def _finish_edge_test(self, ok, detail):
        self.test_button.setEnabled(True)
        if ok:
            self.status.setText('Edge TTS 测试成功，正在打开生成的测试音频。')
            QDesktopServices.openUrl(QUrl.fromLocalFile(detail))
        else:
            self.status.setText('Edge TTS 测试失败：' + detail)

    def _defaults(self):
        provider=self.provider.currentData()
        self._update_test_button()
        if provider=='edge':
            self.model.setText(''); self.keyenv.setText(''); self.voice.setText('zh-CN-XiaoxiaoNeural'); self.language.setText('zh-CN')
        elif provider=='qwen3':
            self.model.setText('Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice'); self.keyenv.setText(''); self.voice.setText('Vivian'); self.language.setText('zh-CN')
        elif provider=='indextts':
            self.model.setText('local-sidecar'); self.keyenv.setText(''); self.language.setText('zh-CN')
        elif provider=='gemini_api': self.model.setText('gemini-2.5-flash-preview-tts'); self.keyenv.setText('GEMINI_API_KEY')
        elif provider=='google_cloud': self.model.setText('gemini-2.5-flash-tts'); self.keyenv.setText('STAR_PET_TTS_API_KEY')
    def _update_test_button(self):
        if hasattr(self, 'test_button'):
            self.test_button.setEnabled(self.provider.currentData() == 'edge')

    def save(self):
        provider=str(self.provider.currentData()); env=self.keyenv.text().strip(); project=self.projectenv.text().strip()
        if str(self.provider.currentData()) in {'gemini_api','google_cloud','external'} and (not env or not env.isidentifier()): QMessageBox.warning(self,'配置无效','当前服务的环境变量名称必须是有效标识符。'); return
        if project and not project.isidentifier(): QMessageBox.warning(self,'配置无效','Cloud 项目环境变量名称必须是有效标识符。'); return
        cfg={'enabled':self.enabled.isChecked(),'provider':provider,'model':self.model.text().strip(),'api_key_env':env,'project_env':project,'location':self.location.currentText(),'endpoint':self.endpoint.text().strip(),'mode':'openai_compatible','voice':self.voice.text().strip() or 'Kore','language':self.language.text().strip() or 'zh-CN','style':self.style.text().strip() or 'Speak naturally','speed':self.speed.value(),'timeout':self.timeout.value()}
        if provider=='external' and not cfg['endpoint'].startswith('https://') and not cfg['endpoint'].startswith(('http://localhost','http://127.0.0.1','http://[::1]')):
            QMessageBox.warning(self,'接口地址无效','第三方接口必须使用 HTTPS 或本机回环 HTTP。'); return
        self.data=self.data if isinstance(self.data,dict) else {}; self.data['tts']=cfg
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True); tmp=self.path.with_suffix('.json.tmp'); tmp.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(self.path)
        except OSError as exc: QMessageBox.warning(self,'保存失败',str(exc)); return
        self.accept()
