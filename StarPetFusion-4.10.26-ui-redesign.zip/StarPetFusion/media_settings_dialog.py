from __future__ import annotations
import json, shutil
from pathlib import Path
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QCheckBox,QSlider,QPushButton,QFileDialog,QMessageBox,QFormLayout)
from PySide6.QtCore import Qt
from config_store import app_data_dir
from voice_service import speak_async, load_profiles

STATES = {"idle":"待机", "happy":"开心", "think":"思考", "sleep":"睡觉"}
class MediaSettingsDialog(QDialog):
    def __init__(self, config, roles, parent=None):
        super().__init__(parent); self.config=config; self.roles=roles; self.setWindowTitle("角色语音与动画资源"); self.resize(520,390)
        root=QVBoxLayout(self); form=QFormLayout(); root.addLayout(form)
        self.voice=QCheckBox("启用 AI 回复语音朗读"); self.voice.setChecked(bool(config.get("voice_enabled",False))); form.addRow("语音输出",self.voice)
        self.role=QComboBox()
        for r in roles: self.role.addItem(r.name, r.slug)
        wanted=str(config.get("default_role","")); idx=self.role.findData(wanted); self.role.setCurrentIndex(max(0,idx)); form.addRow("角色",self.role)
        self.rate=QSlider(Qt.Orientation.Horizontal); self.rate.setRange(70,130); self.rate.setValue(100); form.addRow("语速倍率",self.rate)
        self.volume=QSlider(Qt.Orientation.Horizontal); self.volume.setRange(0,100); self.volume.setValue(90); form.addRow("音量",self.volume)
        self.state=QComboBox()
        for k,v in STATES.items(): self.state.addItem(v,k)
        form.addRow("动画状态",self.state)
        self.status=QLabel("支持 GIF、PNG、JPG、WEBP、BMP。每个角色、每种状态独立保存。GIF 会尝试动态播放。")
        self.status.setWordWrap(True); root.addWidget(self.status)
        row=QHBoxLayout(); root.addLayout(row)
        imp=QPushButton("导入动画资源…"); imp.clicked.connect(self.import_asset); row.addWidget(imp)
        test=QPushButton("测试语音"); test.clicked.connect(self.test_voice); row.addWidget(test)
        row.addStretch(1); save=QPushButton("保存并关闭"); save.clicked.connect(self.accept); row.addWidget(save)
    def import_asset(self):
        slug=self.role.currentData(); state=self.state.currentData()
        path,_=QFileDialog.getOpenFileName(self,"选择角色动画资源",str(Path.home()),"动画/图片 (*.gif *.png *.jpg *.jpeg *.webp *.bmp)")
        if not path: return
        src=Path(path); dest_dir=app_data_dir()/"role_animations"/str(slug); dest_dir.mkdir(parents=True,exist_ok=True)
        dest=dest_dir/(str(state)+src.suffix.lower())
        try: shutil.copy2(src,dest)
        except OSError as e: QMessageBox.warning(self,"导入失败",str(e)); return
        mapping=self.config.get("role_animation_assets",{}); mapping=mapping if isinstance(mapping,dict) else {}
        mapping.setdefault(str(slug),{})[str(state)]=str(dest); self.config.set("role_animation_assets",mapping)
        self.status.setText(f"已导入：{slug} / {STATES[state]}\n{dest}")
    def test_voice(self):
        self.config.set("voice_enabled",self.voice.isChecked())
        slug=str(self.role.currentData() or "default"); profiles=load_profiles(); profile=profiles.get(slug,profiles.get("default",{})).copy()
        profile["rate"]=self.rate.value()/100; profile["volume"]=self.volume.value()/100
        profiles[slug]=profile
        try: (Path(__file__).resolve().parent/"voice_profiles.json").write_text(json.dumps(profiles,ensure_ascii=False,indent=2),encoding="utf-8")
        except OSError as e: QMessageBox.warning(self,"保存语音配置失败",str(e)); return
        speak_async("你好，这是当前角色的语音测试。",slug,self.voice.isChecked())
    def accept(self):
        self.config.set("voice_enabled",self.voice.isChecked())
        slug=str(self.role.currentData() or "default"); profiles=load_profiles(); profile=profiles.get(slug,profiles.get("default",{})).copy()
        profile["rate"]=self.rate.value()/100; profile["volume"]=self.volume.value()/100; profiles[slug]=profile
        try: (Path(__file__).resolve().parent/"voice_profiles.json").write_text(json.dumps(profiles,ensure_ascii=False,indent=2),encoding="utf-8")
        except OSError as e: QMessageBox.warning(self,"保存失败",str(e)); return
        super().accept()
