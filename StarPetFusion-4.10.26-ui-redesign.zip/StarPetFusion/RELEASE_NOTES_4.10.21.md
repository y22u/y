# StarPetFusion 4.10.21 — ASR runtime and concurrency

## Added
- Real local ASR inference endpoint: `POST /api/v1/asr/transcribe` accepts raw audio bytes (`audio/wav`, `audio/mpeg`, `audio/webm`, or `application/octet-stream`) and runs faster-whisper locally.
- ASR readiness endpoint: `GET /api/v1/asr/status` reports optional dependency readiness and ASR concurrency occupancy.
- Runtime diagnostics include ASR dependency readiness and current task concurrency counters.
- Model Hub UI can select ASR model/language, upload a local audio file, run transcription, and inspect runtime status.
- Bounded concurrency semaphores for chat, TTS, and ASR. Overloaded tasks return HTTP 429 rather than allowing unbounded resource use.
- ASR input capped at 25 MiB; temporary audio is removed after the request.

## Configuration
- Optional ASR install: `python -m pip install -r requirements-asr.txt`
- `STAR_PET_ASR_DEVICE=cpu` by default; set `cuda` only when compatible CUDA/CTranslate2 drivers are installed.
- `STAR_PET_ASR_COMPUTE_TYPE=int8` default on CPU; GPU defaults to `float16`.
- `STAR_PET_CHAT_CONCURRENCY=3`, `STAR_PET_TTS_CONCURRENCY=2`, `STAR_PET_ASR_CONCURRENCY=1`, `STAR_PET_MODEL_OPS_CONCURRENCY=2`.
- Concurrency values are bounded by safe application limits. Actual parallel model inference remains constrained by hardware and each runtime's own capabilities.

## Notes / limitations
- Ollama manages Ollama-supported LLM models; it does not natively manage arbitrary TTS/ASR runtime weights. ASR currently uses faster-whisper directly; Qwen3-TTS and IndexTTS remain isolated HTTP sidecars.
- First ASR run may download/load the selected Whisper model and can take longer. Model names available in the UI are `tiny`, `base`, `small`, `medium`, `large-v3`, `large-v3-turbo`, and `distil-large-v3`.
- This release does not automatically record from the microphone through the web UI; it provides file-based local ASR inference and retains the desktop push-to-talk path.
