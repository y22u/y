"""Hybrid voice routing for StarPetFusion.

Priority: verified licensed recording -> local Qwen3-TTS -> local IndexTTS ->
explicitly enabled online Edge TTS. OS TTS remains the final fallback in
voice_service.py. Online speech is opt-in because chat text leaves the device.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import date
from pathlib import Path
from typing import Any

import requests

from config_store import app_data_dir

logger = logging.getLogger(__name__)
ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = {
    "enabled": True,
    "allow_online": False,
    "priorities": ["licensed_audio", "qwen3", "indextts", "edge"],
    "timeout_seconds": 45,
    "sidecar_timeout_seconds": 240,
    "licensed_manifest": "licensed_audio/manifest.json",
    "cache_enabled": True,
}


def load_router_config() -> dict[str, Any]:
    """Load user settings, falling back to conservative defaults."""
    path = app_data_dir() / "voice_router.json"
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(loaded, dict):
            loaded = {}
    except (OSError, ValueError):
        loaded = {}
    cfg = {**DEFAULT_CONFIG, **loaded}
    valid = {"licensed_audio", "qwen3", "indextts", "edge"}
    priorities = cfg.get("priorities")
    cfg["priorities"] = [x for x in priorities if x in valid] if isinstance(priorities, list) else list(DEFAULT_CONFIG["priorities"])
    cfg["timeout_seconds"] = max(5, min(int(cfg.get("timeout_seconds", 45)), 120))
    cfg["sidecar_timeout_seconds"] = max(10, min(int(cfg.get("sidecar_timeout_seconds", 240)), 900))
    cfg["allow_online"] = bool(cfg.get("allow_online", False))
    cfg["enabled"] = bool(cfg.get("enabled", True))
    return cfg


def _normalize_text(text: str) -> str:
    return " ".join(str(text).strip().split())


def find_licensed_recording(text: str, role_slug: str, config: dict[str, Any] | None = None) -> Path | None:
    """Return only exact-text, hash-verified, in-date authorized audio entries."""
    cfg = config or load_router_config()
    manifest_path = (ROOT / str(cfg.get("licensed_manifest", DEFAULT_CONFIG["licensed_manifest"]))).resolve()
    try:
        # Do not allow manifest path traversal outside the project root.
        manifest_path.relative_to(ROOT.resolve())
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return None
    items = manifest.get("items", []) if isinstance(manifest, dict) else []
    if not isinstance(items, list):
        return None
    normalized = _normalize_text(text)
    today = date.today().isoformat()
    for item in items:
        if not isinstance(item, dict):
            continue
        if item.get("character_id") != str(role_slug) or not item.get("authorization_verified"):
            continue
        if _normalize_text(item.get("text_normalized", item.get("text", ""))) != normalized:
            continue
        expires = str(item.get("authorization_expires", "")).strip()
        if expires and expires < today:
            continue
        rel = str(item.get("path", "")).strip()
        if not rel:
            continue
        audio_path = (ROOT / rel).resolve()
        try:
            audio_path.relative_to(ROOT.resolve())
        except ValueError:
            continue
        if not audio_path.is_file() or audio_path.stat().st_size <= 0:
            continue
        expected = str(item.get("sha256", "")).lower().strip()
        if len(expected) != 64:
            continue
        digest = hashlib.sha256(audio_path.read_bytes()).hexdigest()
        if digest != expected:
            continue
        return audio_path
    return None


def _play(path: Path) -> bool:
    try:
        if sys.platform == "win32":
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except OSError as exc:
        logger.warning("Audio playback launch failed (%s)", type(exc).__name__)
        return False


def _sidecar_ready(endpoint: str, timeout: float = 1.0) -> bool:
    try:
        response = requests.get(endpoint.rstrip("/") + "/health", timeout=timeout)
        response.raise_for_status()
        body = response.json()
        return isinstance(body, dict) and body.get("status") == "ok"
    except (requests.RequestException, ValueError, TypeError):
        return False


def _synthesize(provider: str, text: str, role_slug: str, profile: dict[str, Any], cfg: dict[str, Any]) -> Path:
    from tts_adapters import EdgeTTSAdapter, IsolatedTTSAdapter
    temp_dir = Path(tempfile.gettempdir()) / "starpetfusion-audio"
    temp_dir.mkdir(parents=True, exist_ok=True)
    cache_key = hashlib.sha256(json.dumps({
        "provider": provider, "role": role_slug, "text": text,
        "language": profile.get("language", "zh-CN"),
        "rate": profile.get("rate", 1.0), "style": profile.get("style", "neutral"),
        "delivery_prompt": profile.get("delivery_prompt", profile.get("voice_hint", "")),
        "voice": (profile.get("engine_voices", {}) or {}).get(provider, ""),
    }, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    cache_dir = app_data_dir() / "voice_cache"
    if cfg.get("cache_enabled", True):
        for cached in cache_dir.glob(cache_key + ".*") if cache_dir.exists() else []:
            if cached.is_file() and cached.stat().st_size > 0:
                return cached
    fd, name = tempfile.mkstemp(prefix=f"{provider}_", suffix=".wav", dir=str(temp_dir))
    os.close(fd)
    target = Path(name)
    language = str(profile.get("language", "zh-CN"))
    speed = max(0.5, min(float(profile.get("rate", 1.0)), 1.5))
    style = str(profile.get("delivery_prompt", profile.get("voice_hint", profile.get("style", "neutral"))))
    voices = profile.get("engine_voices", {})
    voice = str(voices.get(provider, "")) if isinstance(voices, dict) else ""
    if provider == "qwen3":
        endpoint = os.environ.get("STAR_PET_QWEN3_TTS_ENDPOINT", "http://127.0.0.1:8766")
        if not _sidecar_ready(endpoint):
            raise RuntimeError("Qwen3-TTS sidecar unavailable")
        voice = voice or "Vivian"
        adapter = IsolatedTTSAdapter(endpoint, timeout=cfg["sidecar_timeout_seconds"])
    elif provider == "indextts":
        endpoint = os.environ.get("STAR_PET_INDEXTTS_ENDPOINT", "http://127.0.0.1:8767")
        if not _sidecar_ready(endpoint):
            raise RuntimeError("IndexTTS sidecar unavailable")
        adapter = IsolatedTTSAdapter(endpoint, timeout=cfg["sidecar_timeout_seconds"])
    elif provider == "edge":
        if not cfg["allow_online"]:
            raise RuntimeError("Online TTS disabled by privacy setting")
        voice = voice or "zh-CN-XiaoxiaoNeural"
        adapter = EdgeTTSAdapter(timeout=cfg["timeout_seconds"])
    else:
        raise ValueError(f"Unsupported voice provider: {provider}")
    try:
        generated = adapter.synthesize(text, target, voice=voice, language=language, style=style, speed=speed)
        if not generated.is_file() or generated.stat().st_size <= 0:
            raise RuntimeError("TTS engine returned an empty audio file")
        if cfg.get("cache_enabled", True):
            cache_dir.mkdir(parents=True, exist_ok=True)
            cached = cache_dir / (cache_key + generated.suffix.lower())
            shutil.copy2(generated, cached)
            if generated.parent == temp_dir and generated != cached:
                generated.unlink(missing_ok=True)
            # Keep the cache bounded: evict oldest files above 300 entries.
            cached_files = sorted((p for p in cache_dir.iterdir() if p.is_file()), key=lambda p: p.stat().st_mtime)
            for stale in cached_files[:-300]:
                stale.unlink(missing_ok=True)
            return cached
        return generated
    except Exception:
        target.unlink(missing_ok=True)
        raise


def route_and_play(text: str, role_slug: str, profile: dict[str, Any] | None = None) -> bool:
    """Try configured providers in priority order. Return True only if playback launched."""
    cfg = load_router_config()
    if not cfg["enabled"] or not _normalize_text(text):
        return False
    profile = profile if isinstance(profile, dict) else {}
    for provider in cfg["priorities"]:
        try:
            if provider == "licensed_audio":
                audio = find_licensed_recording(text, role_slug, cfg)
                if audio and _play(audio):
                    logger.info("Voice playback source=licensed_audio role=%s", role_slug)
                    return True
                continue
            if provider == "edge" and not cfg["allow_online"]:
                continue
            audio = _synthesize(provider, str(text)[:1200], role_slug, profile, cfg)
            if audio.is_file() and audio.stat().st_size > 0 and _play(audio):
                logger.info("Voice playback source=%s role=%s", provider, role_slug)
                return True
            logger.warning("Voice provider %s returned no playable audio", provider)
        except Exception as exc:
            logger.warning("Voice provider %s failed (%s); trying next provider", provider, type(exc).__name__)
    return False
