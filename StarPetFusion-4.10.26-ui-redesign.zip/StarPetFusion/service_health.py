from __future__ import annotations

"""Offline service/configuration checks shared by diagnostics and support tools."""
from dataclasses import dataclass, asdict
from typing import Any
from urllib.parse import urlparse


@dataclass(frozen=True)
class HealthCheck:
    name: str
    status: str  # PASS, WARN, FAIL, SKIP
    detail: str

    def as_dict(self) -> dict[str, str]:
        return asdict(self)


def validate_endpoint(url: str, allow_loopback_http: bool = True) -> bool:
    try:
        parsed = urlparse(str(url).strip())
        host = (parsed.hostname or "").lower()
        if parsed.scheme == "https" and host:
            return True
        return bool(allow_loopback_http and parsed.scheme == "http" and host in {"localhost", "127.0.0.1", "::1"})
    except ValueError:
        return False


def validate_ai_config(config: dict[str, Any]) -> list[HealthCheck]:
    provider = str(config.get("provider") or "deepseek").strip().lower()
    base_url = str(config.get("api_base_url") or "").strip()
    model = str(config.get("api_model") or "").strip()
    checks: list[HealthCheck] = []
    if not provider:
        checks.append(HealthCheck("ai.provider", "FAIL", "provider is empty"))
    else:
        checks.append(HealthCheck("ai.provider", "PASS", f"provider={provider}"))
    if not model:
        checks.append(HealthCheck("ai.model", "FAIL", "model ID is empty"))
    else:
        checks.append(HealthCheck("ai.model", "PASS", "model ID configured"))
    local = provider == "ollama" or "localhost" in base_url.lower() or "127.0.0.1" in base_url
    checks.append(HealthCheck("ai.endpoint", "PASS" if validate_endpoint(base_url) else "FAIL",
                              "local endpoint" if local and validate_endpoint(base_url) else
                              ("endpoint syntax accepted" if validate_endpoint(base_url) else "endpoint must be HTTPS or HTTP loopback")))
    return checks


def validate_integration_config(config: dict[str, Any]) -> list[HealthCheck]:
    checks: list[HealthCheck] = []
    tts = config.get("tts", {})
    tts = tts if isinstance(tts, dict) else {}
    enabled = bool(tts.get("enabled", False))
    provider = str(tts.get("provider", "external")).lower()
    if not enabled:
        checks.append(HealthCheck("tts", "SKIP", "TTS integration disabled"))
    elif provider in {"gemini_api", "google_cloud"}:
        checks.append(HealthCheck("tts", "PASS", f"native provider configured: {provider}; credentials not tested"))
    elif provider in {"external", "generic_json", "openai_compatible"}:
        endpoint = str(tts.get("endpoint", ""))
        valid = validate_endpoint(endpoint)
        checks.append(HealthCheck("tts.endpoint", "PASS" if valid else "FAIL",
                                  "endpoint syntax accepted" if valid else "endpoint must be HTTPS or HTTP loopback"))
    else:
        checks.append(HealthCheck("tts.provider", "WARN", f"unknown provider: {provider}"))
    agent = config.get("agent_tools", {})
    roots = agent.get("roots", []) if isinstance(agent, dict) else []
    checks.append(HealthCheck("agent.roots", "PASS" if isinstance(roots, list) else "FAIL",
                              f"authorized root entries={len(roots) if isinstance(roots, list) else 0}"))
    return checks


def main() -> int:
    """Print a secret-free offline report for AI and integration configuration."""
    import json
    from pathlib import Path
    from config_store import ConfigStore, app_data_dir

    config = ConfigStore().data
    checks = validate_ai_config(config)
    integration_path = app_data_dir() / "integrations.json"
    try:
        integration_config = json.loads(integration_path.read_text(encoding="utf-8")) if integration_path.exists() else {}
        if not isinstance(integration_config, dict):
            raise ValueError("root must be object")
        checks.extend(validate_integration_config(integration_config))
    except (OSError, ValueError) as exc:
        checks.append(HealthCheck("integrations.config", "FAIL", f"unreadable config ({type(exc).__name__})"))
    print(json.dumps([check.as_dict() for check in checks], ensure_ascii=False, indent=2))
    return 1 if any(check.status == "FAIL" for check in checks) else 0


if __name__ == "__main__":
    raise SystemExit(main())
