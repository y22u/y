@echo off
setlocal
cd /d "%~dp0"
if not exist "vendor\dafeiyu-pet\sprites" (
  echo Please run setup.bat first so that vendor sources are downloaded.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run setup.bat first.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m pip install pyinstaller
if errorlevel 1 goto :fail
.venv\Scripts\pyinstaller.exe --noconfirm --clean --windowed --onedir --name StarPetFusion --add-data "vendor;vendor" main.py
if errorlevel 1 goto :fail
echo Build complete: dist\StarPetFusion\StarPetFusion.exe
echo Keep the vendor folder packaged with the application; do not publish API keys or personal chat history.
pause
exit /b 0
:fail
echo Build failed. Check the error above.
pause
exit /b 1
