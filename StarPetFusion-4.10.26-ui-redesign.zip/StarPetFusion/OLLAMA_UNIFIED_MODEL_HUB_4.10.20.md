# StarPetFusion 4.10.20 — Unified Ollama Model Hub

## Changes
- Adds a unified Model Hub entry in the frontend for Ollama model listing, background pull jobs, deletion, and agent model assignment.
- Moves the existing TTS settings form into the unified hub so deployment and speech synthesis settings are presented together.
- Adds ASR service route/endpoint fields and persists them in `data/model_hub_assignments.json`.
- Ollama HTTP management remains loopback-only via `OllamaManager`.
- Chat requests can specify the selected model; if omitted, the saved Agent assignment or `STAR_PET_OLLAMA_MODEL` is used.
- Model pulls run on daemon worker threads so the UI request does not wait for a multi-GB download.

## Runtime limitation
Ollama is not a universal runtime for arbitrary TTS and ASR architectures. The hub centralizes configuration and deployment of Ollama-compatible models, but speech synthesis/recognition must use an Ollama model only if its runtime actually supports the required modality; otherwise use the configured local HTTP sidecar (e.g. Qwen3-TTS/IndexTTS or an ASR server). The ASR endpoint is a persisted route setting, not proof that an ASR server is installed or connected.

## Concurrency
StarPetFusion can issue independent HTTP requests concurrently, and pull operations run asynchronously. Actual parallel inference depends on Ollama's server settings, VRAM/RAM, model size, and supported parallelism. Multiple large models may be serialized or cause memory pressure on modest hardware.
