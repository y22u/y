# StarPetFusion 4.x 企业级重构说明

## 目标结构
- `frontend/`：独立 Web UI（HTML/CSS/JS），通过版本化 HTTP API 调用后端。
- `backend/app/`：FastAPI 服务层；负责健康状态、连接器元数据、Agent 调用与 TTS 请求。
- 根目录现有 PySide6 桌面宠物与角色/记忆/工具/数据安全模块保留，作为兼容桌面端与领域能力层；重构采用渐进式迁移，不一次性删除旧入口。
- `docs/`：部署、安全、迁移与验收说明。

## 两轮迭代
### Iteration 1 / 4.0 — Frontend/backend split
- 新增版本化 `/api/v1` 接口和独立 Web 工作台。
- Agent 与 TTS 统一经服务端网关调用。
- 新增服务健康检查与连接器目录。
- 服务默认绑定 `127.0.0.1:8765`，避免未经授权的 LAN 暴露。

### Iteration 2 / 4.1 — Connector & UX hardening
- 加入输入长度限制、请求超时（底层适配器）、安全错误摘要和不返回密钥的连接器状态。
- 重构导航为总览、Agent 对话、语音/TTS、服务连接、安全与权限五个页面。
- 连接器区明确显示认证类型，区分 Ollama 本地、Google Cloud ADC、Gemini API Key 与 OpenAI 兼容服务。
- 预留 OAuth/账号授权扩展点，但未伪装成已完成：每个服务商必须提供正式 OAuth/API 接口才可实现账号授权。Cloud TTS 与 Gemini API 的认证方式并不相同。

## 本地运行
```powershell
python -m pip install -r requirements-service.txt
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8765
```
打开 `http://127.0.0.1:8765/`。

## 安全边界与已知限制
- 这是单用户本机服务的架构预览，不是可直接公网部署的多租户 SaaS。
- 不要使用 `--host 0.0.0.0` 暴露服务。若要远程/多用户部署，必须增加用户身份认证、OAuth state/PKCE、CSRF/Origin 校验、速率限制、TLS、审计日志、密钥管理和权限隔离。
- 浏览器工作台的历史只保存在当前页面内存中；既有桌面端的角色记忆/数据库仍由原模块管理。
- Google Cloud TTS 仍需要 ADC、项目/API 权限及可能的结算设置；Gemini TTS 使用 `GEMINI_API_KEY`；并非所有服务只登录账号就能免费调用。
- TTS 模型/音色参数会随供应商变更，实际可用性须在目标账号和项目中验证。
- 外部 Agent 连接使用既有 `integrations.json` 配置；不要在 UI 或代码中写入密钥。

## 发布前验收
1. `python -m compileall -q backend`
2. `python -m unittest discover -s tests -q`
3. 安装 `requirements-service.txt` 后执行 `python -c "from backend.app.main import app; print(app.version)"`
4. 浏览器确认首页、健康状态、连接器列表能显示。
5. 对 Agent 和每种 TTS 做真实服务端到端测试（本次未连接用户账号，因此不宣称云端测试通过）。
6. 执行依赖许可审查、SBOM、密钥扫描与 Windows clean-install 测试。
