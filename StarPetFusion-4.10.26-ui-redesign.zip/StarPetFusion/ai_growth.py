from __future__ import annotations

"""Opt-in, local-first character memory and reviewable improvement proposals."""
import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

from config_store import app_data_dir


class GrowthStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (app_data_dir() / "growth.sqlite3")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT, role_slug TEXT NOT NULL,
                text TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(role_slug, text))""")
            db.execute("""CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT, role_slug TEXT NOT NULL,
                rating INTEGER NOT NULL, note TEXT NOT NULL, created_at TEXT NOT NULL)""")
            db.execute("""CREATE TABLE IF NOT EXISTS proposals (
                id INTEGER PRIMARY KEY AUTOINCREMENT, role_slug TEXT NOT NULL,
                text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL)""")

    @contextmanager
    def _connect(self):
        """Yield a SQLite connection and always close it after commit/rollback."""
        db = sqlite3.connect(self.path, timeout=5)
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def add_memory(self, slug: str, text: str) -> None:
        text = " ".join(str(text).split())[:1000]
        if not text:
            raise ValueError("记忆内容不能为空")
        with self._lock, self._connect() as db:
            db.execute("INSERT OR IGNORE INTO memories(role_slug,text,created_at) VALUES(?,?,?)",
                       (slug, text, datetime.now().isoformat(timespec="seconds")))

    def memories(self, slug: str, limit: int = 30) -> list[dict[str, Any]]:
        with self._lock, self._connect() as db:
            rows = db.execute("SELECT id,text,created_at FROM memories WHERE role_slug=? ORDER BY id DESC LIMIT ?",
                              (slug, max(1, min(int(limit), 100)))).fetchall()
        return [{"id": r[0], "text": r[1], "created_at": r[2]} for r in rows]

    def remove_memory(self, memory_id: int) -> None:
        with self._lock, self._connect() as db:
            db.execute("DELETE FROM memories WHERE id=?", (int(memory_id),))

    def context(self, slug: str, limit: int = 12) -> str:
        rows = self.memories(slug, limit)
        if not rows:
            return ""
        return "【用户明确允许保存的角色记忆】\n" + "\n".join(f"- {r['text']}" for r in reversed(rows)) + \
               "\n只在相关时使用这些信息；如果用户要求修改或删除，应尊重其要求。"

    def add_feedback(self, slug: str, rating: int, note: str = "") -> None:
        if int(rating) not in (-1, 1):
            raise ValueError("rating 只能是 -1 或 1")
        with self._lock, self._connect() as db:
            db.execute("INSERT INTO feedback(role_slug,rating,note,created_at) VALUES(?,?,?,?)",
                       (slug, int(rating), str(note).strip()[:1000], datetime.now().isoformat(timespec="seconds")))

    def feedback(self, slug: str, limit: int = 30) -> list[dict[str, Any]]:
        with self._lock, self._connect() as db:
            rows = db.execute("SELECT rating,note,created_at FROM feedback WHERE role_slug=? ORDER BY id DESC LIMIT ?",
                              (slug, max(1, min(int(limit), 100)))).fetchall()
        return [{"rating": r[0], "note": r[1], "created_at": r[2]} for r in rows]

    def add_proposal(self, slug: str, text: str) -> int:
        text = str(text).strip()[:5000]
        if not text:
            raise ValueError("改进建议不能为空")
        with self._lock, self._connect() as db:
            cur = db.execute("INSERT INTO proposals(role_slug,text,status,created_at) VALUES(?,?,?,?)",
                             (slug, text, "pending", datetime.now().isoformat(timespec="seconds")))
            return int(cur.lastrowid)

    def proposals(self, slug: str, pending_only: bool = False) -> list[dict[str, Any]]:
        sql = "SELECT id,text,status,created_at FROM proposals WHERE role_slug=?"
        args: list[Any] = [slug]
        if pending_only:
            sql += " AND status='pending'"
        sql += " ORDER BY id DESC LIMIT 50"
        with self._lock, self._connect() as db:
            rows = db.execute(sql, args).fetchall()
        return [{"id": r[0], "text": r[1], "status": r[2], "created_at": r[3]} for r in rows]

    def set_proposal_status(self, proposal_id: int, status: str) -> None:
        if status not in {"approved", "rejected"}:
            raise ValueError("非法建议状态")
        with self._lock, self._connect() as db:
            db.execute("UPDATE proposals SET status=? WHERE id=?", (status, int(proposal_id)))


def load_integrations(path: Path | None = None) -> dict[str, Any]:
    """Read user-configured integration endpoints. Disabled by default."""
    p = path or (app_data_dir() / "integrations.json")
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {"tts": {"enabled": False}, "animation": {"enabled": False}}
    except (OSError, ValueError):
        return {"tts": {"enabled": False}, "animation": {"enabled": False}}
