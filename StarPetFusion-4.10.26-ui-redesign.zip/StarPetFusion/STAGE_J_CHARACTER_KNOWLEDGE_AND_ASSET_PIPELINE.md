# StarPetFusion 4.7.0 — Stage J

## Scope
- Local source-attributed search over bundled roles, optional `vendor/hsr-skills`, local structured data, and character asset text metadata.
- Asset manifest and per-character state discovery for portrait/idle/happy/think/sleep.
- Safe upstream role refresh remains `python prepare.py --force`: staged download, archive path checks, role-card validation, and rollback preservation are retained.
- No model weights, proprietary game files, or unlicensed art are bundled.

## Commands
- `python hsr_knowledge.py 大黑塔 性格`
- `python hsr_knowledge.py 阿格莱雅 --json`
- `python character_asset_registry.py` is not a CLI; use `write_manifest()` from Python or inspect the generated manifest after import.
- Image folder layout: `character_assets/<role-slug>/portrait.png`, `idle.png`, `happy.png`, `think.png`, `sleep.png`.

## Limits
The local knowledge search only sees files already present. It does not claim live official verification and it does not copy full copyrighted narrative content. `prepare.py --force` refreshes the listed sources as a whole, not every GitHub repository. Missing animation states intentionally fall back to procedural mood.
