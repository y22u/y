from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "vendor" / "TheHerta-CodexPet" / "the-herta"
FILES = ("pet.json", "spritesheet.webp")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def install_herta_pet(codex_home: Path | None = None, force: bool = False) -> Path:
    if not SOURCE.is_dir():
        raise FileNotFoundError("找不到上游宠物包。请先运行：python prepare.py")
    for filename in FILES:
        if not (SOURCE / filename).is_file():
            raise FileNotFoundError(f"宠物包文件缺失：{SOURCE / filename}")
    try:
        metadata = json.loads((SOURCE / "pet.json").read_text(encoding="utf-8"))
        if metadata.get("spriteVersionNumber") != 2 or metadata.get("spritesheetPath") != "spritesheet.webp":
            raise ValueError("不支持的 Codex 宠物包格式")
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise ValueError(f"pet.json 校验失败：{exc}") from exc

    if codex_home is None:
        codex_home = Path(os.environ["CODEX_HOME"]) if os.environ.get("CODEX_HOME") else Path.home() / ".codex"
    destination = codex_home / "pets" / "the-herta"
    for filename in FILES:
        incoming = SOURCE / filename
        current = destination / filename
        if current.exists() and not current.is_file():
            raise ValueError(f"目标路径不是文件：{current}")
        if current.is_file() and digest(incoming) != digest(current) and not force:
            raise FileExistsError("已有不同版本的大黑塔宠物包。确认覆盖后请运行命令行：python install_herta_pet.py --force")
    destination.mkdir(parents=True, exist_ok=True)
    for filename in FILES:
        incoming, current = SOURCE / filename, destination / filename
        if current.is_file() and digest(incoming) == digest(current):
            continue
        shutil.copy2(incoming, current)
    return destination


def main() -> int:
    parser = argparse.ArgumentParser(description="安装大黑塔宠物包到 Codex 的 pets 目录")
    parser.add_argument("--codex-home", type=Path, default=None, help="自定义 CODEX_HOME；默认使用环境变量或 ~/.codex")
    parser.add_argument("--force", action="store_true", help="覆盖已经安装的不同版本")
    args = parser.parse_args()
    destination = install_herta_pet(args.codex_home, args.force)
    print(f"安装完成：{destination}")
    print("打开 Codex 桌面端：设置 → 宠物 → 刷新，然后选择「大黑塔」。")
    print("注意：该宠物包由 Codex 客户端负责显示，不等同于本项目中的独立桌宠窗口。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
