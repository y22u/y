from __future__ import annotations
from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QListWidget, QPushButton, QHBoxLayout, QMessageBox
from data_safety import list_backups, restore_backup, cleanup_old_logs

class DataSafetyDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("数据安全与恢复")
        self.resize(760, 420)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Agent 覆盖文件前会自动保存原文件快照。选择一项可恢复；恢复前会再次确认。"))
        self.items = QListWidget(); layout.addWidget(self.items)
        buttons = QHBoxLayout()
        refresh = QPushButton("刷新列表"); refresh.clicked.connect(self.refresh)
        restore = QPushButton("恢复选中备份…"); restore.clicked.connect(self.restore_selected)
        cleanup = QPushButton("清理 30 天前日志…"); cleanup.clicked.connect(self.cleanup_logs)
        close = QPushButton("关闭"); close.clicked.connect(self.accept)
        for b in (refresh, restore, cleanup, close): buttons.addWidget(b)
        layout.addLayout(buttons)
        self.refresh()
    def refresh(self):
        self.items.clear()
        for item in list_backups():
            label = f"{item.get('created_at','未知时间')} | {item.get('target','未知文件')} | {item.get('size',0)} 字节 | ID={item.get('id','')}"
            self.items.addItem(label)
    def restore_selected(self):
        row = self.items.currentRow()
        backups = list_backups()
        if row < 0 or row >= len(backups):
            QMessageBox.information(self, "请选择备份", "请先选择一个备份记录。"); return
        item = backups[row]
        answer = QMessageBox.question(self, "确认恢复", f"将备份恢复到原路径：\n{item.get('target')}\n\n当前文件内容会被替换。建议先确认该文件没有新的重要修改。继续吗？", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes: return
        try: result = restore_backup(str(item.get('id', '')))
        except Exception as exc: QMessageBox.warning(self, "恢复失败", str(exc)); return
        QMessageBox.information(self, "恢复完成", f"已恢复：{result['target']}\n大小：{result['bytes']} 字节")
    def cleanup_logs(self):
        answer = QMessageBox.question(self, "清理旧日志", "仅删除 StarPetFusion 自己的、超过 30 天的日志文件。此操作不可撤销。继续吗？", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes: return
        count = cleanup_old_logs(30)
        QMessageBox.information(self, "日志清理完成", f"已删除 {count} 个旧日志文件。")
