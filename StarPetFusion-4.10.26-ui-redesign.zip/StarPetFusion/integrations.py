from __future__ import annotations

"""Optional, explicitly configured third-party integration adapters.

No integrations run unless enabled by the user in %APPDATA%/StarPetFusion/integrations.json
(or ~/.config/StarPetFusion/integrations.json). Only HTTPS and loopback endpoints are allowed.
"""
import json
import os
import logging
from pathlib import Path
from urllib.parse import urlparse

import requests
from config_store import app_data_dir

logger = logging.getLogger(__name__)


def _allowed_url(url: str) -> bool:
    try:
        parsed = urlparse(str(url))
        host = (parsed.hostname or "").lower()
        return parsed.scheme == "https" or (parsed.scheme == "http" and host in {"localhost", "127.0.0.1", "::1"})
    except ValueError:
        return False


def integration_config() -> dict:
    path = app_data_dir() / "integrations.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def notify_animation(role_slug: str, state: str) -> None:
    cfg = integration_config().get("animation", {})
    if not isinstance(cfg, dict) or not cfg.get("enabled"):
        return
    url = str(cfg.get("webhook_url", "")).strip()
    if not _allowed_url(url):
        return
    # Send only non-sensitive event metadata; never send chat content or local paths.
    try:
        requests.post(url, json={"event": "character_animation_state", "role": role_slug[:80], "state": state[:40]}, timeout=3).raise_for_status()
    except requests.RequestException:
        return


def external_tts(text: str, role_slug: str) -> bool:
    """Use an explicitly configured external TTS provider, if enabled.

    Supported modes: generic_json (legacy) and openai_compatible. API keys are
    read from environment variables only. Provider receives chat text when enabled.
    """
    cfg = integration_config().get("tts", {})
    if not isinstance(cfg, dict) or not cfg.get("enabled"):
        return False
    provider = str(cfg.get("provider", "external")).lower()
    url = str(cfg.get("endpoint", "")).strip()
    # Built-in Edge and loopback sidecar providers do not use a generic cloud endpoint.
    if provider not in {"edge", "qwen3", "indextts", "gemini_api", "google_cloud"} and not _allowed_url(url):
        return False
    try:
        import tempfile
        import subprocess
        import sys
        from pathlib import Path
        from tts_adapters import (ExternalTTSAdapter, GoogleGeminiTTSAdapter, GoogleCloudTTSAdapter,
                                 EdgeTTSAdapter, IsolatedTTSAdapter)
        key_env = str(cfg.get("api_key_env", "STAR_PET_TTS_API_KEY"))[:100]
        timeout = int(cfg.get("timeout", 45))
        voice_map = cfg.get("voices", {})
        voice = voice_map.get(str(role_slug), cfg.get("voice", "Kore")) if isinstance(voice_map, dict) else cfg.get("voice", "Kore")
        suffix = ".mp3" if provider == "edge" else ".wav"
        fd, name = tempfile.mkstemp(prefix="starpet_tts_", suffix=suffix)
        os.close(fd)
        common = dict(voice=str(voice), language=str(cfg.get("language", "zh-CN")),
                      style=str(cfg.get("style", "Speak naturally")), speed=float(cfg.get("speed", 1.0)))
        if provider == "edge":
            adapter = EdgeTTSAdapter(timeout=timeout)
            common["voice"] = str(voice if voice and voice not in {"Kore", "alloy"} else "zh-CN-XiaoxiaoNeural")
        elif provider in {"qwen3", "indextts"}:
            env_name = "STAR_PET_QWEN3_TTS_ENDPOINT" if provider == "qwen3" else "STAR_PET_INDEXTTS_ENDPOINT"
            default_endpoint = "http://127.0.0.1:8766" if provider == "qwen3" else "http://127.0.0.1:8767"
            adapter = IsolatedTTSAdapter(os.environ.get(env_name, default_endpoint), timeout=max(timeout, 240))
            if provider == "qwen3" and not voice:
                common["voice"] = "Vivian"
        elif provider == "gemini_api":
            adapter = GoogleGeminiTTSAdapter(api_key_env=str(cfg.get("api_key_env", "GEMINI_API_KEY")),
                model=str(cfg.get("model", "gemini-2.5-flash-preview-tts")), timeout=timeout)
        elif provider == "google_cloud":
            adapter = GoogleCloudTTSAdapter(api_key_env=str(cfg.get("project_env", "GOOGLE_CLOUD_PROJECT")),
                model=str(cfg.get("model", "gemini-2.5-flash-tts")), timeout=timeout,
                location=str(cfg.get("location", "global")))
        else:
            adapter = ExternalTTSAdapter(endpoint=url, api_key_env=key_env,
                mode=str(cfg.get("mode", "generic_json")), model=str(cfg.get("model", "")), timeout=timeout)
        adapter.synthesize(str(text)[:1200], name, **common)
        if sys.platform == "win32":
            os.startfile(name)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(["xdg-open", name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except (requests.RequestException, OSError, ValueError, TypeError, ImportError) as exc:
        logger.warning("External TTS failed; provider=%s error_type=%s", provider, type(exc).__name__)
        return False
    except Exception as exc:
        # Cloud credential libraries may raise provider-specific exceptions. Keep the app alive.
        logger.warning("External TTS failed unexpectedly; provider=%s error_type=%s", provider, type(exc).__name__)
        return False
