"""Install the upstream Dafeiyu three-view sprites into the local vendor folder.

The source archive is downloaded on explicit user action; artwork is not bundled
into the distributed ZIP. Upstream repository code is MIT-licensed; verify any
separate artwork terms before redistributing extracted images.
"""
from __future__ import annotations
import hashlib, io, json, shutil, sys, urllib.request, zipfile
from pathlib import Path, PurePosixPath
from config_store import ConfigStore

ROOT = Path(__file__).resolve().parent
OWNER_REPO = "1190fasheqi/dafeiyu-pet"
REF = "main"
ZIP_URL = f"https://codeload.github.com/{OWNER_REPO}/zip/refs/heads/{REF}"
VENDOR = ROOT / "vendor" / "dafeiyu-pet"
SPRITES = VENDOR / "sprites"
VIEWS = ("正面.png", "侧面.png", "背面.png")
ATTRIBUTION = (
    f"Source repository: https://github.com/{OWNER_REPO}\n"
    "Code license: MIT (see upstream LICENSE). Image artwork may have separate rights; "
    "this local installer does not grant redistribution rights.\n"
)

def install(timeout: int = 90) -> Path:
    req = urllib.request.Request(ZIP_URL, headers={"User-Agent": "StarPetFusion-AssetInstaller/4.10.7"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        payload = response.read(80 * 1024 * 1024 + 1)
    if len(payload) > 80 * 1024 * 1024:
        raise RuntimeError("上游压缩包超过 80 MiB，已停止")
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        candidates = {}
        for item in archive.infolist():
            path = PurePosixPath(item.filename)
            if path.is_absolute() or ".." in path.parts:
                continue
            if path.name in VIEWS and path.parent.name == "sprites" and not item.is_dir():
                candidates[path.name] = item
        missing = [name for name in VIEWS if name not in candidates]
        if missing:
            raise RuntimeError("上游压缩包缺少三视图文件：" + ", ".join(missing))
        staged = ROOT / "vendor" / ".dafeiyu-sprites-staging"
        if staged.exists(): shutil.rmtree(staged)
        staged.mkdir(parents=True, exist_ok=True)
        try:
            for name, item in candidates.items():
                data = archive.read(item)
                if not data.startswith(b"\x89PNG\r\n\x1a\n"):
                    raise RuntimeError(f"{name} 不是有效 PNG")
                (staged / name).write_bytes(data)
            SPRITES.mkdir(parents=True, exist_ok=True)
            for name in VIEWS:
                shutil.copy2(staged / name, SPRITES / name)
        finally:
            shutil.rmtree(staged, ignore_errors=True)
    digest = {name: hashlib.sha256((SPRITES / name).read_bytes()).hexdigest() for name in VIEWS}
    (VENDOR / "ASSET_NOTICE.txt").write_text(ATTRIBUTION + "\nSHA-256:\n" + "\n".join(f"{k}: {v}" for k,v in digest.items()) + "\n", encoding="utf-8")
    # Let PetWidget use the three-view renderer rather than a single-image overlay.
    ConfigStore().set("appearance_path", "")
    ConfigStore().set("default_role", "dafeiyu")
    return SPRITES

if __name__ == "__main__":
    try:
        path = install()
        print(f"已安装大肥鱼三视图素材：{path}")
        print("请重启程序；桌宠将使用正面/侧面/背面三视图。")
    except Exception as exc:
        print(f"下载或安装失败：{exc}", file=sys.stderr)
        print("请检查网络及上游仓库文件结构；失败时不会自动替换现有外观。", file=sys.stderr)
        raise SystemExit(2)
