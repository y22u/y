# StarPetFusion 4.10.14 — Workspace UI & Lookbook Improvements

## What changed
- Refined the workspace hero to feature a real Q-style image asset rather than a purely decorative orb.
- Improved the character library hierarchy, card metadata, responsive grid, search result count, empty state, and keyboard focus states.
- Added persistent favorites and a favorites-only filter; favorites are stored in this browser's localStorage.
- Added name sorting and expanded search to include descriptions and notes.
- Clarified that selecting a character changes the web preview only. It does not change the native desktop pet or activate a 3D model.
- Added reduced-motion styling and regression assertions for library controls and preview semantics.

## Verification
- Python unittest suite: 129 passed, 1 skipped.
- `node --check frontend/assets/app.js`: passed.
- `python -m compileall -q .`: passed (bytecode cache removed before packaging).
- All declared character image paths checked against the project tree.
- ZIP integrity checked after packaging.

## Limitations
The current character entries are static image previews. Native desktop-pet switching and animated 3D models require a separate model/renderer integration and are not claimed by this release.
