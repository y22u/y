#!/usr/bin/env python3
"""Fetch a small set of character image assets from public GitHub repos.

This helper does not scrape game clients or bypass access controls. It searches a
repository's public Git tree for image files whose paths match character aliases,
then saves only a bounded number of candidates for local personal use. Check each
source's license and HoYoverse fan-content rules before redistributing assets.
"""
from __future__ import annotations
import argparse, json, re, sys, time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'character_assets'
EXTS = {'.png', '.jpg', '.jpeg', '.webp', '.gif'}
ALIASES = {
 'the-herta': ['the herta', 'the_herta', 'the-herta', '大黑塔'],
 'herta': ['herta', '黑塔'], 'aglaea': ['aglaea', '阿格莱雅'],
 'hyacine': ['hyacine', '风堇'], 'acheron': ['acheron', '黄泉'],
 'firefly': ['firefly', '流萤'], 'robin': ['robin', '知更鸟'],
 'kafka': ['kafka', '卡芙卡'], 'march-7th': ['march 7th', 'march-7th', '三月七'],
 'castorice': ['castorice', '遐蝶'], 'hysilens': ['hysilens', '海瑟音'],
 'silver-wolf': ['silver wolf', 'silver-wolf', '银狼'], 'sparkle': ['sparkle', '花火'],
 'jingliu': ['jingliu', '镜流'], 'ruan-mei': ['ruan mei', 'ruan-mei', '阮梅'],
}
DEFAULT_REPO = 'Mar-7th/StarRailRes'

def get_json(url: str, timeout: int = 25):
    req = Request(url, headers={'User-Agent':'StarPetFusion-AssetHelper/1.0','Accept':'application/vnd.github+json'})
    with urlopen(req, timeout=timeout) as r:
        if r.status != 200: raise RuntimeError(f'HTTP {r.status}: {url}')
        return json.loads(r.read().decode('utf-8'))

def download(url: str, path: Path, max_bytes: int = 12*1024*1024):
    req = Request(url, headers={'User-Agent':'StarPetFusion-AssetHelper/1.0'})
    with urlopen(req, timeout=35) as r:
        data = r.read(max_bytes + 1)
    if len(data) > max_bytes: raise RuntimeError('文件超过 12 MiB，已跳过')
    if len(data) < 16: raise RuntimeError('下载文件过小')
    # Basic file signature check; do not trust file extension alone.
    signatures = (b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'GIF87a', b'GIF89a', b'RIFF')
    if not any(data.startswith(s) for s in signatures): raise RuntimeError('响应不是受支持的图片格式')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

def main() -> int:
    ap = argparse.ArgumentParser(description='从公开 GitHub 仓库按角色名称匹配少量图片素材')
    ap.add_argument('--repo', default=DEFAULT_REPO, help='GitHub owner/repo，默认 Mar-7th/StarRailRes')
    ap.add_argument('--ref', default='master', help='分支或 tag，默认 master')
    ap.add_argument('--character', action='append', help='角色 slug，可重复指定；默认下载大黑塔/阿格莱雅/海瑟音候选图')
    ap.add_argument('--limit-per-character', type=int, default=2, help='每个角色最多下载几张，1–5')
    ap.add_argument('--url-manifest', type=Path, help='可选 JSON：[{"character":"the-herta","url":"https://...","filename":"portrait.png"}]')
    args = ap.parse_args()
    if not 1 <= args.limit_per_character <= 5:
        ap.error('--limit-per-character 必须在 1–5 之间')
    chosen = args.character or ['the-herta','aglaea','hyacine']
    unknown = [x for x in chosen if x not in ALIASES]
    if unknown: ap.error('暂不支持这些角色 slug：' + ', '.join(unknown))
    saved, skipped = [], []
    if args.url_manifest:
        try: rows = json.loads(args.url_manifest.read_text(encoding='utf-8'))
        except Exception as e: print(f'无法读取 URL 清单：{e}', file=sys.stderr); return 2
        for row in rows:
            if row.get('character') not in chosen: continue
            url = str(row.get('url',''))
            if not url.startswith('https://'): skipped.append(f"{row.get('character')}: 仅允许 HTTPS URL"); continue
            filename = Path(str(row.get('filename') or url.split('?',1)[0].rsplit('/',1)[-1])).name
            if Path(filename).suffix.lower() not in EXTS: skipped.append(f'{filename}: 不支持的扩展名'); continue
            target = DEST / row['character'] / filename
            try: download(url, target); saved.append(str(target.relative_to(ROOT)))
            except Exception as e: skipped.append(f'{filename}: {e}')
    else:
        try:
            meta = get_json(f'https://api.github.com/repos/{quote(args.repo, safe='/')}/git/trees/{quote(args.ref, safe="")}?recursive=1')
            tree = meta.get('tree', [])
        except Exception as e:
            print(f'GitHub 目录索引获取失败：{e}', file=sys.stderr)
            print('可重试 --ref main；也可使用 --url-manifest 导入你有权使用的 HTTPS 图片链接。', file=sys.stderr)
            return 2
        for slug in chosen:
            aliases = [a.casefold() for a in ALIASES[slug]]
            matches = []
            for item in tree:
                p = item.get('path','')
                if item.get('type') != 'blob' or Path(p).suffix.lower() not in EXTS: continue
                folded = p.casefold()
                if any(a in folded for a in aliases):
                    # Prefer portraits / splash / character art over tiny icons.
                    score = (5 if any(k in folded for k in ('splash','portrait','avatar','art','character')) else 0)
                    score -= (3 if any(k in folded for k in ('icon','skill','material','lightcone')) else 0)
                    matches.append((score, p, item.get('size',0)))
            matches.sort(key=lambda x: (-x[0], len(x[1]), x[1]))
            count = 0
            for _, p, size in matches:
                if count >= args.limit_per_character: break
                if size and size > 12*1024*1024: continue
                url = f'https://raw.githubusercontent.com/{args.repo}/{args.ref}/' + '/'.join(quote(part) for part in p.split('/'))
                target = DEST / slug / Path(p).name
                try:
                    download(url, target); saved.append(str(target.relative_to(ROOT))); count += 1
                except Exception as e: skipped.append(f'{slug}/{Path(p).name}: {e}')
            if count == 0: skipped.append(f'{slug}: 未在仓库路径中找到可匹配图片；可通过 URL 清单手动指定资源')
    index = DEST / 'ASSET_INDEX.json'
    index.parent.mkdir(parents=True, exist_ok=True)
    old = []
    if index.exists():
        try: old = json.loads(index.read_text(encoding='utf-8')).get('assets', [])
        except Exception: old = []
    known = {x.get('path') for x in old}
    for rel in saved:
        if rel not in known:
            old.append({'path':rel,'source_type':'github_or_user_url','license_review_required':True,'usage':'local desktop appearance'})
    # Record upstream provenance and require explicit review before redistribution.
    for entry in old:
        entry.setdefault('source_repository', f'https://github.com/{args.repo}')
        entry.setdefault('source_ref', args.ref)
        entry.setdefault('license_review_required', True)
        entry.setdefault('redistribution_allowed', False)
        entry.setdefault('usage', 'local appearance only until license is reviewed')
    index.write_text(json.dumps({'notice':'Fan project. Repository code license does not automatically license character art. Verify each asset license and current HoYoverse fan-content rules before redistribution.','assets':old}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'已保存 {len(saved)} 张图片。')
    for p in saved: print('  +', p)
    if skipped:
        print(f'跳过/未找到 {len(skipped)} 项：')
        for s in skipped: print('  -', s)
    print('启动 StarPetFusion 后，右键桌宠 → 切换桌宠外观，即可选择已导入图片。')
    return 0 if saved else 1

if __name__ == '__main__': raise SystemExit(main())
