import tempfile
import unittest
from pathlib import Path
from config_store import ConfigStore
from access_control import is_allowed, get_permissions, PRESETS

class PermissionTests(unittest.TestCase):
    def test_defaults_allow_existing_features(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = ConfigStore(Path(td) / "config.json")
            self.assertTrue(is_allowed(cfg, "chat"))
            self.assertTrue(is_allowed(cfg, "manage_assets"))
    def test_network_off_blocks_remote_chat(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = ConfigStore(Path(td) / "config.json")
            cfg.set("permissions", {**get_permissions(cfg), "network": False})
            self.assertFalse(is_allowed(cfg, "chat"))
            self.assertFalse(is_allowed(cfg, "network"))
    def test_productivity_permissions_are_explicit(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = ConfigStore(Path(td) / "config.json")
            self.assertTrue(is_allowed(cfg, "productivity"))
            self.assertTrue(is_allowed(cfg, "file_search"))
            self.assertTrue(is_allowed(cfg, "open_files"))
            cfg.set("permissions", {**get_permissions(cfg), "open_files": False})
            self.assertFalse(is_allowed(cfg, "open_files"))

    def test_unknown_permission_denied(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = ConfigStore(Path(td) / "config.json")
            self.assertFalse(is_allowed(cfg, "execute_arbitrary_code"))
    def test_restricted_preset_disables_sensitive_actions(self):
        self.assertFalse(PRESETS["受限模式"]["manage_assets"])
        self.assertFalse(PRESETS["受限模式"]["install_external"])

if __name__ == "__main__": unittest.main()
