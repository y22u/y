import unittest
from voice_pipeline import distilled_voice_profile, backend_summary

class VoicePipelineTests(unittest.TestCase):
    def test_profile_is_bounded_and_normalized(self):
        p = distilled_voice_profile({"rate": 8, "volume": -2, "style": "unknown", "voice_hint": "x" * 500})
        self.assertEqual(p["rate"], 1.5)
        self.assertEqual(p["volume"], 0.0)
        self.assertEqual(p["style"], "neutral")
        self.assertLessEqual(len(p["delivery"]), 120)

    def test_backend_summary_has_asr_and_tts(self):
        summary = backend_summary()
        self.assertIn("asr", summary)
        self.assertIn("tts", summary)
        self.assertTrue(summary["asr"])
        self.assertTrue(summary["tts"])

if __name__ == "__main__":
    unittest.main()
