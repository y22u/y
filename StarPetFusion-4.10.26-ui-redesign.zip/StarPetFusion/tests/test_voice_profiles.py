import json, unittest
from pathlib import Path
from voice_service import load_profiles, speak_text
ROOT = Path(__file__).resolve().parents[1]
class VoiceProfileTests(unittest.TestCase):
    def test_profiles_include_new_characters(self):
        profiles = load_profiles()
        self.assertIn("aglaea", profiles)
        self.assertIn("hysilens", profiles)
        self.assertIn("hyacine", profiles)
    def test_profile_values_are_bounded(self):
        for p in load_profiles().values():
            self.assertGreaterEqual(float(p.get("rate", 1)), 0.5)
            self.assertLessEqual(float(p.get("rate", 1)), 1.5)
            self.assertGreaterEqual(float(p.get("volume", .9)), 0)
            self.assertLessEqual(float(p.get("volume", .9)), 1)
    def test_character_profiles_have_provider_voice_and_distinct_delivery(self):
        profiles = load_profiles()
        expected = {
            "the-herta", "aglaea", "hysilens", "hyacine", "kafka", "march-7th",
            "firefly", "acheron", "jingliu", "silver-wolf", "black-swan",
            "fu-xuan", "topaz", "ruan-mei", "robin", "fugue", "evernight"
        }
        self.assertTrue(expected.issubset(profiles.keys()))
        for slug in expected:
            profile = profiles[slug]
            self.assertIn("delivery_prompt", profile, slug)
            self.assertTrue(profile["delivery_prompt"].strip(), slug)
            self.assertIn("edge", profile["engine_voices"], slug)
            self.assertIn("qwen3", profile["engine_voices"], slug)
            self.assertTrue(profile["engine_voices"]["edge"].startswith("zh-CN-"), slug)
        prompts = {profiles[slug]["delivery_prompt"] for slug in expected}
        self.assertEqual(len(prompts), len(expected))

    def test_character_voice_profiles_do_not_claim_actor_cloning(self):
        for slug, profile in load_profiles().items():
            if slug == "default":
                continue
            note = profile.get("voice_profile_note", "")
            self.assertIn("不", note, slug)

    def test_disabled_speech_is_safe(self):
        speak_text("test", "aglaea", enabled=False)
if __name__ == "__main__": unittest.main()
