import unittest
from agent_runtime import AgentRuntime, SafeToolRegistry, STYLE_BY_KEY

class AgentRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.agent = AgentRuntime()

    def test_style_modes_are_available(self):
        for key in ("character", "natural", "concise", "professional", "warm", "playful", "analytical", "formal", "poetic"):
            self.assertIn(key, STYLE_BY_KEY)
            self.assertTrue(self.agent.style_instruction(key))

    def test_prompt_keeps_persona_and_adds_style(self):
        prompt = self.agent.enrich_system_prompt("原始人物设定", "示例角色", "professional", "", "帮我分析", True)
        self.assertIn("原始人物设定", prompt)
        self.assertIn("专业严谨", prompt)
        self.assertIn("Agent 执行边界", prompt)

    def test_read_only_tools_are_allowlisted(self):
        tools = SafeToolRegistry()
        self.assertIn("current_time", tools.available_tools())
        self.assertIn("app_capabilities", tools.available_tools())
        self.assertIn("未获允许", tools.run("run_shell"))

    def test_tools_only_added_when_relevant(self):
        prompt = self.agent.enrich_system_prompt("base", "角色", "character", user_text="现在几点？")
        self.assertIn("本机时间", prompt)
        prompt = self.agent.enrich_system_prompt("base", "角色", "character", user_text="你好")
        self.assertNotIn("本机时间：", prompt)

if __name__ == "__main__":
    unittest.main()
