"""Regression locks for the 4.10.7 Big Fat Fish desktop-pet appearance.

These hashes protect the desktop-pet core and stable character manifests. ASSET_INDEX.json
is intentionally extensible so new user-approved preview assets can be registered; core pet rendering remains locked.
"""
import hashlib
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASELINE_4_10_7 = {
    "download_dafeiyu_assets.py": "1bcfdc57e2ec3ebac91cb60308c39d739b951e29e6ceb1b04e7ba11316ed675c",
    "install_herta_pet.py": "2043878725cfe4e237438b523b74542876628471fca559340dd408ade2c60fb9",
    "character_assets/CHARACTER_ASSET_MANIFEST.json": "128f410f2363da50ce761e1f34d79d7de7bf8108dad556e86c65c23bf98dd1c5",
    "official_data/character_visual_voice_profiles.json": "29d739237866aba2a3ecca9e82fa3df4f83da0b1fbbae66f92ce51e8bbe609cf",
}

class VisualPreservationTests(unittest.TestCase):
    def test_asset_index_is_valid_and_extensible(self):
        import json
        data = json.loads((ROOT / "character_assets/ASSET_INDEX.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(len(data.get("assets", [])), 28)
        self.assertTrue(all(not item.get("is_3d_model", True) for item in data["assets"]))

    def test_4107_visual_files_remain_byte_identical(self):
        for relative, expected in BASELINE_4_10_7.items():
            with self.subTest(path=relative):
                path = ROOT / relative
                self.assertTrue(path.is_file(), f"Missing protected visual file: {relative}")
                actual = hashlib.sha256(path.read_bytes()).hexdigest()
                self.assertEqual(actual, expected, f"Unexpected visual change in {relative}")

    def test_native_desktop_pet_is_image_free(self):
        pet_source = (ROOT / "pet_widget.py").read_text(encoding="utf-8")
        paint_source = pet_source.split("    def paintEvent(self, event)", 1)[1].split("    def _draw_bubble(", 1)[0]
        self.assertNotIn("drawPixmap", paint_source)
        self.assertNotIn("QPixmap", paint_source)
        self.assertIn("文字模式", paint_source)
        main_source = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertNotIn('menu.addMenu("切换桌宠外观")', main_source)
        self.assertIn('桌宠外观：无图片文字模式', main_source)

if __name__ == "__main__":
    unittest.main()
