import tempfile
import unittest
from pathlib import Path
from productivity_data import export_backup, read_backup, merge_data, normalize_data

class ProductivityDataTests(unittest.TestCase):
    def test_export_import_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'backup.json'
            data = {'todos': [{'text': '保留任务', 'done': True, 'created': '2026-10-23T10:00'}], 'notes': '原有便签'}
            export_backup(path, data)
            self.assertEqual(read_backup(path), normalize_data(data))

    def test_merge_preserves_existing_data(self):
        current = {'todos': [{'text': '旧任务', 'done': False, 'created': 'a'}], 'notes': '旧便签'}
        incoming = {'todos': [{'text': '新任务', 'done': False, 'created': 'b'}], 'notes': '新便签'}
        merged = merge_data(current, incoming)
        self.assertEqual(len(merged['todos']), 2)
        self.assertTrue(merged['notes'].startswith('旧便签'))
        self.assertIn('新便签', merged['notes'])

    def test_rejects_wrong_backup_kind(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'bad.json'
            path.write_text('{"todos": [], "notes": ""}', encoding='utf-8')
            with self.assertRaises(ValueError):
                read_backup(path)

if __name__ == '__main__':
    unittest.main()
