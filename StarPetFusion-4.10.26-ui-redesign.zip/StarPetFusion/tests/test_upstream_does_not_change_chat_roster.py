import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import skills

class UpstreamRosterMergeSafetyTests(unittest.TestCase):
    def test_generic_downloaded_skills_do_not_enter_merged_character_roster(self):
        bundled = skills._scan_role_root(skills.BUNDLED_ROLES_ROOT)
        self.assertTrue(bundled, "expected bundled character roster")
        with tempfile.TemporaryDirectory() as tmp:
            upstream = Path(tmp) / "vendor" / "hsr-skills"
            upstream.mkdir(parents=True)
            extra = upstream / "random-tool-or-experimental-skill"
            extra.mkdir()
            (extra / "SKILL.md").write_text("# Not a curated chat character", encoding="utf-8")
            with patch.object(skills, "SKILLS_ROOT", upstream):
                actual = skills.list_roles()
        self.assertEqual(len(actual), len(bundled))
        self.assertNotIn("random-tool-or-experimental-skill", {r.slug for r in actual})
        self.assertEqual([r.name.casefold() for r in actual], sorted(r.name.casefold() for r in actual))

if __name__ == "__main__":
    unittest.main()
