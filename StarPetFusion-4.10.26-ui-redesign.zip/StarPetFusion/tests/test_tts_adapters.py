import unittest
import base64
import importlib.util
import os
import tempfile
import wave
from pathlib import Path
from unittest.mock import Mock, patch
from tts_adapters import ExternalTTSAdapter, GoogleGeminiTTSAdapter, GoogleCloudTTSAdapter

class TTSAdapterTests(unittest.TestCase):
    def test_rejects_plain_remote_http(self):
        with self.assertRaises(ValueError):
            ExternalTTSAdapter('http://example.com/speech')
    def test_allows_loopback(self):
        adapter = ExternalTTSAdapter('http://127.0.0.1:5000/v1/audio/speech')
        self.assertEqual(adapter.mode, 'openai_compatible')
    def test_rejects_invalid_mode_to_default(self):
        adapter = ExternalTTSAdapter('https://example.com/speech', mode='oops')
        self.assertEqual(adapter.mode, 'openai_compatible')

    def test_gemini_tts_wraps_pcm_as_valid_wav(self):
        pcm = b"\x00\x00" * 120
        response = Mock()
        response.json.return_value = {"candidates": [{"content": {"parts": [{"inlineData": {"mimeType": "audio/pcm;rate=24000", "data": base64.b64encode(pcm).decode()}}]}}]}
        response.raise_for_status.return_value = None
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {"TEST_GEMINI_KEY": "test-secret"}), patch("tts_adapters.requests.post", return_value=response):
            out = Path(temp) / "test.wav"
            GoogleGeminiTTSAdapter("TEST_GEMINI_KEY").synthesize("hello", out)
            with wave.open(str(out), "rb") as audio:
                self.assertEqual(audio.getframerate(), 24000)
                self.assertEqual(audio.getnchannels(), 1)
                self.assertEqual(audio.getnframes(), 120)

    def test_gemini_tts_requires_key_without_leaking_it(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(ValueError, "TEST_GEMINI_KEY"):
                GoogleGeminiTTSAdapter("TEST_GEMINI_KEY").synthesize("hello", "unused.wav")

    @unittest.skipUnless(importlib.util.find_spec("google.auth") is not None, "google-auth is not installed in this test environment")
    def test_google_cloud_tts_writes_wav_from_pcm(self):
        pcm = b"\x00\x00" * 80
        response = Mock()
        response.json.return_value = {"audioContent": base64.b64encode(pcm).decode()}
        response.raise_for_status.return_value = None
        creds = Mock(valid=True, token="dummy-token")
        with tempfile.TemporaryDirectory() as temp, \
             patch("google.auth.default", return_value=(creds, "demo-project")), \
             patch("tts_adapters.requests.post", return_value=response):
            out = Path(temp) / "cloud.wav"
            GoogleCloudTTSAdapter().synthesize("hello", out)
            with wave.open(str(out), "rb") as audio:
                self.assertEqual(audio.getframerate(), 24000)
                self.assertEqual(audio.getnframes(), 80)

if __name__ == '__main__':
    unittest.main()
