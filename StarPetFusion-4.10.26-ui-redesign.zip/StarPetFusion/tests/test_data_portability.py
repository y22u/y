import json, tempfile, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
import data_portability as dp

class DataPortabilityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name) / 'appdata'; self.root.mkdir()
        (self.root/'config.json').write_text(json.dumps({'provider':'demo','api_key':'secret-value','nested':{'access_token':'abc','ok':1}}), encoding='utf-8')
        (self.root/'integrations.json').write_text(json.dumps({'tts':{'api_key':'tts-secret','enabled':False}}), encoding='utf-8')
        with patch.object(dp, 'app_data_dir', return_value=self.root):
            import sqlite3
            db = sqlite3.connect(self.root/'growth.sqlite3')
            try:
                db.execute('CREATE TABLE memories (id INTEGER PRIMARY KEY, text TEXT)')
                db.execute('INSERT INTO memories(text) VALUES (?)', ('test-memory',))
                db.commit()
            finally:
                db.close()
        self.patch = patch.object(dp, 'app_data_dir', return_value=self.root); self.patch.start()
    def tearDown(self): self.patch.stop(); self.tmp.cleanup()
    def test_export_redacts_secrets_and_roundtrips(self):
        archive = self.root.parent/'backup.zip'; dp.export_backup(archive)
        info = dp.inspect_backup(archive); self.assertTrue(info['valid']); self.assertTrue(info['redacted_secrets'])
        with zipfile.ZipFile(archive) as zf:
            config = json.loads(zf.read('config.json')); self.assertEqual(config['api_key'], '')
            self.assertEqual(config['nested']['access_token'], '')
        (self.root/'config.json').write_text('{"provider":"changed"}', encoding='utf-8')
        result = dp.import_backup(archive); self.assertIn('config.json', result['imported'])
        self.assertEqual(json.loads((self.root/'config.json').read_text())['provider'], 'demo')
        self.assertTrue((Path(result['rollback_snapshot'])/'config.json').is_file())
    def test_tampered_archive_is_rejected(self):
        archive = self.root.parent/'backup.zip'; dp.export_backup(archive)
        bad = self.root.parent/'bad.zip'
        with zipfile.ZipFile(archive) as src, zipfile.ZipFile(bad,'w') as dst:
            for n in src.namelist(): dst.writestr(n, b'{"api_key":"tampered"}' if n == 'config.json' else src.read(n))
        with self.assertRaises(ValueError): dp.inspect_backup(bad)
    def test_unexpected_paths_rejected(self):
        archive = self.root.parent/'bad.zip'
        with zipfile.ZipFile(archive,'w') as zf:
            zf.writestr('../config.json','{}'); zf.writestr('manifest.json', json.dumps({'format':dp.FORMAT,'version':1,'files':{}}))
        with self.assertRaises(ValueError): dp.inspect_backup(archive)
    def test_diagnostic_does_not_disclose_secrets(self):
        report = dp.create_diagnostic_report(); text = json.dumps(report)
        self.assertNotIn('secret-value', text); self.assertNotIn('tts-secret', text)
        self.assertTrue(any(x['name']=='growth_database_integrity' and x['ok'] for x in report['checks']))

if __name__ == '__main__': unittest.main()
