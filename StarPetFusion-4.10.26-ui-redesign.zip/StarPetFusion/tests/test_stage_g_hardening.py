import unittest
from unittest.mock import patch
import requests

from services import AIClient
from external_agent import ExternalAgentClient, ExternalAgentError


def http_error(status=500, body='upstream echoed secret=DO_NOT_LEAK'):
    response = requests.Response()
    response.status_code = status
    response._content = body.encode('utf-8')
    response.url = 'https://example.invalid/chat/completions'
    error = requests.HTTPError(f'HTTP {status}')
    error.response = response
    return error


class StageGHardeningTests(unittest.TestCase):
    @patch('services.requests.post')
    def test_ai_error_does_not_expose_provider_body(self, post):
        post.side_effect = http_error()
        client = AIClient({'provider': 'deepseek', 'api_base_url': 'https://example.invalid',
                           'api_model': 'test-model', 'api_key': 'dummy-test-key'})
        with self.assertRaises(RuntimeError) as caught:
            client.chat([{'role': 'user', 'content': 'hello'}])
        self.assertIn('HTTP 500', str(caught.exception))
        self.assertNotIn('DO_NOT_LEAK', str(caught.exception))

    @patch('external_agent._SESSION.post')
    def test_agent_error_does_not_expose_provider_body(self, post):
        post.side_effect = http_error()
        client = ExternalAgentClient({'enabled': True, 'endpoint': 'http://127.0.0.1:9999',
                                      'model': 'test-model', 'timeout': 5})
        with self.assertRaises(ExternalAgentError) as caught:
            client.chat([{'role': 'user', 'content': 'hello'}])
        self.assertIn('HTTP 500', str(caught.exception))
        self.assertNotIn('DO_NOT_LEAK', str(caught.exception))


if __name__ == '__main__':
    unittest.main()
