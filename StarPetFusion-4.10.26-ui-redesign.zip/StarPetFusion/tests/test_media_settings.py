import json, unittest
from pathlib import Path

class MediaFeatureTests(unittest.TestCase):
    def test_voice_profiles_have_role_specific_values(self):
        data=json.loads((Path(__file__).resolve().parents[1]/"voice_profiles.json").read_text(encoding="utf-8"))
        self.assertIn("aglaea",data); self.assertIn("hysilens",data)
        self.assertNotEqual(data["aglaea"].get("rate"),data["march-7th"].get("rate"))
    def test_animation_states_documented(self):
        text=(Path(__file__).resolve().parents[1]/"media_settings_dialog.py").read_text(encoding="utf-8")
        for state in ("idle","happy","think","sleep"): self.assertIn(state,text)

    def test_edge_tts_is_visible_in_tts_service_settings(self):
        root=Path(__file__).resolve().parents[1]
        dialog=(root/"tts_settings_dialog.py").read_text(encoding="utf-8")
        frontend=(root/"frontend"/"index.html").read_text(encoding="utf-8")
        self.assertIn("Edge TTS（免费在线，无 API Key）", dialog)
        self.assertIn("测试 Edge TTS", dialog)
        self.assertIn('option value="edge"', frontend)

    def test_duplicate_role_animation_submenu_removed(self):
        main=(Path(__file__).resolve().parents[1]/"main.py").read_text(encoding="utf-8")
        self.assertNotIn('menu.addMenu("当前角色专属动作")', main)
        self.assertIn('menu.addMenu("互动动作")', main)

if __name__ == "__main__": unittest.main()
