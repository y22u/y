import json
import unittest
from pathlib import Path

from skills import BUNDLED_ROLES_ROOT, list_roles, build_system_prompt

class StageFPersonaProfileTests(unittest.TestCase):
    def test_all_bundled_roles_have_generated_prompt_profile(self):
        roles = [p for p in BUNDLED_ROLES_ROOT.iterdir() if p.is_dir() and (p / 'manifest.json').is_file()]
        self.assertGreaterEqual(len(roles), 20)
        for folder in roles:
            with self.subTest(role=folder.name):
                data = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
                prompt = folder / 'prompt_profile.md'
                self.assertTrue(prompt.is_file())
                self.assertGreater(len(prompt.read_text(encoding='utf-8')), 500)
                self.assertIn('prompt_profile', data)
                self.assertGreaterEqual(len(data['prompt_profile'].get('prompt_template', [])), 8)
                self.assertIn('interaction_protocol', data['prompt_profile'])
                self.assertIn('safety_and_capability', data['prompt_profile'])

    def test_system_prompt_includes_generated_profile(self):
        role = next(r for r in list_roles(BUNDLED_ROLES_ROOT) if r.slug == 'sparkle')
        prompt = build_system_prompt(role, user_text='我想聊聊你的说话风格')
        self.assertIn('花火', prompt)
        self.assertIn('自动生成的详细角色提示词', prompt)
        self.assertIn('不虚构', prompt)

    def test_prompts_do_not_claim_official_full_setting(self):
        for folder in BUNDLED_ROLES_ROOT.iterdir():
            file = folder / 'prompt_profile.md'
            if file.is_file():
                text = file.read_text(encoding='utf-8')
                self.assertIn('不代表官方完整设定', text)

if __name__ == '__main__':
    unittest.main()
