import importlib.util
import tempfile
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

knowledge = load('hsr_knowledge_stage_j', 'hsr_knowledge.py')
assets = load('character_assets_stage_j', 'character_asset_registry.py')

class StageJTests(unittest.TestCase):
    def test_search_returns_source_attribution(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); role = root / 'the-herta'; role.mkdir()
            (role / 'SKILL.md').write_text('# 大黑塔\n聪慧、自信、理性，擅长研究。', encoding='utf-8')
            results = knowledge.search('大黑塔 研究', roots=(root,))
            self.assertTrue(results)
            self.assertEqual(results[0]['character'], 'the-herta')
            self.assertIn('SKILL.md', results[0]['source'])

    def test_asset_registry_finds_states(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); role = root / 'the-herta'; role.mkdir()
            for name in ('portrait.png', 'idle.webp', 'happy.jpg', 'think.png', 'sleep.png'):
                (role / name).write_bytes(b'placeholder')
            result = assets.scan_assets((root,))
            self.assertIn('the-herta', result)
            self.assertEqual(set(result['the-herta']['animations']), {'idle','happy','think','sleep'})
            self.assertTrue(result['the-herta']['portrait'].endswith('portrait.png'))

    def test_find_role_portrait_prefers_portrait_filename(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); role = root / 'the-herta'; role.mkdir()
            (role / 'portrait.png').write_bytes(b'placeholder')
            (role / 'other.jpg').write_bytes(b'placeholder')
            self.assertEqual(Path(assets.find_role_portrait('the-herta', (root,))).name, 'portrait.png')

    def test_find_role_portrait_returns_none_when_missing(self):
        with tempfile.TemporaryDirectory() as td:
            self.assertIsNone(assets.find_role_portrait('the-herta', (Path(td),)))

    def test_chinese_role_name_resolves_english_portrait_folder(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); role = root / 'the-herta'; role.mkdir()
            (role / 'portrait.png').write_bytes(b'placeholder')
            self.assertEqual(Path(assets.find_role_portrait('大黑塔', (root,))).name, 'portrait.png')



    def test_asset_scan_deterministically_prefers_named_portrait(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); role = root / 'the-herta'; role.mkdir()
            (role / 'z-scene.jpg').write_bytes(b'scene')
            (role / 'avatar.png').write_bytes(b'avatar')
            (role / 'a-scene.png').write_bytes(b'scene')
            result = assets.scan_assets((root,))
            self.assertEqual(Path(result['the-herta']['portrait']).name, 'avatar.png')
            self.assertEqual(result, assets.scan_assets((root,)))

    def test_sprite_sheet_is_not_mistaken_for_role_portrait(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); role = root / 'the-herta'; role.mkdir()
            (role / 'spritesheet.webp').write_bytes(b'placeholder')
            self.assertIsNone(assets.find_role_portrait('the-herta', (root,)))
            self.assertEqual(assets.scan_assets((root,)), {})

    def test_character_library_imports_role_profiles_to_sqlite(self):
        import character_library
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            role = root / 'bundled_roles' / 'the-herta'
            role.mkdir(parents=True)
            (role / 'manifest.json').write_text('{"slug":"the-herta","name":"大黑塔"}', encoding='utf-8')
            (role / 'prompt_profile.md').write_text('# 大黑塔\n聪慧、自信。', encoding='utf-8')
            db = root / 'library.db'
            self.assertEqual(character_library.import_profiles(root, db), 1)
            rows = character_library.list_characters(db)
            self.assertEqual(rows[0]['slug'], 'the-herta')
            conn = character_library.connect(db)
            try:
                row = conn.execute('SELECT profile_markdown FROM characters WHERE slug=?', ('the-herta',)).fetchone()
                self.assertIn('聪慧', row['profile_markdown'])
            finally:
                conn.close()

    def test_existing_valid_animation_mapping_is_preserved(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); role = root / 'the-herta'; role.mkdir()
            (role / 'idle.png').write_bytes(b'placeholder')
            custom = root / 'my-idle.png'; custom.write_bytes(b'custom')
            merged = assets.update_config_mapping({'role_animation_assets': {'the-herta': {'idle': str(custom)} }}, (root,))
            self.assertEqual(merged['the-herta']['idle'], str(custom))
            self.assertIn('portrait', assets.scan_assets((root,))['the-herta'])

if __name__ == '__main__': unittest.main()
