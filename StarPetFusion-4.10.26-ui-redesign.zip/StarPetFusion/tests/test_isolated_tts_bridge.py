import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tts_adapters import IsolatedTTSAdapter

class FakeResponse:
    headers = {"Content-Type": "audio/wav"}
    content = b"RIFF" + b"test-audio"
    def raise_for_status(self): pass

class IsolatedTTSBridgeTests(unittest.TestCase):
    def test_rejects_non_loopback_http(self):
        with self.assertRaises(ValueError):
            IsolatedTTSAdapter("http://192.168.1.5:8766")

    def test_posts_to_local_sidecar_and_saves_wav(self):
        with tempfile.TemporaryDirectory() as d:
            with patch("tts_adapters.requests.post", return_value=FakeResponse()) as post:
                path = IsolatedTTSAdapter("http://127.0.0.1:8766").synthesize("测试", Path(d) / "out.wav", voice="Vivian")
            self.assertEqual(path.read_bytes(), FakeResponse.content)
            self.assertEqual(post.call_args.args[0], "http://127.0.0.1:8766/synthesize")
            self.assertEqual(post.call_args.kwargs["json"]["voice"], "Vivian")

    def test_rejects_non_audio_response(self):
        class Bad(FakeResponse):
            headers = {"Content-Type": "application/json"}
        with tempfile.TemporaryDirectory() as d, patch("tts_adapters.requests.post", return_value=Bad()):
            with self.assertRaises(ValueError):
                IsolatedTTSAdapter("http://localhost:8767").synthesize("测试", Path(d) / "out.wav")

if __name__ == "__main__": unittest.main()
