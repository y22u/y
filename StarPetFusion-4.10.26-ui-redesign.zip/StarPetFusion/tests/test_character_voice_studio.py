import json, math, struct, tempfile, wave
from pathlib import Path
from unittest.mock import patch
import unittest
import character_voice_studio as studio


def wav_bytes(seconds=2.0, rate=16000, amplitude=8000):
    import io
    out=io.BytesIO()
    with wave.open(out,'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(rate)
        frames=b''.join(struct.pack('<h', int(amplitude*math.sin(2*math.pi*440*i/rate))) for i in range(int(seconds*rate)))
        wf.writeframes(frames)
    return out.getvalue()

class CharacterVoiceStudioTests(unittest.TestCase):
    def test_wav_inspection_returns_objective_metrics(self):
        metrics=studio.inspect_wav(wav_bytes())
        self.assertEqual(metrics['sample_rate'],16000)
        self.assertEqual(metrics['channels'],1)
        self.assertAlmostEqual(metrics['duration_seconds'],2.0)
        self.assertIn('rms_dbfs',metrics)

    def test_rejects_invalid_wav_and_duration(self):
        with self.assertRaises(ValueError): studio.inspect_wav(b'not wav')
        with self.assertRaises(ValueError): studio.inspect_wav(wav_bytes(seconds=.2))

    def test_reference_requires_explicit_authorization(self):
        with self.assertRaisesRegex(ValueError,'授权'):
            studio.save_reference('the-herta',wav_bytes(),authorization_confirmed=False,authorization_basis='authorized by owner')

    def test_reference_manifest_hash_and_delete(self):
        with tempfile.TemporaryDirectory(dir=studio.ROOT) as tmp:
            base=Path(tmp); refdir=base/'refs'; manifest=base/'manifest.json'; data=base/'data'
            with patch.object(studio,'REFERENCE_DIR',refdir), patch.object(studio,'MANIFEST',manifest), patch.object(studio,'DATA_DIR',data):
                record=studio.save_reference('the-herta',wav_bytes(),authorization_confirmed=True,authorization_basis='本人录制并授权本地合成')
                self.assertTrue(record['authorization_verified'])
                self.assertEqual(studio.get_references()['the-herta']['sha256'],record['sha256'])
                self.assertTrue(studio.delete_reference('the-herta'))
                self.assertNotIn('the-herta',studio.get_references())

if __name__=='__main__': unittest.main()
