import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class CharacterLookbookTests(unittest.TestCase):
    def test_all_library_images_exist_and_are_declared_as_previews(self):
        manifest = json.loads((ROOT / 'character_assets/USER_CHARACTER_LIBRARY.json').read_text(encoding='utf-8'))
        self.assertGreaterEqual(len(manifest['characters']), 28)
        self.assertEqual(manifest.get('chibi_reference_count'), 20)
        self.assertEqual(sum(item.get('category') == 'chibi' for item in manifest['characters']), 20)
        for item in manifest['characters']:
            path = ROOT / 'frontend' / item['image'].lstrip('/')
            self.assertTrue(path.is_file(), item['image'])
            self.assertFalse(item['is_3d_model'])
            self.assertEqual(item['usable_as'], 'image_preview')

    def test_gallery_controls_and_local_switching_are_present(self):
        html = (ROOT / 'frontend/index.html').read_text(encoding='utf-8')
        js = (ROOT / 'frontend/assets/app.js').read_text(encoding='utf-8')
        for control in ('character-search', 'character-filter', 'character-sort', 'character-grid', 'character-preview-image', 'character-select-button', 'character-favorite-button', 'character-result-count'):
            self.assertIn(control, html)
        self.assertIn('starpetfusion.selectedCharacter', js)
        self.assertIn('function selectCharacter', js)
        self.assertIn('function toggleFavorite', js)
        self.assertIn('starpetfusion.favoriteCharacters', js)
        self.assertIn('原生桌宠未更改', js)
        self.assertIn('prefers-reduced-motion', (ROOT / 'frontend/assets/app.css').read_text(encoding='utf-8'))

if __name__ == '__main__':
    unittest.main()
