import json
import tempfile
import unittest
from pathlib import Path

from persona_distiller import distill_persona
from skills import build_system_prompt, list_roles

class PersonaDistillerTests(unittest.TestCase):
    def test_bundled_personas_have_richer_fields(self):
        roles = list_roles()
        self.assertGreaterEqual(len(roles), 15)
        for role in roles:
            if role.directory and (role.directory / "manifest.json").exists():
                data = json.loads((role.directory / "manifest.json").read_text(encoding="utf-8"))
                if data.get("version", 0) >= 3:
                    for key in ("personality", "speech_style", "emotional_responses", "first_message", "example_dialogue"):
                        self.assertTrue(data.get(key), f"{role.slug} missing {key}")

    def test_distiller_is_bounded_and_topic_aware(self):
        role = next(r for r in list_roles() if r.slug == "firefly")
        base = distill_persona(role.directory, "你好", max_chars=1200)
        mood = distill_persona(role.directory, "我最近心情很差，想聊聊", max_chars=1200)
        self.assertLessEqual(len(base), 1220)
        self.assertIn("核心性格", base)
        self.assertIn("emotional_responses", mood)

    def test_black_tower_and_the_herta_are_distinct(self):
        roles = list_roles()
        black = next(r for r in roles if r.slug == "herta")
        the_herta = next(r for r in roles if r.slug == "the-herta")
        self.assertEqual(black.name, "黑塔")
        self.assertEqual(the_herta.name, "大黑塔")
        self.assertNotIn("大黑塔风格补充", build_system_prompt(black))
        self.assertIn("大黑塔风格补充", build_system_prompt(the_herta))

    def test_prompt_keeps_external_legacy_role_support(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); folder = root / "sample"; folder.mkdir()
            (folder / "SKILL.md").write_text("# 示例角色\n基础描述", encoding="utf-8")
            (folder / "manifest.json").write_text(json.dumps({"name":"示例角色"}, ensure_ascii=False), encoding="utf-8")
            role = list_roles(root)[0]
            self.assertIn("基础描述", build_system_prompt(role))

if __name__ == "__main__":
    unittest.main()
