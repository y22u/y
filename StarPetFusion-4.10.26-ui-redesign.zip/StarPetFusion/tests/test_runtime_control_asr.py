from runtime_control import slot, snapshot
from asr_runtime import readiness
import pytest

def test_runtime_limits_are_bounded():
    state = snapshot()
    assert state['chat']['limit'] >= 1
    assert state['tts']['limit'] >= 1
    assert state['asr']['limit'] >= 1

def test_slot_releases_after_exception():
    before = snapshot()['chat']['active']
    with pytest.raises(RuntimeError):
        with slot('chat'):
            raise RuntimeError('test')
    assert snapshot()['chat']['active'] == before

def test_asr_readiness_is_truthful():
    result = readiness()
    assert result['provider'] == 'faster-whisper'
    assert isinstance(result['ready'], bool)
