import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import integrations


class IntegrationTests(unittest.TestCase):
    def test_native_google_tts_does_not_require_generic_endpoint(self):
        with tempfile.TemporaryDirectory() as temp:
            def fake_synthesize(_text, output_path, **_kwargs):
                Path(output_path).write_bytes(b"RIFFtest")
                return Path(output_path)

            config = {"tts": {"enabled": True, "provider": "gemini_api", "endpoint": ""}}
            with patch.object(integrations, "integration_config", return_value=config), \
                 patch("tts_adapters.GoogleGeminiTTSAdapter.synthesize", side_effect=fake_synthesize), \
                 patch("subprocess.Popen") as popen:
                # The native provider must reach synthesis even when the generic URL is blank.
                self.assertTrue(integrations.external_tts("hello", "test-role"))
                popen.assert_called_once()

    def test_external_tts_rejects_insecure_remote_endpoint(self):
        config = {"tts": {"enabled": True, "provider": "external", "endpoint": "http://example.com/speech"}}
        with patch.object(integrations, "integration_config", return_value=config):
            self.assertFalse(integrations.external_tts("hello", "test-role"))

    def test_edge_tts_is_called_without_external_endpoint(self):
        with tempfile.TemporaryDirectory() as temp:
            def fake_synthesize(_text, output_path, **_kwargs):
                Path(output_path).with_suffix(".mp3").write_bytes(b"fake-mp3")
                return Path(output_path).with_suffix(".mp3")
            config = {"tts": {"enabled": True, "provider": "edge", "voice": "zh-CN-XiaoxiaoNeural"}}
            with patch.object(integrations, "integration_config", return_value=config), \
                 patch("tts_adapters.EdgeTTSAdapter.synthesize", side_effect=fake_synthesize), \
                 patch("subprocess.Popen") as popen:
                self.assertTrue(integrations.external_tts("hello", "the-herta"))
                popen.assert_called_once()


if __name__ == "__main__":
    unittest.main()
