import json
import tempfile
import unittest
from unittest.mock import Mock, patch
from pathlib import Path

from config_store import ConfigStore
from skills import build_system_prompt, list_roles
from services import AIClient, ChatStore
import install_herta_pet


class StarPetFusionCoreTests(unittest.TestCase):
    def test_config_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = ConfigStore(Path(tmp) / "config.json")
            store.set("city", "Osaka")
            loaded = ConfigStore(Path(tmp) / "config.json")
            self.assertEqual(loaded.get("city"), "Osaka")
            self.assertTrue((Path(tmp) / "config.json").is_file())

    def test_dynamic_interaction_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = ConfigStore(Path(tmp) / "config.json")
            self.assertTrue(store.get("animations_enabled"))
            self.assertFalse(store.get("idle_chatter"))

    def test_config_migrates_legacy_deepseek_model_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "config.json"
            path.write_text(json.dumps({"api_base_url": "https://api.deepseek.com/v1", "api_model": "deepseek-chat"}), encoding="utf-8")
            store = ConfigStore(path)
            self.assertEqual(store.get("api_model"), "deepseek-flash")

    def test_skill_scan_and_prompt(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            role_dir = root / "sample-role"
            role_dir.mkdir()
            (role_dir / "SKILL.md").write_text("# 示例角色\n基础描述", encoding="utf-8")
            (role_dir / "manifest.json").write_text(json.dumps({"name": "示例角色"}, ensure_ascii=False), encoding="utf-8")
            (role_dir / "personality.md").write_text("沉着、好奇", encoding="utf-8")
            roles = list_roles(root)
            self.assertEqual(len(roles), 1)
            self.assertEqual(roles[0].name, "示例角色")
            prompt = build_system_prompt(roles[0])
            self.assertIn("示例角色", prompt)
            self.assertIn("沉着、好奇", prompt)


    def test_herta_installer_does_not_overwrite_by_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source"
            source.mkdir()
            (source / "pet.json").write_text(json.dumps({"spriteVersionNumber": 2, "spritesheetPath": "spritesheet.webp"}), encoding="utf-8")
            (source / "spritesheet.webp").write_bytes(b"source image placeholder")
            original_source = install_herta_pet.SOURCE
            install_herta_pet.SOURCE = source
            try:
                codex_home = root / "codex"
                destination = install_herta_pet.install_herta_pet(codex_home)
                self.assertTrue((destination / "pet.json").is_file())
                (destination / "spritesheet.webp").write_bytes(b"different existing file")
                with self.assertRaises(FileExistsError):
                    install_herta_pet.install_herta_pet(codex_home)
                install_herta_pet.install_herta_pet(codex_home, force=True)
                self.assertEqual((destination / "spritesheet.webp").read_bytes(), b"source image placeholder")
            finally:
                install_herta_pet.SOURCE = original_source

    @patch("services.requests.post")
    def test_ollama_local_api_does_not_require_key(self, mock_post):
        response = Mock()
        response.raise_for_status.return_value = None
        response.json.return_value = {"choices": [{"message": {"content": "连接成功"}}]}
        mock_post.return_value = response
        client = AIClient({
            "provider": "ollama",
            "api_base_url": "http://localhost:11434/v1",
            "api_model": "qwen2.5:3b",
            "api_key": "",
        })
        answer = client.chat([{"role": "user", "content": "你好"}])
        self.assertEqual(answer, "连接成功")
        args, kwargs = mock_post.call_args
        self.assertEqual(args[0], "http://localhost:11434/v1/chat/completions")
        self.assertNotIn("Authorization", kwargs["headers"])

    def test_herta_prompt_override_is_appended(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            role_dir = root / "the_herta"
            role_dir.mkdir()
            (role_dir / "SKILL.md").write_text("# 大黑塔\n天才", encoding="utf-8")
            role = list_roles(root)[0]
            prompt = build_system_prompt(role, "请保持简洁和自信")
            self.assertIn("大黑塔风格补充", prompt)
            self.assertIn("请保持简洁和自信", prompt)

    def test_chat_history_is_role_separated(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = ChatStore(Path(tmp) / "chat.sqlite3")
            store.add("one", "user", "你好")
            store.add("one", "assistant", "你好呀")
            store.add("two", "user", "另一条")
            self.assertEqual(len(store.history("one")), 2)
            self.assertEqual(len(store.history("two")), 1)
            store.clear("one")
            self.assertEqual(store.history("one"), [])
            self.assertEqual(len(store.history("two")), 1)

    def test_bundled_hsr_female_roles_are_available(self):
        from skills import list_roles
        roles = list_roles()
        names = {role.name for role in roles}
        for name in ("大黑塔", "卡芙卡", "三月七", "阮·梅", "流萤", "黄泉", "镜流", "银狼", "黑天鹅", "符玄", "托帕"):
            self.assertIn(name, names)
        herta = next(role for role in roles if role.name == "大黑塔")
        self.assertIn("研究者", build_system_prompt(herta))


if __name__ == "__main__":
    unittest.main()
