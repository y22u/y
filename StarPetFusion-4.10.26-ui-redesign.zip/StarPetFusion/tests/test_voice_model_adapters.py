import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from tts_adapters import EdgeTTSAdapter

class EdgeTTSAdapterTests(unittest.TestCase):
    def test_edge_adapter_saves_mp3_without_api_key(self):
        class FakeCommunicate:
            def __init__(self, text, voice, rate):
                self.text, self.voice, self.rate = text, voice, rate
            async def save(self, path):
                Path(path).write_bytes(b"fake-mp3-audio")
        fake = types.SimpleNamespace(Communicate=FakeCommunicate)
        with tempfile.TemporaryDirectory() as tmp, patch.dict(sys.modules, {"edge_tts": fake}):
            result = EdgeTTSAdapter().synthesize("你好", Path(tmp) / "voice.wav")
            self.assertEqual(result.suffix, ".mp3")
            self.assertTrue(result.exists())
            self.assertGreater(result.stat().st_size, 0)

    def test_edge_adapter_rejects_empty_text(self):
        with self.assertRaises(ValueError):
            EdgeTTSAdapter().synthesize("  ", "unused.mp3")

try:
    from fastapi.testclient import TestClient
    from backend.app.main import app
    CLIENT = TestClient(app)
except Exception:
    CLIENT = None

@unittest.skipIf(CLIENT is None, "fastapi/testclient not installed")
class VoiceGatewayTests(unittest.TestCase):
    def test_connector_catalog_includes_voice_models(self):
        body = CLIENT.get('/api/v1/connectors').json()
        ids = {item['id'] for item in body['items']}
        self.assertTrue({'edge_tts', 'qwen3_tts', 'indextts'}.issubset(ids))

    def test_edge_tts_route_returns_mp3(self):
        def fake_synth(self, text, output_path, **kwargs):
            p = Path(output_path).with_suffix('.mp3')
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b'fake-mp3-audio')
            return p
        with patch('tts_adapters.EdgeTTSAdapter.synthesize', fake_synth):
            r = CLIENT.post('/api/v1/tts', json={'provider':'edge', 'text':'你好'})
        self.assertEqual(r.status_code, 200)
        self.assertIn('audio/mpeg', r.headers.get('content-type', ''))
        self.assertEqual(r.content, b'fake-mp3-audio')

if __name__ == '__main__': unittest.main()
