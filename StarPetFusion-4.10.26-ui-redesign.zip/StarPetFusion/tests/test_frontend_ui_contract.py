from collections import Counter
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class FrontendParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.sections = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get("id"):
            self.ids.append(attrs["id"])
        if tag == "section" and attrs.get("id"):
            self.sections.append(attrs["id"])


def test_frontend_page_ids_are_unique_and_navigation_targets_exist():
    parser = FrontendParser()
    parser.feed((ROOT / "frontend" / "index.html").read_text(encoding="utf-8"))
    duplicates = [key for key, count in Counter(parser.ids).items() if count > 1]
    assert duplicates == []
    for page in ("overview", "agent", "characters", "model-hub", "automation", "voice", "connectors", "security"):
        assert page in parser.sections


def test_agent_and_tts_forms_have_matching_script_targets():
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (ROOT / "frontend" / "assets" / "app.js").read_text(encoding="utf-8")
    for element_id in ("agent-provider", "chat-form", "chat-log", "chat-input", "chat-status", "tts-form-status"):
        assert f'id="{element_id}"' in html
    assert "$('#chat-form').addEventListener('submit'" in js
    assert "$('#tts-form-status')" in js


def test_redesign_styles_include_mobile_and_reduced_motion_support():
    css = (ROOT / "frontend" / "assets" / "app.css").read_text(encoding="utf-8")
    assert "@media(max-width:650px)" in css
    assert "prefers-reduced-motion:reduce" in css
    assert ".agent-layout" in css and ".character-grid" in css and ".automation" not in css
