import tempfile
import unittest
from pathlib import Path
from skills import Role, _merged_roles, build_system_prompt
import skills

class MergedRosterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.bundled = self.base / "bundled"
        self.vendor = self.base / "vendor"
        self.bundled.mkdir(); self.vendor.mkdir()
        self._old_bundled = skills.BUNDLED_ROLES_ROOT
        self._old_vendor = skills.SKILLS_ROOT
        skills.BUNDLED_ROLES_ROOT = self.bundled
        skills.SKILLS_ROOT = self.vendor

    def tearDown(self):
        skills.BUNDLED_ROLES_ROOT = self._old_bundled
        skills.SKILLS_ROOT = self._old_vendor
        self.tmp.cleanup()

    def _card(self, root, slug, name, text):
        folder = root / slug; folder.mkdir()
        (folder / "manifest.json").write_text('{"slug": "%s", "name": "%s"}' % (slug, name), encoding="utf-8")
        (folder / "SKILL.md").write_text('# %s\n\n%s' % (name, text), encoding="utf-8")
        return folder

    def test_merge_matches_by_localized_name_and_preserves_bundled_identity(self):
        b = self._card(self.bundled, "the-herta", "大黑塔", "内置优先设定")
        u = self._card(self.vendor, "herta-upstream", "大黑塔", "上游补充知识")
        roles = _merged_roles()
        self.assertEqual(len(roles), 1)
        self.assertEqual(roles[0].slug, "the-herta")
        self.assertEqual(roles[0].directory, b)
        self.assertEqual(roles[0].reference_directory, u)

    def test_upstream_only_character_is_added_once_and_sorted(self):
        self._card(self.bundled, "the-herta", "大黑塔", "内置")
        self._card(self.vendor, "firefly", "流萤", "上游角色")
        roles = _merged_roles()
        self.assertEqual({r.name for r in roles}, {"大黑塔", "流萤"})
        self.assertEqual(len({r.slug for r in roles}), len(roles))

    def test_upstream_reference_content_is_available_to_prompt(self):
        b = self._card(self.bundled, "the-herta", "大黑塔", "内置优先设定")
        u = self._card(self.vendor, "herta-upstream", "大黑塔", "上游补充知识")
        role = Role("the-herta", "大黑塔", b, u)
        prompt = build_system_prompt(role)
        self.assertIn("上游补充知识", prompt)

if __name__ == "__main__":
    unittest.main()
