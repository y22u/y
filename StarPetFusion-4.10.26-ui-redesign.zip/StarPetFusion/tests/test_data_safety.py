import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import data_safety
from agent_tools import AgentToolGateway

class DataSafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.appdata = self.base / 'appdata'
        self.root = self.base / 'approved'
        self.root.mkdir()
        self.target = self.root / 'note.txt'
        self.target.write_text('original\n', encoding='utf-8')
        self.patcher = patch.object(data_safety, 'app_data_dir', return_value=self.appdata)
        self.patcher.start()
    def tearDown(self):
        self.patcher.stop(); self.tmp.cleanup()
    def test_existing_file_is_backed_up_before_confirmed_overwrite(self):
        gateway = AgentToolGateway([self.root])
        staged = gateway.execute('stage_text_file', {'root_index':0,'relative_path':'note.txt','content':'replacement\n'})
        self.assertTrue(staged['ok']); self.assertIn('original', staged['existing_preview'])
        done = gateway.confirm_write(staged['confirmation_token'], True)
        self.assertTrue(done['ok']); self.assertTrue(done['backup']['created'])
        self.assertEqual(self.target.read_text(encoding='utf-8'), 'replacement\n')
        backups = data_safety.list_backups(); self.assertEqual(len(backups), 1)
        restored = data_safety.restore_backup(backups[0]['id'])
        self.assertTrue(restored['restored'])
        self.assertEqual(self.target.read_text(encoding='utf-8'), 'original\n')
    def test_cancelled_write_does_not_create_backup(self):
        gateway = AgentToolGateway([self.root])
        staged = gateway.execute('stage_text_file', {'root_index':0,'relative_path':'note.txt','content':'no'})
        gateway.confirm_write(staged['confirmation_token'], False)
        self.assertEqual(data_safety.list_backups(), [])
        self.assertEqual(self.target.read_text(encoding='utf-8'), 'original\n')
    def test_backup_size_limit_blocks_overwrite(self):
        self.target.write_bytes(b'x' * (data_safety.MAX_BACKUP_BYTES + 1))
        gateway = AgentToolGateway([self.root])
        staged = gateway.execute('stage_text_file', {'root_index':0,'relative_path':'note.txt','content':'small'})
        with self.assertRaises(ValueError): gateway.confirm_write(staged['confirmation_token'], True)
        self.assertEqual(self.target.stat().st_size, data_safety.MAX_BACKUP_BYTES + 1)
    def test_restore_rejects_invalid_backup_id(self):
        with self.assertRaises(ValueError): data_safety.restore_backup('../oops')

if __name__ == '__main__': unittest.main()
