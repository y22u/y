import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class AudioReviewToolTests(unittest.TestCase):
    def test_packaged_annotation_has_36_rows_and_no_guessed_identity(self):
        p = ROOT / 'data' / 'audio_review' / 'audio_annotation.csv'
        with p.open(encoding='utf-8-sig', newline='') as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 36)
        self.assertTrue(all(r['file_check'] == 'ok' for r in rows))
        self.assertTrue(all(r['human_role_confirmation'] == '待人工确认' for r in rows))
        self.assertTrue(all(r['review_status'].startswith('已完成声学测量') for r in rows))

    def test_report_marks_semantic_labels_pending(self):
        p = ROOT / 'data' / 'audio_review' / 'audio_signal_report.json'
        data = json.loads(p.read_text(encoding='utf-8'))
        self.assertEqual(data['audio_files_analyzed'], 36)
        self.assertIn('transcript', data['labels_left_pending'])
        self.assertIn('human_role_confirmation', data['labels_left_pending'])

if __name__ == '__main__':
    unittest.main()
