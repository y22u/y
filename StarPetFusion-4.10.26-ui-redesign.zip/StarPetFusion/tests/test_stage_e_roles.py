import json
import unittest
from pathlib import Path
from skills import list_roles

ROOT = Path(__file__).resolve().parents[1]

class StageERoleResearchTests(unittest.TestCase):
    def test_added_roles_are_discoverable(self):
        roles = {r.slug: r for r in list_roles()}
        expected = {'sparkle', 'feixiao', 'jade', 'fugue', 'tribbie', 'castorice', 'cipher', 'the-dahlia'}
        self.assertTrue(expected.issubset(roles.keys()), f'missing: {expected - roles.keys()}')

    def test_every_bundled_manifest_has_provenance_and_profile_fields(self):
        for manifest_path in (ROOT / 'bundled_roles').glob('*/manifest.json'):
            data = json.loads(manifest_path.read_text(encoding='utf-8'))
            self.assertTrue(data.get('name'), manifest_path)
            self.assertTrue(data.get('official_sources'), manifest_path)
            self.assertTrue(data.get('source_notes'), manifest_path)
            self.assertTrue(data.get('canon_vs_fan_extension'), manifest_path)
            for field in ('personality', 'speech_style', 'emotional_responses', 'first_message', 'example_dialogue'):
                self.assertTrue(data.get(field), f'{manifest_path} missing {field}')

    def test_role_source_index_matches_bundled_roster(self):
        index = json.loads((ROOT / 'official_data' / 'character_sources.json').read_text(encoding='utf-8'))
        actual = sorted(p.name for p in (ROOT / 'bundled_roles').iterdir() if p.is_dir() and (p / 'manifest.json').exists())
        self.assertEqual(index['role_coverage'], actual)
        self.assertGreaterEqual(len(actual), 24)

    def test_new_role_prompts_are_available_and_bounded(self):
        roles = {r.slug: r for r in list_roles()}
        for slug in ('sparkle', 'feixiao', 'jade', 'fugue', 'tribbie', 'castorice', 'cipher', 'the-dahlia'):
            role = roles[slug]
            self.assertIn(role.name, role.name)
            self.assertIn('区分', __import__('skills').build_system_prompt(role, user_text='我想聊聊角色设定'))

if __name__ == '__main__':
    unittest.main()
