import unittest
from unittest.mock import Mock, patch

from ollama_manager import OllamaManager, normalize_ollama_url


class OllamaManagerTests(unittest.TestCase):
    def test_normalizes_legacy_openai_url(self):
        self.assertEqual(normalize_ollama_url('http://localhost:11434/v1'), 'http://localhost:11434')

    def test_rejects_non_loopback_http(self):
        with self.assertRaises(ValueError):
            OllamaManager('http://192.168.1.20:11434')

    @patch('ollama_manager.requests.request')
    def test_lists_installed_models(self, request):
        response = Mock()
        response.json.return_value = {'models': [{'name': 'qwen2.5:3b', 'size': 123}, {'name': 'llama3.2:3b'}]}
        response.raise_for_status.return_value = None
        request.return_value = response
        models = OllamaManager().list_models()
        self.assertEqual([m['name'] for m in models], ['qwen2.5:3b', 'llama3.2:3b'])
        self.assertEqual(request.call_args.args[:2], ('GET', 'http://127.0.0.1:11434/api/tags'))

    @patch('ollama_manager.requests.request')
    def test_lists_running_models_with_memory_fields(self, request):
        response = Mock()
        response.json.return_value = {'models': [{'name': 'qwen2.5:3b', 'size': 2 * 1024**3,
            'size_vram': 1536 * 1024**2, 'context_length': 8192, 'expires_at': '2026-10-28T12:00:00Z'}]}
        response.raise_for_status.return_value = None
        request.return_value = response
        models = OllamaManager().list_running_models()
        self.assertEqual(models[0]['name'], 'qwen2.5:3b')
        self.assertEqual(models[0]['context_length'], 8192)
        self.assertIn('GB', models[0]['size_human'])
        self.assertIn('GB', models[0]['vram_human'])
        self.assertEqual(request.call_args.args[:2], ('GET', 'http://127.0.0.1:11434/api/ps'))

    @patch('ollama_manager.requests.request')
    def test_reads_ollama_version(self, request):
        response = Mock()
        response.json.return_value = {'version': '0.13.0'}
        response.raise_for_status.return_value = None
        request.return_value = response
        self.assertEqual(OllamaManager().version(), '0.13.0')

    @patch('ollama_manager.requests.post')
    def test_pull_model_reads_progress_stream(self, post):
        response = Mock()
        response.__enter__ = Mock(return_value=response)
        response.__exit__ = Mock(return_value=False)
        response.iter_lines.return_value = [b'{"status":"downloading","total":100,"completed":50}', b'{"status":"success"}']
        response.raise_for_status.return_value = None
        post.return_value = response
        events = []
        OllamaManager().pull_model('qwen2.5:3b', events.append)
        self.assertEqual(len(events), 2)
        self.assertEqual(events[0]['completed'], 50)


if __name__ == '__main__':
    unittest.main()
