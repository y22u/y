import ast
import unittest
from pathlib import Path


class StageDMenuBindingTests(unittest.TestCase):
    def test_menu_callback_exists_on_app_controller(self):
        source = Path(__file__).resolve().parents[1] / "main.py"
        tree = ast.parse(source.read_text(encoding="utf-8"))
        controller = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "AppController")
        methods = {node.name for node in controller.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        self.assertIn("stage_d_settings", methods)

    def test_stage_d_callback_is_connected(self):
        source = Path(__file__).resolve().parents[1] / "main.py"
        text = source.read_text(encoding="utf-8")
        self.assertIn("stage_d.triggered.connect(self.stage_d_settings)", text)


if __name__ == "__main__":
    unittest.main()
