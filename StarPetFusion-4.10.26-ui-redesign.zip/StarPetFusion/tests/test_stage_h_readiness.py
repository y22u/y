import unittest
from unittest.mock import patch

try:
    from fastapi.testclient import TestClient
    from backend.app.main import app
    CLIENT = TestClient(app)
except Exception:
    CLIENT = None

@unittest.skipIf(CLIENT is None, 'fastapi/testclient not installed')
class ReadinessTests(unittest.TestCase):
    def test_diagnostics_never_returns_secret_values(self):
        with patch('integrations.integration_config', return_value={'external_agent': {'enabled': True, 'endpoint': 'http://127.0.0.1:1/v1', 'model': 'test', 'api_key_env': 'STAR_PET_TEST_SECRET'}}), patch.dict('os.environ', {'STAR_PET_TEST_SECRET':'do-not-leak'}):
            response = CLIENT.get('/api/v1/diagnostics')
        self.assertEqual(response.status_code, 200)
        self.assertNotIn('do-not-leak', response.text)
        ids = {x['id'] for x in response.json()['checks']}
        self.assertTrue({'edge_tts','qwen3_tts','indextts','ollama','external_agent'}.issubset(ids))
    def test_diagnostics_marks_local_unavailable_as_not_ready(self):
        with patch('requests.get', side_effect=__import__('requests').ConnectionError('unavailable')):
            response = CLIENT.get('/api/v1/diagnostics')
        self.assertEqual(response.status_code, 200)
        items = {x['id']:x for x in response.json()['checks']}
        self.assertIn('qwen3_tts', items)
        self.assertIn('indextts', items)

if __name__ == '__main__': unittest.main()
