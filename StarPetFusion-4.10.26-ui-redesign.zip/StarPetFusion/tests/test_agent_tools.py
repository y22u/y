import tempfile, unittest
from pathlib import Path
from agent_tools import AgentToolGateway

class AgentToolGatewayTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        (self.root/'hello.txt').write_text('alpha\nbeta alpha\n',encoding='utf-8')
        self.g=AgentToolGateway([self.root])
    def tearDown(self): self.tmp.cleanup()
    def test_search_and_read_are_allowlisted(self):
        r=self.g.execute('search_files',{'root_index':0,'query':'alpha'})
        self.assertTrue(r['ok']); self.assertEqual(len(r['results']),2)
        r=self.g.execute('read_text_file',{'root_index':0,'relative_path':'hello.txt'})
        self.assertIn('beta',r['content'])
    def test_path_traversal_blocked(self):
        r=self.g.execute('read_text_file',{'root_index':0,'relative_path':'../outside.txt'})
        self.assertFalse(r['ok'])
    def test_write_requires_confirmation(self):
        r=self.g.execute('stage_text_file',{'root_index':0,'relative_path':'new.txt','content':'approved'})
        self.assertTrue(r['requires_confirmation']); self.assertFalse((self.root/'new.txt').exists())
        done=self.g.confirm_write(r['confirmation_token'],True)
        self.assertTrue(done['ok']); self.assertEqual((self.root/'new.txt').read_text(), 'approved')
    def test_cancelled_write_does_not_write(self):
        r=self.g.execute('stage_text_file',{'root_index':0,'relative_path':'new.txt','content':'no'})
        self.g.confirm_write(r['confirmation_token'],False)
        self.assertFalse((self.root/'new.txt').exists())
    def test_write_preview_is_available_before_confirmation(self):
        r=self.g.execute('stage_text_file',{'root_index':0,'relative_path':'preview.txt','content':'hello'})
        self.assertEqual(r['preview'],'hello')
        self.assertFalse((self.root/'preview.txt').exists())

    def test_write_limit_is_measured_in_utf8_bytes(self):
        r=self.g.execute('stage_text_file',{'root_index':0,'relative_path':'large.txt','content':'界'*70000})
        self.assertFalse(r['ok'])

    def test_unknown_tool_rejected(self):
        self.assertFalse(self.g.execute('run_shell',{} )['ok'])

if __name__=='__main__': unittest.main()
