import unittest
from unittest.mock import patch
import resource_monitor

class ResourceMonitorTests(unittest.TestCase):
    def test_low_memory_recommends_serial_chat(self):
        with patch.object(resource_monitor, "_memory_bytes", return_value=(8 * 1024**3, 2 * 1024**3, "test")), \
             patch.object(resource_monitor, "_gpu_memory", return_value=None):
            result = resource_monitor.resource_snapshot()
        self.assertEqual(result["advice"]["recommended_chat_concurrency"], 1)
        self.assertEqual(result["advice"]["level"], "critical")
        self.assertFalse(result["advice"]["applied_automatically"])

    def test_plenty_memory_has_bounded_recommendation(self):
        with patch.object(resource_monitor, "_memory_bytes", return_value=(32 * 1024**3, 20 * 1024**3, "test")), \
             patch.object(resource_monitor, "_gpu_memory", return_value=None):
            result = resource_monitor.resource_snapshot()
        self.assertEqual(result["advice"]["recommended_chat_concurrency"], 3)
        self.assertIn("caveat", result)

if __name__ == "__main__": unittest.main()
