import io
import urllib.error
from unittest.mock import patch
import tempfile
import unittest
import zipfile
from pathlib import Path

from prepare import download, safe_extract, validate_role_pack


class PrepareTests(unittest.TestCase):
    def test_extracts_github_archive_without_top_folder(self):
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr("demo-main/README.md", "hello")
            archive.writestr("demo-main/nested/file.txt", "world")
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "out"
            target.mkdir()
            safe_extract(buffer.getvalue(), target)
            self.assertEqual((target / "README.md").read_text(), "hello")
            self.assertEqual((target / "nested" / "file.txt").read_text(), "world")

    def test_role_pack_validation_rejects_empty_download(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "hsr-skills"
            root.mkdir()
            with self.assertRaises(RuntimeError):
                validate_role_pack(root, required=True)

    def test_role_pack_validation_counts_role_cards(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "hsr-skills"
            role = root / "the-herta"
            role.mkdir(parents=True)
            (role / "SKILL.md").write_text("# The Herta", encoding="utf-8")
            self.assertEqual(validate_role_pack(root, required=True), 1)

    def test_rejects_path_traversal(self):
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr("demo-main/../../evil.txt", "unsafe")
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "out"
            target.mkdir()
            with self.assertRaises(RuntimeError):
                safe_extract(buffer.getvalue(), target)

    def test_download_retries_after_transient_network_error(self):
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr("demo-main/README.md", "hello")
        payload = buffer.getvalue()
        with patch("prepare.urllib.request.urlopen", side_effect=[urllib.error.URLError("temporary"), io.BytesIO(payload)]):
            with patch("prepare.time.sleep"):
                self.assertEqual(download("https://example.invalid/archive.zip", retries=2), payload)


if __name__ == "__main__":
    unittest.main()
