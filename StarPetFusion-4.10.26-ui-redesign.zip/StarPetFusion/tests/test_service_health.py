import unittest
from service_health import validate_ai_config, validate_endpoint, validate_integration_config
from app_logging import redact


class ServiceHealthTests(unittest.TestCase):
    def test_endpoint_policy_accepts_https_and_loopback_only(self):
        self.assertTrue(validate_endpoint('https://api.example.com/v1'))
        self.assertTrue(validate_endpoint('http://localhost:11434/v1'))
        self.assertFalse(validate_endpoint('http://example.com/api'))
        self.assertFalse(validate_endpoint('file:///etc/passwd'))

    def test_ai_config_reports_missing_model_and_bad_endpoint(self):
        checks = validate_ai_config({'provider': 'deepseek', 'api_base_url': 'http://example.com', 'api_model': ''})
        by_name = {item.name: item for item in checks}
        self.assertEqual(by_name['ai.model'].status, 'FAIL')
        self.assertEqual(by_name['ai.endpoint'].status, 'FAIL')

    def test_native_tts_config_does_not_need_generic_endpoint(self):
        checks = validate_integration_config({'tts': {'enabled': True, 'provider': 'gemini_api', 'endpoint': ''}, 'agent_tools': {'roots': []}})
        by_name = {item.name: item for item in checks}
        self.assertEqual(by_name['tts'].status, 'PASS')
        self.assertEqual(by_name['agent.roots'].status, 'PASS')

    def test_secret_redaction(self):
        value = redact('Authorization: Bearer abc123 api_key=secretXYZ access_token=token123')
        self.assertNotIn('abc123', value)
        self.assertNotIn('secretXYZ', value)
        self.assertNotIn('token123', value)
        self.assertIn('[REDACTED]', value)


if __name__ == '__main__':
    unittest.main()
