import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import voice_router


class VoiceRouterTests(unittest.TestCase):
    def test_manifest_requires_exact_role_text_authorization_and_hash(self):
        root = Path(voice_router.__file__).resolve().parent
        with tempfile.TemporaryDirectory(dir=root) as temp:
            folder = Path(temp)
            audio = folder / "licensed.wav"
            audio.write_bytes(b"authorized audio bytes")
            digest = hashlib.sha256(audio.read_bytes()).hexdigest()
            manifest = folder / "manifest.json"
            manifest.write_text(json.dumps({"items": [{
                "character_id": "the-herta", "text_normalized": "你好 世界",
                "path": str(audio.relative_to(root)), "sha256": digest,
                "authorization_verified": True
            }]}), encoding="utf-8")
            cfg = {"licensed_manifest": str(manifest.relative_to(root))}
            self.assertEqual(voice_router.find_licensed_recording("你好   世界", "the-herta", cfg), audio)
            self.assertIsNone(voice_router.find_licensed_recording("你好世界", "the-herta", cfg))
            self.assertIsNone(voice_router.find_licensed_recording("你好 世界", "kafka", cfg))
            manifest.write_text(json.dumps({"items": [{
                "character_id": "the-herta", "text_normalized": "你好 世界",
                "path": str(audio.relative_to(root)), "sha256": digest,
                "authorization_verified": False
            }]}), encoding="utf-8")
            self.assertIsNone(voice_router.find_licensed_recording("你好 世界", "the-herta", cfg))

    def test_manifest_rejects_path_traversal(self):
        cfg = {"licensed_manifest": "../outside.json"}
        self.assertIsNone(voice_router.find_licensed_recording("hi", "the-herta", cfg))

    def test_online_edge_is_disabled_by_default(self):
        cfg = voice_router.load_router_config()
        self.assertFalse(cfg["allow_online"])

    def test_router_falls_through_to_next_engine(self):
        with patch.object(voice_router, "load_router_config", return_value={
            "enabled": True, "allow_online": False,
            "priorities": ["licensed_audio", "qwen3", "indextts", "edge"],
            "licensed_manifest": "licensed_audio/manifest.json", "cache_enabled": False,
            "timeout_seconds": 10, "sidecar_timeout_seconds": 10,
        }), patch.object(voice_router, "find_licensed_recording", return_value=None), \
             patch.object(voice_router, "_synthesize", side_effect=[RuntimeError("qwen down"), RuntimeError("index down")]), \
             patch.object(voice_router, "_play", return_value=True):
            # Both local engines fail, online Edge is opt-out, so no voice is reported as played.
            self.assertFalse(voice_router.route_and_play("hello", "the-herta", {}))

    def test_empty_text_does_not_attempt_playback(self):
        with patch.object(voice_router, "load_router_config", return_value={"enabled": True, "priorities": []}):
            self.assertFalse(voice_router.route_and_play("  ", "default", {}))

    def test_manifest_rejects_expired_authorization(self):
        root = Path(voice_router.__file__).resolve().parent
        with tempfile.TemporaryDirectory(dir=root) as temp:
            folder = Path(temp)
            audio = folder / "licensed.wav"
            audio.write_bytes(b"audio")
            manifest = folder / "manifest.json"
            manifest.write_text(json.dumps({"items": [{
                "character_id": "the-herta", "text_normalized": "hello",
                "path": str(audio.relative_to(root)),
                "sha256": hashlib.sha256(audio.read_bytes()).hexdigest(),
                "authorization_verified": True,
                "authorization_expires": "2000-01-01"
            }]}), encoding="utf-8")
            cfg = {"licensed_manifest": str(manifest.relative_to(root))}
            self.assertIsNone(voice_router.find_licensed_recording("hello", "the-herta", cfg))

    def test_manifest_rejects_audio_hash_mismatch(self):
        root = Path(voice_router.__file__).resolve().parent
        with tempfile.TemporaryDirectory(dir=root) as temp:
            folder = Path(temp)
            audio = folder / "licensed.wav"
            audio.write_bytes(b"actual bytes")
            manifest = folder / "manifest.json"
            manifest.write_text(json.dumps({"items": [{
                "character_id": "the-herta", "text_normalized": "hello",
                "path": str(audio.relative_to(root)), "sha256": "0" * 64,
                "authorization_verified": True
            }]}), encoding="utf-8")
            cfg = {"licensed_manifest": str(manifest.relative_to(root))}
            self.assertIsNone(voice_router.find_licensed_recording("hello", "the-herta", cfg))

    def test_config_filters_unknown_priority_entries_and_keeps_online_opt_in(self):
        with patch.object(voice_router, "app_data_dir", return_value=Path(tempfile.mkdtemp())):
            cfg = voice_router.load_router_config()
        self.assertEqual(cfg["priorities"], voice_router.DEFAULT_CONFIG["priorities"])
        self.assertFalse(cfg["allow_online"])


if __name__ == "__main__":
    unittest.main()
