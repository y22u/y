import csv, json, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace
import tools.transcribe_audio_review as asr_module
from tools.transcribe_audio_review import run_transcription

class FakeModel:
    def transcribe(self, path, **kwargs):
        seg = SimpleNamespace(start=0.2, end=1.8, text=' Hello world', words=[
            SimpleNamespace(start=0.2, end=0.7, word=' Hello', probability=0.98),
            SimpleNamespace(start=0.8, end=1.8, word=' world', probability=0.97)])
        return iter([seg]), SimpleNamespace(language='en', language_probability=0.99)

class TranscribeTests(unittest.TestCase):
    def test_transcript_and_segments_written(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'clip.mp3').write_bytes(b'test')
            csv_path=root/'annotations.csv'; seg_path=root/'segments.json'
            with csv_path.open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.DictWriter(f,fieldnames=['index','audio_file','transcript','language','duration_seconds_measured','human_role_confirmation','speaker_count','review_status'])
                w.writeheader(); w.writerow({'index':'1','audio_file':'clip.mp3','transcript':'','duration_seconds_measured':'2','human_role_confirmation':'待人工确认','speaker_count':'待人工确认'})
            asr_module.DEFAULT_SEGMENTS = seg_path
            summary=run_transcription(csv_path,root,'small','cpu','int8',None,False,FakeModel())
            with csv_path.open(encoding='utf-8-sig',newline='') as f: row=next(csv.DictReader(f))
            self.assertEqual(row['transcript'],'Hello world')
            self.assertEqual(row['language'],'en')
            self.assertEqual(summary['completed_this_run'],1)
            segments=json.loads(seg_path.read_text(encoding='utf-8'))
            self.assertEqual(segments[0]['segments'][0]['text'],'Hello world')

if __name__=='__main__': unittest.main()
