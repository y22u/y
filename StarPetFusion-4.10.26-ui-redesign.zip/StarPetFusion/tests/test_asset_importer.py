import importlib.util
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('download_hsr_assets', ROOT / 'download_hsr_assets.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

class AssetImporterTests(unittest.TestCase):
    def test_default_roles_have_aliases(self):
        for slug in ('the-herta', 'aglaea', 'hyacine'):
            self.assertIn(slug, MODULE.ALIASES)
            self.assertTrue(MODULE.ALIASES[slug])

    def test_supported_extensions_are_images_only(self):
        self.assertIn('.png', MODULE.EXTS)
        self.assertIn('.webp', MODULE.EXTS)
        self.assertNotIn('.exe', MODULE.EXTS)
        self.assertNotIn('.zip', MODULE.EXTS)

    def test_catalog_is_valid_and_curated(self):
        import json
        catalog = json.loads((ROOT / 'HSR_GITHUB_INTEGRATION_CATALOG.json').read_text(encoding='utf-8'))
        ids = {x['id'] for x in catalog['sources']}
        self.assertIn('hsr-skills', ids)
        self.assertIn('starrailres', ids)
        self.assertGreaterEqual(len(ids), 5)

if __name__ == '__main__':
    unittest.main()
