import unittest

try:
    from fastapi.testclient import TestClient
    from backend.app.main import app
    CLIENT = TestClient(app)
except Exception:
    CLIENT = None

@unittest.skipIf(CLIENT is None, "fastapi/testclient not installed")
class ServiceApiTests(unittest.TestCase):
    def test_health(self):
        r = CLIENT.get('/api/v1/health')
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()['status'], 'ok')
    def test_connectors_never_return_secret_value(self):
        r = CLIENT.get('/api/v1/connectors')
        self.assertEqual(r.status_code, 200)
        body = r.text.lower()
        self.assertNotIn('api_key_value', body)
        self.assertIn('external_agent', body)
    def test_multi_agent_profile_provider_is_routed(self):
        from unittest.mock import patch
        profile = {'enabled': True, 'endpoint': 'https://example.invalid/v1', 'model': 'demo', 'api_key_env': 'DEMO_KEY'}
        with patch('integrations.integration_config', return_value={'agent_profiles': {'demo_agent': profile}}), patch('external_agent.ExternalAgentClient.chat', return_value='profile-ok'):
            r = CLIENT.post('/api/v1/chat', json={'message':'hello', 'provider':'agent_profile:demo_agent'})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()['reply'], 'profile-ok')
    def test_diagnostics_reports_version_and_checks(self):
        r = CLIENT.get('/api/v1/diagnostics')
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()['version'], '4.10.26')
        self.assertIn('edge_tts', {x['id'] for x in r.json()['checks']})
        self.assertIn('resources', r.json())
        self.assertIn('recommended_chat_concurrency', r.json()['resources']['advice'])
    def test_model_hub_assignments_endpoint_has_role_defaults(self):
        r = CLIENT.get('/api/v1/model-hub/assignments')
        self.assertEqual(r.status_code, 200)
        self.assertIn('agent', r.json()['assignments'])
        self.assertIn('asr_endpoint', r.json()['assignments'])
    def test_automation_api_exposes_persistent_task_queue_and_blocks_unsafe_hosts(self):
        import tempfile
        from pathlib import Path
        import autonomous_tasks as tasks
        old_db = tasks.DB_PATH
        with tempfile.TemporaryDirectory() as td:
            try:
                tasks.DB_PATH = Path(td) / 'tasks.sqlite3'
                tasks._init_db()
                status = CLIENT.get('/api/v1/automation/status')
                self.assertEqual(status.status_code, 200)
                created = CLIENT.post('/api/v1/automation/tasks', json={'task_type':'health_check','payload':{},'title':'test task'})
                self.assertEqual(created.status_code, 200)
                self.assertEqual(created.json()['task']['status'], 'queued')
                rejected = CLIENT.post('/api/v1/automation/tasks', json={'task_type':'ollama_inventory','payload':{'base_url':'http://example.com:11434'}})
                self.assertEqual(rejected.status_code, 400)
            finally:
                tasks.DB_PATH = old_db
    def test_chat_rejects_empty_message(self):
        r = CLIENT.post('/api/v1/chat', json={'message':''})
        self.assertEqual(r.status_code, 422)
    def test_homepage_served(self):
        r = CLIENT.get('/')
        self.assertEqual(r.status_code, 200)
        self.assertIn('StarPetFusion', r.text)

if __name__ == '__main__': unittest.main()

# Character voice studio endpoints are local-only metadata and authorization gated.
def _test_character_voice_studio_endpoints():
    from fastapi.testclient import TestClient
    from backend.app.main import app
    client = TestClient(app)
    listing = client.get('/api/v1/character-voices')
    assert listing.status_code == 200
    body = listing.json()
    assert len(body['characters']) >= 10
    assert 'indextts' in body['providers']
    denied = client.post('/api/v1/character-voices/the-herta/reference?authorization_confirmed=false&authorization_basis=I%20own%20this',
                         content=b'not a wav', headers={'Content-Type':'audio/wav'})
    assert denied.status_code == 400


def test_character_voice_studio_endpoints():
    _test_character_voice_studio_endpoints()
