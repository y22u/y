import tempfile
import unittest
from pathlib import Path
from ai_growth import GrowthStore
from integrations import _allowed_url

class GrowthTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = GrowthStore(Path(self.tmp.name) / 'growth.sqlite3')
    def tearDown(self): self.tmp.cleanup()
    def test_memory_add_context_remove(self):
        self.store.add_memory('herta', '喜欢简洁的学习计划')
        self.assertIn('简洁的学习计划', self.store.context('herta'))
        row = self.store.memories('herta')[0]
        self.store.remove_memory(row['id'])
        self.assertEqual(self.store.context('herta'), '')
    def test_feedback_and_proposal_review(self):
        self.store.add_feedback('herta', 1, '回答有帮助')
        self.assertEqual(self.store.feedback('herta')[0]['rating'], 1)
        pid = self.store.add_proposal('herta', '建议回答更简洁')
        self.assertEqual(self.store.proposals('herta', True)[0]['id'], pid)
        self.store.set_proposal_status(pid, 'approved')
        self.assertEqual(self.store.proposals('herta', True), [])
    def test_integration_url_policy(self):
        self.assertTrue(_allowed_url('https://example.com/tts'))
        self.assertTrue(_allowed_url('http://127.0.0.1:8000/tts'))
        self.assertFalse(_allowed_url('http://example.com/tts'))
        self.assertFalse(_allowed_url('file:///etc/passwd'))

if __name__ == '__main__': unittest.main()
