import os
import unittest
from unittest.mock import Mock, patch

from external_agent import ExternalAgentClient, ExternalAgentError


class ExternalAgentTests(unittest.TestCase):
    def test_disabled_connector_rejects_request(self):
        with self.assertRaises(ExternalAgentError):
            ExternalAgentClient({"enabled": False}).chat([{"role": "user", "content": "hi"}])

    def test_rejects_insecure_non_loopback_url(self):
        cfg = {"enabled": True, "endpoint": "http://example.com/v1", "model": "agent", "api_key_env": "STAR_PET_TEST_KEY"}
        with patch.dict(os.environ, {"STAR_PET_TEST_KEY": "secret"}):
            with self.assertRaises(ExternalAgentError):
                ExternalAgentClient(cfg).chat([{"role": "user", "content": "hi"}])

    @patch("external_agent._SESSION.post")
    def test_openai_compatible_response(self, post):
        cfg = {"enabled": True, "endpoint": "http://127.0.0.1:8000/v1", "model": "local-agent", "api_key_env": "STAR_PET_TEST_KEY", "timeout": 15}
        response = Mock()
        response.json.return_value = {"choices": [{"message": {"content": "任务分析完成"}}]}
        post.return_value = response
        with patch.dict(os.environ, {}, clear=True):
            answer = ExternalAgentClient(cfg).chat([{"role": "user", "content": "请分析"}])
        self.assertEqual(answer, "任务分析完成")
        self.assertEqual(post.call_args.args[0], "http://127.0.0.1:8000/v1/chat/completions")
        self.assertEqual(post.call_args.kwargs["timeout"], (10, 15))

    @patch("external_agent._SESSION.post")
    def test_read_timeout_can_be_configured_separately(self, post):
        cfg = {"enabled": True, "endpoint": "http://127.0.0.1:8000/v1", "model": "local-agent",
               "api_key_env": "STAR_PET_TEST_KEY", "connect_timeout": 7, "read_timeout": 240}
        response = Mock()
        response.json.return_value = {"choices": [{"message": {"content": "ok"}}]}
        post.return_value = response
        with patch.dict(os.environ, {}, clear=True):
            ExternalAgentClient(cfg).chat([{"role": "user", "content": "hi"}])
        self.assertEqual(post.call_args.kwargs["timeout"], (7, 240))

    @patch("external_agent._SESSION.post")
    def test_thinking_guidance_and_native_effort_are_configurable(self, post):
        cfg = {"enabled": True, "endpoint": "http://127.0.0.1:8000/v1", "model": "local-agent",
               "api_key_env": "STAR_PET_TEST_KEY", "thinking_enabled": True, "reasoning_effort": "high"}
        response = Mock()
        response.json.return_value = {"choices": [{"message": {"content": "checked"}}]}
        post.return_value = response
        with patch.dict(os.environ, {}, clear=True):
            ExternalAgentClient(cfg).chat([{"role": "user", "content": "请分析"}])
        payload = post.call_args.kwargs["json"]
        self.assertEqual(payload["reasoning_effort"], "high")
        self.assertIn("关键假设", payload["messages"][0]["content"])

    @patch("external_agent._SESSION.post")
    def test_auto_effort_does_not_send_optional_provider_parameter(self, post):
        cfg = {"enabled": True, "endpoint": "http://127.0.0.1:8000/v1", "model": "local-agent",
               "api_key_env": "STAR_PET_TEST_KEY", "reasoning_effort": "auto"}
        response = Mock()
        response.json.return_value = {"choices": [{"message": {"content": "ok"}}]}
        post.return_value = response
        with patch.dict(os.environ, {}, clear=True):
            ExternalAgentClient(cfg).chat([{"role": "user", "content": "hi"}])
        self.assertNotIn("reasoning_effort", post.call_args.kwargs["json"])

    @patch("external_agent._SESSION.post")
    def test_fast_mode_bounds_history_and_uses_short_guidance(self, post):
        cfg = {"enabled": True, "endpoint": "http://127.0.0.1:8000/v1", "model": "local-agent",
               "api_key_env": "STAR_PET_TEST_KEY", "latency_mode": "fast", "max_history_messages": 2}
        response = Mock()
        response.json.return_value = {"choices": [{"message": {"content": "快速答复"}}]}
        post.return_value = response
        messages = [{"role": "system", "content": "角色设定"}] + [
            {"role": "user", "content": f"问题{i}"} for i in range(6)
        ]
        with patch.dict(os.environ, {}, clear=True):
            ExternalAgentClient(cfg).chat(messages)
        sent = post.call_args.kwargs["json"]["messages"]
        self.assertEqual(len([m for m in sent if m["role"] == "user"]), 2)
        self.assertIn("优先直接回答", sent[0]["content"])
        self.assertEqual(sent[-1]["content"], "问题5")

    @patch("external_agent._SESSION.post")
    def test_optional_max_tokens_is_sent_only_when_positive(self, post):
        cfg = {"enabled": True, "endpoint": "http://127.0.0.1:8000/v1", "model": "local-agent",
               "api_key_env": "STAR_PET_TEST_KEY", "max_tokens": 512}
        response = Mock()
        response.json.return_value = {"choices": [{"message": {"content": "ok"}}]}
        post.return_value = response
        with patch.dict(os.environ, {}, clear=True):
            ExternalAgentClient(cfg).chat([{"role": "user", "content": "hi"}])
        self.assertEqual(post.call_args.kwargs["json"]["max_tokens"], 512)

    def test_invalid_environment_name(self):
        cfg = {"enabled": True, "endpoint": "http://127.0.0.1:8000/v1", "model": "local-agent", "api_key_env": "not a var"}
        with self.assertRaises(ExternalAgentError):
            ExternalAgentClient(cfg).chat([{"role": "user", "content": "hi"}])


if __name__ == "__main__":
    unittest.main()
