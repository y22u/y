# StarPetFusion：星穹桌宠整合项目

将三个开源项目的主要使用流程整合为一个可运行的 Windows 桌面宠物程序：

- **大肥鱼桌宠**：透明置顶小窗、拖动、自由散步 / 跟随鼠标 / 原地待着、喂食、气泡、系统托盘、鼠标穿透。
- **hsr-skills**：自动读取本地角色 Skill 目录，在统一聊天面板里选择角色；每个角色的对话历史独立保存在本机 SQLite 数据库。
- **TheHerta-CodexPet**：内置安装脚本，可把官方格式的「大黑塔」v2 宠物包安装到 Codex 的 `pets/the-herta` 目录；Codex 宠物显示仍由 Codex 客户端负责。
- **AI 对话 / 天气 / 系统监控**：支持 DeepSeek、Ollama 本地模型、OpenAI 和其他 OpenAI 兼容接口；可查询城市天气；监控 CPU、内存，以及在可用时监控 NVIDIA GPU 温度。
- **角色个性设置**：每个角色可保存独立补充提示词；内置大黑塔、卡芙卡、三月七、阮·梅、流萤、黄泉、镜流、银狼、黑天鹅、符玄、托帕等女性角色风格卡，并可与下载的 `hsr-skills` 角色资料合并显示。内置卡是简明同人风格摘要，不冒充官方完整设定。
- **动态互动**：桌宠呼吸浮动、眨眼、情绪光晕、鼠标悬停回应；右键「互动动作」可招呼、开心、思考、休息或鼓励。
- **互动偏好**：可单独关闭动态效果；「偶尔碎碎念」默认关闭，开启后桌宠会低频随机发言。
- **聊天效率**：聊天窗口提供快捷话题菜单和按角色导出 TXT 记录。
- **日常工作台（2.7/2.8）**：提供本地待办清单、便签保存、在用户主动选择的目录中按文件名搜索；双击打开文件前会弹出确认，默认不执行脚本或程序。2.8 增加待办/便签 JSON 备份、校验与合并导入，写入前保留上一版数据副本。
- **视觉与连接诊断**：统一深紫色主题；AI 设置窗口可测试连接，并针对常见 HTTP 错误显示检查建议。
- **TTS 服务（4.8.1）**：桌面菜单的「TTS 语音服务设置」已加入 Edge TTS、Qwen3-TTS、IndexTTS、Gemini、Google Cloud 与通用接口选项；Edge TTS 可在设置窗口直接测试，且桌面端 AI 回复语音可使用已启用的 Edge TTS 配置。Edge TTS 是联网服务，不是离线模型。

> 这是一个新的整合实现，不是把三个仓库的文件直接拼接覆盖。为了尊重上游项目的署名、许可证和角色素材范围，代码包本身不内嵌上游源码、图像或大量角色资料；运行准备脚本后会从原仓库下载这些依赖到本地 `vendor/` 目录。


## 4.10.26 本地智能体自动任务

新增“自动任务”工作台：持久化任务队列、服务/硬件巡检、Ollama 本地模型盘点、角色语音样本生成与基础质检、质量门禁与发布打包、审批式文本代码变更。状态和事件保存在本地 SQLite；代码变更需要人工审批并先备份。

- 首次安装服务依赖后，双击 `start_service.bat` 手动启动本地服务。
- 浏览器访问 `http://127.0.0.1:8765/`，进入“自动任务”，点击“启动执行器”。可选开启每 30 分钟巡检。
- 详细步骤、安全边界、任务参数和 API 见 `AUTONOMOUS_TASKS_4.10.26.md`。
- 执行器不提供任意 Shell，且不会自动删除模型、安装软件、上传音频或重启外部服务。

## 1. 环境要求

- Windows 10/11 推荐；桌面宠物依赖 Qt 桌面环境。
- Python 3.10 或更高版本（推荐 Python 3.11/3.12）。
- 云端 AI 对话通常需要对应服务商的 API Key 与可用额度。使用本地 Ollama 时不需要云端 API Key，但需要安装模型并在本机运行 Ollama。
- 首次准备上游素材时需要可以访问 GitHub 的网络。

## 2. 安装和运行

Windows 首次运行建议：先双击 `setup.bat` 安装依赖，再双击 `start.bat` 启动。语音输出使用系统通用音色；如果没有声音，可运行 `python check_environment.py` 检查环境。外部 TTS 需要你自行选择服务商、填写可用 endpoint/model/voice，并将密钥放入环境变量；项目不会内置任何服务商密钥。学生模型训练是独立的可选流程，必须准备有训练许可的数据、兼容的预训练 checkpoint 与配置文件，不会因安装项目而自动得到已训练模型。


在 PowerShell 或终端进入项目文件夹：

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe prepare.py
.\.venv\Scripts\python.exe main.py
```

也可以先运行 `setup.bat`，它会创建虚拟环境、安装依赖并准备三个上游仓库。

`prepare.py` 会将上游文件与图像素材下载到（需要能够访问 GitHub）：

```text
vendor/
├── TheHerta-CodexPet/   # Codex v2 大黑塔宠物包
├── hsr-skills/          # 角色 SKILL.md 与相关角色资料
└── dafeiyu-pet/         # 透明桌宠素材等
```

如果某个目录已经存在，准备脚本默认跳过它。要重新下载并覆盖 `vendor/` 中相应目录，请执行 `python prepare.py --force`（这会删除后重新下载三个已存在的源目录）。

## 3. 操作方式

- **单击桌宠**：打开角色聊天窗口（有短暂的单击判定延迟，避免和双击冲突）。
- **双击桌宠**：弹出喂食选择。
- **鼠标悬停**：桌宠会短暂回应；动态效果开启时显示轻微呼吸浮动、眨眼和情绪光晕。
- **互动动作**：右键 →「互动动作」，可触发招呼、开心、思考、休息、鼓励等表情状态；也可关闭动态效果或开启低频碎碎念。
- **聊天快捷话题**：在聊天输入框旁选择常用话题，快速填入输入框；「导出记录」可将当前角色最近 100 条记录保存为 UTF-8 文本。
- **拖动桌宠**：移动窗口。
- **右键桌宠 / 系统托盘图标**：打开功能菜单。
- **移动模式**：自由散步、跟随鼠标、原地待着。
- **切换桌宠外观**：右键桌宠 →「切换桌宠外观」，可恢复默认大肥鱼、选择已发现的角色立绘，或通过「为当前角色设置专属立绘」导入当前角色图片。角色立绘保存在用户数据目录，切换角色时自动应用；状态动画在「互动动作」中统一切换，避免同一功能出现两套重复菜单。
- **天气**：通过 `wttr.in` 查询配置城市；默认城市为 Tokyo，可从菜单修改。
- **系统提醒**：每 10 秒检查一次；CPU 高于 90%、内存高于 95%、可读取的 NVIDIA 显卡温度高于 80°C 时会播报，同类提醒有冷却时间。
- **Codex 安装**：选择「安装大黑塔到 Codex」，或直接运行 `python install_herta_pet.py`。自定义路径可用 `python install_herta_pet.py --codex-home E:\\CodexHome`。如果目标目录已有不同版本，默认停止；确认覆盖才加 `--force`。

如果系统托盘不可用，可尝试在桌宠窗口上使用 `Ctrl+M` 打开菜单。

## 4. 配置 AI 模型

右键菜单 → **AI 设置**，选择服务类型后填写 Base URL、模型 ID 和 API Key。点击「测试连接」可先验证配置，再保存。

内置预设：

| 类型 | Base URL | 默认模型 | 密钥 |
|---|---|---|---|
| DeepSeek | `https://api.deepseek.com` | `deepseek-flash` | 需要有效 API Key 与额度；模型 ID 以[官方模型列表](https://api-docs.deepseek.com/api/list-models/)为准 |
| Ollama 本地 | `http://localhost:11434/v1` | `qwen2.5:3b` | 本地连接可留空 |
| OpenAI | `https://api.openai.com/v1` | `gpt-4o-mini` | 需要 OpenAI API Key |
| 自定义 | 按服务商文档填写 | 按服务商文档填写 | 视服务而定 |

Ollama 本地模型准备示例（需先安装 Ollama）：

```powershell
ollama pull qwen2.5:3b
ollama list
```

确认模型出现在 `ollama list` 后，在 AI 设置里选择「Ollama 本地模型」。模型名称应与本机列表完全一致。Ollama 兼容接口参考：[官方 API 文档](https://github.com/ollama/ollama/blob/main/docs/api/introduction.mdx)。

也支持通过环境变量提供 Key（推荐）：

```powershell
$env:STAR_PET_API_KEY="你的 API Key"
# 或者 DeepSeek 专用变量：
$env:DEEPSEEK_API_KEY="你的 API Key"
.\.venv\Scripts\python.exe main.py
```

`STAR_PET_API_KEY` 优先级最高，其次为 `DEEPSEEK_API_KEY`，最后才读取本地配置中的 Key。**不要把 API Key 提交到 Git 或发给他人。**配置目录在 Windows 的 `%APPDATA%\StarPetFusion\`，包含设置和本地对话数据库；删除对话可在聊天面板中按角色清空。

聊天面板的「角色设定」按钮可为当前角色追加独立提示词。选择大黑塔后，可以补充语气和回答偏好；角色提示词只是引导文本，不等于模型训练，也不能保证每次回答完全符合角色。

角色对话会把系统提示词和近期对话发送给你配置的模型服务。角色资料文件保存在本地；发送聊天时，所选角色的相关资料摘录和近期对话会一起发送给你配置的模型服务。使用前请确认你信任该服务。对话历史仅保存在本机 SQLite 中。

## 5. 打包 EXE（可选）

```powershell
.\.venv\Scripts\python.exe -m pip install pyinstaller
.\.venv\Scripts\pyinstaller.exe --noconfirm --clean --windowed --onedir --name StarPetFusion --add-data "vendor;vendor" main.py
```

也可以运行 `build.bat`。打包输出位于 `dist/StarPetFusion/`，以 `onedir` 方式保留 `vendor/` 数据。对外分发前，请先核对第三方许可证、角色素材权利和 API 使用方式。

## 6. 项目结构

```text
StarPetFusion/
├── main.py                 # Qt 桌宠主窗口、托盘、菜单、聊天面板
├── pet_widget.py           # 透明窗口、程序化动态效果、情绪回应与鼠标交互
├── skills.py               # 合并内置角色卡与外部角色资料、构造系统提示词\n├── bundled_roles/          # 可离线使用的角色风格卡（Markdown + manifest）
├── services.py             # 多后端 API 客户端、SQLite 对话历史、天气、系统监控
├── ai_settings_dialog.py   # AI 服务商预设、连接测试与设置窗口
├── permissions_dialog.py   # 基本权限管理
├── access_control.py       # 应用功能权限校验
├── productivity.py         # 本地待办、便签、只读文件查找、备份导入导出
├── productivity_data.py    # 工作台数据校验、原子写入、备份与合并恢复
├── config_store.py         # 用户配置管理
├── prepare.py              # 下载并安全解压三个上游仓库
├── install_herta_pet.py    # 将大黑塔 v2 宠物包安装到 Codex
├── requirements.txt
├── setup.bat
├── start.bat
├── build.bat                # 可选的 PyInstaller onedir 打包脚本
├── LICENSE
├── THIRD_PARTY.md
├── OPEN_SOURCE_REVIEW.md   # 同类开源项目调研与设计取舍
└── tests/
```

## 7. 同类项目调研与素材说明

参考方向与许可证注意事项见 [OPEN_SOURCE_REVIEW.md](OPEN_SOURCE_REVIEW.md)。运行 `python prepare.py` 会将原始项目和图像素材下载到 `vendor/`，外观菜单会扫描其中适合单张展示的图片。发行包不直接捆绑所有上游图像，避免在未完成许可证/角色素材授权核查前再分发。下载不等于取得再分发授权。

## 8. 内置角色卡与开源项目整合原则\n\n内置角色卡不依赖网络即可使用；若 `vendor/hsr-skills/` 中存在同 slug 的上游角色资料，优先保留内置卡，避免来源更新导致本地角色覆盖或启动后角色列表异常。新增角色可复制 `bundled_roles/` 下任一目录，编辑 `manifest.json` 的 `name` 与 `SKILL.md`。角色资料中的文本作为参考内容处理，不授予角色任何现实工具权限。\n\n本项目采用“功能借鉴、独立实现、按需下载”的整合方式：吸收 DyberPet 的模组化思路、桌面伴侣项目的后台任务/本地存储思路、模型桌宠项目的多后端配置思路；不将未审核的第三方源码、模型权重或图片直接复制进发行包。新增上游时必须审查许可证、署名、依赖安全与角色素材权利。\n\n## 9. 工作台数据备份（2.8）

打开右键菜单中的“日常工作台”→“数据备份”，可导出或导入待办/便签。导入会先验证 JSON 格式并默认合并，不会清空现有待办；便签会追加到已有内容之后。备份文件不包含聊天历史、API Key 或应用设置。每次写入工作台数据前，会尝试在同一配置目录保存 `.previous.json` 副本。建议定期把导出文件复制到安全位置，并避免把私人便签发送给他人。

## 10. 测试

```powershell
python -m unittest discover -s tests -v
python -m compileall -q .
```

## 声明

本项目为非官方粉丝工具，与 OpenAI、HoYoverse / miHoYo 无隶属或认可关系。角色名、游戏设定及同人视觉资产归相应权利人所有。请遵守上游项目许可证、平台规则和当地法律。

### 角色与动画增强（2.2）

- 在“角色会客厅”顶部搜索框输入角色名称或 slug，可即时筛选角色。
- 使用“☆ 收藏”管理常用角色；收藏数据保存在用户配置目录，不修改角色源文件。
- 右键桌宠 →“互动动作”→“动画风格”，可选择“柔和呼吸”“活泼弹跳”“轻微动态”。
- 右键桌宠 →“切换桌宠外观”或“从电脑选择图片”，选择 GIF 可播放动图；静态图片仍按原方式显示。
- 动画风格设置保存在本地配置中。若 GIF 文件较大，建议使用尺寸适中的优化动图以降低 CPU/GPU 开销。


## 10. 官方资料、角色扩展与语音输出（2.4）

- `official_data/sources.json` 保存官方公开资料入口和用途；`official_data/ASSET_POLICY.md` 说明素材边界。项目不会自动下载/打包游戏模型、官方立绘、PV、动画、音乐或语音音轨。
- 新增阿格莱雅、海瑟音、风堇等角色卡，并扩充已有角色的性格、背景摘要和互动约束。摘要基于官方公开简介整理，不能替代游戏内完整资料；需要精确核对时请打开 sources.json 中的官方链接。
- `voice_profiles.json` 为各角色提供语速、音量和表达风格参数。启用系统语音前，先安装可选依赖：`python -m pip install pyttsx3`，然后在用户配置文件 `%APPDATA%\StarPetFusion\config.json` 中设置 `"voice_enabled": true`。默认关闭，避免意外播音。
- 语音由操作系统安装的通用 TTS 声音合成，角色配置只调节朗读节奏与风格；**不会克隆或声称复现官方配音演员音色**。若要使用官方音频，必须先确认适用地区规则及声音表演权利，并仅加载你有权使用的本地文件。
- 如果需要更自然的多语言声音，可通过独立 TTS 插件适配有明确授权的语音服务；不要把 API 密钥写入源码或提交到仓库。

### 新增角色
复制 `bundled_roles/<slug>/` 目录并编辑 `manifest.json` 与 `SKILL.md`。在 `voice_profiles.json` 添加同 slug 的语音风格，在 `user_animations/<slug>/` 放入有权使用的 `idle.gif`、`happy.gif`、`think.gif`、`sleep.gif` 即可按角色组织素材。


## 2.5 语音与角色动画资源

右键桌宠 →「语音与动画资源设置…」可开启系统 TTS、选择角色、调整语速/音量、测试语音并导入角色状态素材。资源按角色 slug 和状态（idle/happy/think/sleep）分别保存到 `%APPDATA%/StarPetFusion/role_animations/<role-slug>/`。导入素材会复制到应用数据目录，不修改原文件。

提示：系统 TTS 的语速与音量不能将通用声音变成官方配音演员的音色；请只使用自己有权使用的音频/动画素材。


## 11. 基本权限与隐私模式（2.6）

右键桌宠 →「基本权限管理」可以使用「标准模式」「隐私模式」「受限模式」预设，或单独控制联网请求、AI 设置、素材导入、角色提示词编辑、聊天记录导出/删除及外部安装。权限保存在用户配置目录的 `config.json` 中。

- **标准模式**：保留原有功能。
- **隐私模式**：默认关闭外部网络请求、聊天记录导出和外部应用安装。
- **受限模式**：仅保留聊天相关基础权限（仍需启用联网权限才能使用远程模型）。
- 关闭「访问外部 AI / 天气服务」会同时拦截远程模型聊天与天气查询；本地 Ollama 也属于应用发起的网络请求，因此该权限关闭时同样受限。
- 这些是应用内功能开关，并非操作系统账户隔离或防篡改安全边界；同一账户下有权限修改配置文件的人仍可调整它们。

运行测试：`python -m unittest discover -s tests -v`。

## 9. 日常工作台与权限说明（2.7）

右键菜单选择「日常工作台」即可使用待办清单、便签和文件查找。待办与便签写入 `%APPDATA%/StarPetFusion/productivity.json`（非 Windows 系统写入 `~/.config/StarPetFusion/`）。文件搜索必须由用户选择目录，仅匹配文件名，最多显示 500 个结果；打开文件会再次确认，常见可执行文件和脚本会被拦截。

右键菜单的「基本权限管理」可单独关闭工作台、文件搜索或打开文件权限。这里的开关是应用层功能控制，不是操作系统沙箱；请仍然谨慎选择目录，并不要将敏感文件发送给不信任的 AI 服务。


## 2.9：大模型成长与第三方接入

- 右键菜单新增「角色记忆与成长」：可手动添加/删除本地记忆、评价回答，并让大模型生成待审核的角色风格建议。建议不会自动改写原始角色资料或代码。
- 可选第三方 TTS 和动画状态 webhook 默认关闭。请参考 `THIRD_PARTY_INTEGRATIONS.md`，将 `integrations.example.json` 复制到应用配置目录并按服务商文档配置。
- API Key 建议放在环境变量中。第三方语音服务可能收到要朗读的文本；云端大模型会接收发送的对话上下文。
- 应用内权限不是操作系统安全沙箱。
## 人物设定蒸馏与角色扩写（3.1）

16 张内置人物卡扩充了核心身份、背景摘要、动机、优势与弱点、日常习惯、语言特征、情绪反应、关系方式、开场及原创对话示例。黑塔与大黑塔分别保留为独立角色，风堇使用统一显示名。

`persona_distiller.py` 会将稳定性格压缩成常驻摘要，并按当前消息挑选相关信息，避免每轮都重复发送全部长篇设定。此功能是提示词压缩，不是模型训练。外部旧版角色资料仍支持回退读取。详情见 `RELEASE_NOTES_3.1.md`。

## Agent 与语言风格（3.0）

角色聊天窗口顶部提供按角色保存的语言风格选择：角色原设、自然日常、简洁直接、专业严谨、温柔鼓励、活泼俏皮、逻辑分析、正式书面和文学表达。该设置只改变表达方式，不覆盖原始角色资料。右键菜单可关闭 Agent 任务辅助。

Agent 运行时使用固定只读工具白名单，不会执行模型输出的任意代码、命令或自动安装插件。新增模块说明见 `RELEASE_NOTES_3.0.md`。

## 语音交互（3.2）
聊天窗口新增「语音输入」按钮，可选安装 `sounddevice`、`numpy`、`faster-whisper` 后进行本机中文语音识别；识别结果会先进入输入框，由用户确认后发送。语音朗读可选安装 `pyttsx3`。详细安装与故障排查见 `VOICE_AND_UI_GUIDE.md`。角色语音预设只调整语速、音量和表达节奏，不克隆或冒充官方配音演员。


## 10. 语音训练工作流（3.4）

`distillation/README.md` 说明教师 TTS 生成数据集、学生模型微调与验证步骤。`python check_environment.py` 可检查基础运行依赖，`distillation/texts.example.txt` 是原创通用测试文本。项目不包含官方 PV/剧情语音抓取器，也不把生成数据集宣称为已训练模型；请使用明确允许模型训练的音频、文本与声音服务。外部 TTS 配置模板见 `integrations.example.json`，密钥只通过环境变量提供。

## StarPetFusion 4.1 服务化架构预览

本项目新增独立服务端与 Web 工作台，详见 `docs/ARCHITECTURE_V4.md`。安装服务端依赖并启动：

```powershell
python -m pip install -r requirements-service.txt
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8765
```

浏览器打开 `http://127.0.0.1:8765/`。默认只监听本机回环地址，请勿直接暴露到局域网或公网。原 PySide6 桌宠入口与既有角色/记忆模块保留，采用渐进迁移。

**账号授权说明：** 服务商只有在提供官方 OAuth/账号授权能力时才能实现纯账号登录。Google Cloud TTS 与 Gemini API 的凭据体系不同；API 权限、结算和配额要求不会因前端重构而消失。


## 7. 4.5 多 Agent 与免费 TTS

- 免费/免 API Key 选项：Edge TTS（在线、需网络）以及本地开源模型 Qwen3-TTS、IndexTTS（需各自独立环境和模型权重）。
- 在浏览器网关中可通过“语音与 TTS”选择 Edge、Qwen3 或 IndexTTS；Qwen3/IndexTTS 必须先运行各自 sidecar，端口默认 8766/8767。
- Agent 对话支持 Ollama 本地模型、一个默认 OpenAI 兼容 Agent，以及多个 `agent_profiles` 配置档。示例见 `AGENT_MULTI_PROFILE.md`。
- `/api/v1/connectors` 与 `/api/v1/diagnostics` 会区分“配置存在”和“服务可用”，但诊断不会验证云端密钥是否有额度，也不会自动触发收费调用。
- Gemini TTS 的免费层和限制以 Google 当前政策为准；Google Cloud TTS 可能收费。开源模型不收模型 API 费用，但本地算力、存储和下载流量仍由使用者承担。

## 4.5.0 TTS 与 Agent 就绪检测

在项目目录执行 `python diagnose_integrations.py` 可检查 Edge TTS 依赖、Qwen3/IndexTTS 本地 sidecar、Ollama 和外部 Agent 配置。Web 工作台“服务连接”页也会显示实际就绪状态。就绪检查不会发起付费语音合成或真实模型推理。

免费/本地选项：Edge TTS（在线、需网络）、Qwen3-TTS 和 IndexTTS（本地开源、需单独安装环境和模型权重）、Ollama（本地模型、需下载模型）。外部 Agent 需要其服务实例提供兼容 API；不能保证所有桌面 Agent 产品都具备直接调用接口。


## 角色设定与形象数字库

本版本提供本地 SQLite 角色库，详见 `CHARACTER_LIBRARY_GUIDE.md`。执行 `python tools/build_character_library.py` 可导入/更新 24 个内置角色设定；将有权使用的图片通过 `character_library.register_asset(...)` 导入后，桌宠外观菜单会扫描角色素材目录。默认大肥鱼使用内置矢量绘制，无需外部精灵。未经核实授权的社交平台同人图片不会自动抓取或打包。

## 11. 大肥鱼替换与崩铁角色形象扩展（4.10.6）

- 开源项目检索结果、用途与授权边界见 [OPEN_SOURCE_VISUAL_ASSET_RESEARCH.md](OPEN_SOURCE_VISUAL_ASSET_RESEARCH.md)。
- 下载并启用大肥鱼社区预览 GIF：`python download_dafeiyu_assets.py`。此操作需要联网；下载成功后会将 `appearance_path` 指向本地素材并设置默认角色为 `dafeiyu`，然后重启应用。该素材不会被直接打包进发行 ZIP。
- 下载崩铁角色图片候选：`python download_hsr_assets.py --character the-herta --character aglaea --character hysilens --limit-per-character 2`。下载后通过右键 →「切换桌宠外观」选择，或设置为当前角色专属立绘。
- `Hyacine=风堇`，`Hysilens=海瑟音`，下载器别名已分开，避免把两名角色混淆。
- 角色图片和模型的权利不等同于仓库代码许可证。索引默认标记 `license_review_required=true`、`redistribution_allowed=false`；未经核查不要把下载素材再打包发布。

## 角色 Skill 文件丢失时恢复（4.10.9）

角色 `SKILL.md` 恢复说明见 `SKILL_FILE_RECOVERY.md`。在项目根目录运行 `python restore_character_skills.py` 可从随包恢复快照补回缺失的内置角色卡；运行 `python restore_character_skills.py --restore-vendor` 可在不覆盖现有文件的前提下，将缺失的内置角色卡补到 `vendor/hsr-skills/`。脚本会生成 `skill_recovery_report.json`。


### 混合语音路由（4.10.10）

桌面端语音输出现支持“授权录音精确匹配 → 本地 Qwen3-TTS → 本地 IndexTTS →（明确启用后）在线 Edge TTS → 系统 TTS”的回退路径。路由配置位于用户配置目录 `voice_router.json`（Windows：`%APPDATA%\StarPetFusion\voice_router.json`；macOS/Linux：`~/.config/StarPetFusion/voice_router.json`），可从项目根目录的 `voice_router.example.json` 复制后修改。默认 `allow_online=false`，不会因为启用路由就自动把聊天文本发送给在线 TTS。首次运行可直接使用默认值；需要在线合成时，确认数据传输意愿后将 `allow_online` 改为 `true`。

官方录音目录为 `licensed_audio/`，默认不附带任何游戏录音。仅可登记已获得适当授权的素材；程序要求角色 ID、完整台词匹配、有效文件及 SHA-256 一致，授权到期的条目会被忽略。详细格式见 `licensed_audio/README.md`。本地 Qwen3/IndexTTS 需先启动对应 sidecar（`start_qwen3_sidecar.bat` / `start_indextts_sidecar.bat`）；未启动时会快速检查健康状态并尝试下一个引擎。

## 4.10.11 混合语音与大肥鱼形象保护

- 语音路由说明：`voice_router.example.json`、`licensed_audio/README.md`。
- 大肥鱼形象保护基线：`VISUAL_PRESERVATION_4.10.11.md`。
- 运行回归测试：`python -m unittest discover -s tests -q`。
- 除非用户明确要求外观调整，不修改 `pet_widget.py`、前端样式和大肥鱼资源清单。


## 4.10.12 角色形象库
新增角色形象库页面，整合上传图片与概念海报，支持搜索、筛选、预览切换和浏览器本地记忆。详细说明见 `CHARACTER_LOOKBOOK_4.10.12.md`。本次不修改 4.10.7 大肥鱼桌宠外观核心。


## 4.10.13 Q版形象库填充
详见 `CHARACTER_LOOKBOOK_4.10.13.md`。角色库现在含 28 条静态预览素材，其中 20 条由用户提供的概念图裁切而来。

## 4.10.14 工作台前端与角色库体验优化

详见 `RELEASE_NOTES_4.10.14.md`。本版优化总览页角色展示、角色库卡片层级、搜索结果计数、名称排序、收藏及收藏筛选、空状态、移动端布局与键盘可访问性。再次明确：角色库选择当前是网页静态预览，尚不会自动切换原生桌宠或激活 3D 模型。


## 4.10.15 外部 Agent 低延迟优化

详见 `EXTERNAL_AGENT_LOW_LATENCY_4.10.15.md`。外部 Agent 连接改为复用 HTTP 连接池，并在设置窗口增加快速响应/均衡/深度分析策略、历史上下文上限和可选最大生成 Token。快速模式精简提示词和旧历史，降低客户端处理与请求负载；端到端速度仍取决于网络、服务排队和模型推理。

## 4.10.21 ASR 与并发运行时

- 可选安装本地 ASR：运行 `install_asr.bat`，或执行 `python -m pip install -r requirements-asr.txt`。
- 服务启动后打开统一模型中心，可上传音频文件并通过 faster-whisper 本地识别；接口说明见 `RELEASE_NOTES_4.10.21.md`。
- 并发上限可通过 `STAR_PET_CHAT_CONCURRENCY`、`STAR_PET_TTS_CONCURRENCY`、`STAR_PET_ASR_CONCURRENCY` 环境变量调整。提高上限不保证实际并行速度提高，需考虑内存、显存和运行时限制。

## 4.10.22 Ollama 多模型运行态与调度可观测性
- 统一模型中心新增“当前驻留内存的模型”面板，显示 Ollama 版本、模型驻留大小、VRAM 用量、上下文长度与卸载时间。
- 删除模型前会检查 `/api/ps`，如果模型仍驻留内存，提示先停止推理或等待自动卸载。
- 并发面板显示活动、等待及拒绝累计值。线程/请求上限并不保证多模型同时驻留；最终由 Ollama 与系统内存/显存共同决定。


## 4.10.23 硬件资源感知建议

- 运行时诊断会尽力读取可用 RAM；Windows 使用系统 API，Linux 优先使用 psutil（若安装）或 `/proc/meminfo`。
- 如果可用则通过 `nvidia-smi` 读取 NVIDIA GPU 显存。未检测到 NVIDIA 工具时会明确标注，不推断其他显卡的显存。
- 按可用 RAM 给出保守的对话并发建议；显存紧张时进一步建议串行。此建议不会自动覆盖环境变量并发配置，避免在未充分了解模型、上下文和工作负载时擅自改变行为。
- 这是主机资源提示而非精确模型需求预测；请优先结合 Ollama `/api/ps` 的实际驻留占用，并为 KV Cache、上下文长度及其他应用留出余量。


## 4.10.24 角色专属音色预设
- 为内置角色完善独立的语速、音量、表达指令，以及 Edge TTS / Qwen3-TTS 的 provider-specific voice 映射。
- Qwen3-TTS 使用角色化自然语言指令，避免把 `elegant` 等内部风格标签误当作完整合成指令。
- 音频缓存键纳入完整角色表达指令与引擎音色，避免不同角色的同一句文本错误共用缓存。
- 角色音色是通用合成音色的差异化演绎，不声称复刻游戏配音演员；在线 Edge 仍需在设置中显式允许，默认不发送文本到在线服务。
- 端到端生成仍取决于本机已安装的 TTS 依赖、模型、网络和硬件；本包不包含大型语音模型权重。

## 4.10.25 角色参考音频工作台
统一模型中心内新增“角色参考音频与试听验收”：可以为角色登记有授权的 PCM WAV（1–30 秒、20 MB 内），保存授权依据与 SHA-256，执行基本音频检查；IndexTTS/Qwen3-TTS 服务就绪后，每批最多为 5 个角色生成相同文本的试听样本并对比基础声学指标。自动指标不等于主观听感或角色相似度评价。项目不包含第三方角色/演员参考录音；请只使用你有权使用的音频。
