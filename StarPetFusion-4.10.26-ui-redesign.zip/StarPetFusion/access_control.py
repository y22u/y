"""Lightweight feature-level permissions for StarPetFusion.

These controls gate application features; they are not operating-system security
boundaries and do not protect files from someone with access to the user account.
"""
from __future__ import annotations
from typing import Any

PERMISSIONS = {
    "growth": "角色记忆与成长建议（本地保存）",
    "chat": "角色聊天与联网模型请求",
    "network": "访问外部 AI / 天气服务",
    "edit_settings": "修改 AI 与应用设置",
    "manage_assets": "导入桌宠图片、语音和动画素材",
    "edit_roles": "编辑角色提示词与角色资料",
    "history_export": "导出聊天记录",
    "history_delete": "清空本地聊天记录",
    "install_external": "向外部应用目录安装宠物资源",
    "productivity": "本地待办与便签管理",
    "file_search": "搜索用户主动选择的文件夹",
    "open_files": "使用系统默认程序打开文件（需二次确认）",
}

DEFAULT_PERMISSIONS = {key: True for key in PERMISSIONS}
PRESETS = {
    "标准模式": dict(DEFAULT_PERMISSIONS),
    "隐私模式": {**DEFAULT_PERMISSIONS, "network": False, "history_export": False, "install_external": False},
    "受限模式": {key: key in {"chat", "network", "productivity"} for key in PERMISSIONS},
}

def get_permissions(config: Any) -> dict[str, bool]:
    raw = config.get("permissions", {})
    result = dict(DEFAULT_PERMISSIONS)
    if isinstance(raw, dict):
        for key in PERMISSIONS:
            if key in raw:
                result[key] = bool(raw[key])
    return result

def is_allowed(config: Any, permission: str) -> bool:
    if permission not in PERMISSIONS:
        return False
    # Network permission also controls chat requests to remote providers.
    allowed = get_permissions(config)
    if permission == "chat":
        return allowed["chat"] and allowed["network"]
    return allowed.get(permission, False)
