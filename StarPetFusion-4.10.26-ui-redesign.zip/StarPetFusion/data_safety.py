from __future__ import annotations
"""Local safety snapshots for files modified through confirmed Agent writes."""
import json
import os
import shutil
import time
import uuid
from pathlib import Path
from config_store import app_data_dir

MAX_BACKUPS = 100
MAX_BACKUP_BYTES = 20 * 1024 * 1024


def backup_root() -> Path:
    return app_data_dir() / "backups" / "agent-writes"


def create_backup(target: Path) -> dict:
    target = target.resolve()
    if not target.is_file():
        return {"created": False, "reason": "target_not_existing_file"}
    size = target.stat().st_size
    if size > MAX_BACKUP_BYTES:
        raise ValueError("原文件超过 20 MB 安全备份上限，已阻止覆盖。请先手动备份并缩小文件。")
    root = backup_root()
    root.mkdir(parents=True, exist_ok=True)
    backup_id = f"{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}"
    folder = root / backup_id
    folder.mkdir()
    try:
        shutil.copy2(target, folder / "original.bin")
        metadata = {"id": backup_id, "target": str(target), "created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "size": size}
        (folder / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        prune_backups()
        return {"created": True, **metadata}
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        raise


def list_backups() -> list[dict]:
    root = backup_root()
    if not root.exists():
        return []
    items = []
    for folder in root.iterdir():
        meta_path = folder / "metadata.json"
        data_path = folder / "original.bin"
        if not folder.is_dir() or not meta_path.is_file() or not data_path.is_file():
            continue
        try:
            item = json.loads(meta_path.read_text(encoding="utf-8"))
            if isinstance(item, dict) and item.get("id") == folder.name:
                items.append(item)
        except (OSError, ValueError):
            continue
    return sorted(items, key=lambda x: str(x.get("created_at", "")), reverse=True)


def restore_backup(backup_id: str) -> dict:
    if not backup_id or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in backup_id):
        raise ValueError("备份编号无效。")
    folder = (backup_root() / backup_id).resolve()
    try:
        folder.relative_to(backup_root().resolve())
    except ValueError as exc:
        raise ValueError("备份路径无效。") from exc
    metadata_path, data_path = folder / "metadata.json", folder / "original.bin"
    if not metadata_path.is_file() or not data_path.is_file():
        raise ValueError("备份文件不存在或不完整。")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    target = Path(metadata.get("target", "")).resolve()
    if not target.is_file():
        raise ValueError("原文件不存在；为避免意外在未知位置创建文件，未执行恢复。")
    temp = target.with_name(target.name + ".starpet-restore.tmp")
    try:
        shutil.copyfile(data_path, temp)
        os.replace(temp, target)
    finally:
        try: temp.unlink(missing_ok=True)
        except OSError: pass
    return {"restored": True, "target": str(target), "bytes": target.stat().st_size}


def prune_backups(keep: int = MAX_BACKUPS) -> int:
    root = backup_root()
    if not root.exists(): return 0
    folders = sorted((p for p in root.iterdir() if p.is_dir()), key=lambda p: p.name, reverse=True)
    removed = 0
    for folder in folders[max(1, keep):]:
        shutil.rmtree(folder, ignore_errors=True)
        removed += 1
    return removed


def cleanup_old_logs(days: int = 30) -> int:
    """Delete only StarPetFusion's own rotated log files older than days."""
    if not isinstance(days, int) or days < 1:
        raise ValueError("保留天数必须是正整数。")
    log_dir = app_data_dir() / "logs"
    if not log_dir.exists(): return 0
    cutoff = time.time() - days * 86400
    removed = 0
    for path in log_dir.glob("starpetfusion.log*"):
        try:
            if path.is_file() and path.stat().st_mtime < cutoff:
                path.unlink(); removed += 1
        except OSError:
            continue
    return removed
