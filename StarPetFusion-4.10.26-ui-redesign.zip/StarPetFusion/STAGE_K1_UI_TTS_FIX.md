# StarPetFusion 4.8.1 — 桌宠形象与 TTS 入口优化

## 本阶段目的
结合 4.2–4.8.0 已有功能，修复角色立绘与桌面外观的映射体验、合并重复动作入口，并让已接入的 Edge TTS 可在桌面端 TTS 服务设置中找到、测试和用于角色回复语音。

## 改动
1. 角色立绘发现支持“大黑塔 / the-herta / the_herta / herta”、“阿格莱雅 / aglaea”和“海瑟音 / hysilens / hyacine”等常见别名。
2. 外观选择列表不再把 `idle.png`、`happy.png`、`think.png`、`sleep.png` 等状态图重复列为通用外观。
3. 移除重复的“当前角色专属动作”子菜单；待机、开心、思考、睡觉整合进“互动动作”，仍保留招呼和鼓励。
4. 桌面菜单“ TTS 语音服务设置”增加 Edge TTS、Qwen3-TTS、IndexTTS 选项，并增加 Edge TTS 实际合成测试按钮。
5. `integrations.external_tts` 新增 Edge TTS 分支，可读取用户在 `integrations.json` 中启用的设置用于桌宠回复语音；失败时保留系统 TTS 回退。
6. 对 Qwen3-TTS、IndexTTS 已部署的本机 sidecar 增加桌面回复语音路由。
7. Edge TTS 合成增加超时保护；服务版本更新为 4.8.1。

## Edge TTS 使用方法
- 右键桌宠 → “TTS 语音服务设置…” → 服务类型选择“Edge TTS（免费在线，无 API Key）”。
- 保持默认中文音色 `zh-CN-XiaoxiaoNeural`，点击“测试 Edge TTS”。
- 成功后会生成 MP3 并使用系统默认播放器打开。此测试需要联网，不代表离线模型。
- 勾选“启用所选 TTS 服务”并保存后，桌宠回复语音会优先尝试该服务；如果网络/依赖失败，会回退到系统 TTS。
- Web 工作台的“语音与 TTS”页面也保留 Edge TTS 选项和生成播放能力。

## 角色形象使用方法
- 先在角色聊天窗口选择角色；右键桌宠 → “切换桌宠外观” → “为当前角色设置专属立绘…”。
- 立绘会复制到用户数据目录并绑定到当前角色；再次切换角色时自动切换其对应立绘。
- `character_assets/<role-slug>/portrait.png` 仍可作为项目本地资源路径。
- 待机/开心/思考/睡觉状态通过“互动动作”统一触发；若没有对应状态图片，则显示角色立绘并使用程序化情绪动作。
- 本包不捆绑受版权保护的游戏立绘，需要用户导入自己有权使用的图片。

## 验收结果
- `python -m compileall -q .`：通过。
- `python -m unittest discover -s tests -q`：109 项通过，1 项跳过。
- `python quality_gate.py`：4/4 检查通过（编译、单元测试、服务健康、角色提示词生成检查）。
- ZIP 完整性检查：通过。
- 未在构建环境执行真实在线 Edge TTS 请求；应在用户电脑联网后点击测试按钮完成最终验收。
