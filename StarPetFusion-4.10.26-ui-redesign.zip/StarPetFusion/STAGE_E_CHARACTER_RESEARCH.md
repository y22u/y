# Stage E：角色资料检索与设定扩充

## 三轮迭代

### 第一轮：资料来源与边界标准化
- 增加 `official_data/character_sources.json`，列出中国大陆官网、国际服官方角色页、HoYoWiki 角色聚合页及粉丝创作指南。
- 对已有内置角色统一补充资料复核日期、来源说明、资料结构清单和“官方公开事实 / 粉丝原创扩展”区分规则。
- 仅保存公开资料入口和原创概括，不下载或重新分发官方立绘、模型、语音、PV、动画。

### 第二轮：扩充角色资料卡
新增 8 张可被程序自动发现的内置角色卡：花火、飞霄、翡翠、忘归人、缇宝、遐蝶、赛飞儿、大丽花。每张角色卡均包含身份、公开背景摘要、性格、动机、优势与局限、习惯、语言风格、情绪反应、关系方式、场景、开场示例和原创对话示例。

### 第三轮：质量校验与集成
- 新增 `tests/test_stage_e_roles.py`，验证角色可发现性、来源标注、核心字段完整性和来源索引覆盖。
- 角色使用既有 `bundled_roles` 自动扫描机制，不更改聊天/Agent/语音/记忆等既有流程。
- 角色设定遵守事实边界：不确定的剧情细节不写成事实，原创对话不冒充官方台词。

## 数据来源
- https://sr.mihoyo.com/main?nav=world
- https://hsr.hoyoverse.com/en-us/character
- https://wiki.hoyolab.com/pc/hsr/aggregate/character?bbs_presentation_style=fullscreen
- https://hsr.hoyoverse.com/en-us/news/111203?type=news

上述页面用于核对名称、公开简介和创作边界。此版本的角色行为、日常陪伴习惯和对话例子为 StarPetFusion 粉丝向原创扩展，不代表官方完整设定。

## 运行验证
在项目根目录运行：

```bash
python -m compileall -q .
python -m unittest discover -s tests -q
python service_health.py
```

## 资源版权说明
项目只存放角色文字资料和来源链接；未将官方图片、角色模型、游戏动画、PV 或配音音频打包进项目。用户若添加素材，应确认其取得方式和使用范围合法。
