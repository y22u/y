# StarPetFusion 大黑塔形象丢失排查与全项目自检

## 结论

- 历史版本：检查了原始 `StarPetFusion.zip`、2.2、2.3、3.1、4.6、4.7、4.8.1、4.9.1、4.10 等可用发行包。检查到的发行包中均没有 PNG/JPG/WEBP/GIF/BMP/APNG/MP4 图片或视频资源。
- 根因判断：当前“只显示默认蓝色大肥鱼”首先由大黑塔图片/动画素材未随发行包提供导致；此外确有加载链路兼容性问题。
- 不能确认用户电脑上的旧安装目录、下载缓存或 Codex 资源目录也已丢失，因为无法直接读取用户本机文件。新增只读诊断脚本帮助用户在本机查找。

## 已确认的代码问题

1. `PetWidget._load_custom_sprite()` 只把 GIF 交给 `QMovie`，WEBP 统一走 `QPixmap` 静态加载路径。修复为尝试通过 `QMovie` 加载动画 WEBP（前提是当前 Qt 图像插件支持多帧）；静态 WEBP 仍回退到 `QPixmap`。
2. `character_asset_registry.py` 原先可能把名为 `spritesheet.webp` 的文件误判为普通立绘（若以后将上游目录加入扫描根目录）。现在明确排除 spritesheet 与应用图标，避免把整张图集当人物立绘。
3. `install_herta_pet.py` 的 Codex 资源安装路径是独立集成：需要 `pet.json` 和 `spritesheet.webp`。桌宠本身的普通图片加载器并不会自动解析该 Codex 图集布局，因此仅下载/安装图集并不等于桌宠动态形象已经恢复。
4. 找不到当前角色立绘时，`AppController.set_active_role()` 会回退到用户全局外观；若全局外观也不存在，则清除自定义图并显示内置大肥鱼。这是当前代码的明确回退逻辑。
5. `persona_distiller.py` 只负责按话题选择人物设定文本并限制提示词长度；不负责查找、加载或渲染图片/动画，因此它不是本次形象丢失的直接原因。

## 已添加/修改

- `diagnose_character_assets.py`：只读扫描项目素材、Codex 大黑塔目录、常见用户目录与可选额外路径。不会写配置、修改数据库或覆盖资源。
- `pet_widget.py`：增加动画 WEBP 的 QMovie 尝试路径；Qt 插件不支持时保留静态图片回退。
- `character_asset_registry.py`：排除 `spritesheet.webp`、常见 sprite-sheet 文件名和 `icon.png`，避免误识别为角色立绘。
- `tests/test_stage_j_knowledge_assets.py`：增加图集不得被识别为立绘的回归测试。

## 自检结果

- `python quality_gate.py`：4/4 检查通过。
- `python -m unittest discover -s tests -q`：111 项测试通过，1 项跳过。
- `service_health` 中 TTS 为 SKIP（TTS 集成关闭），因此未声称在线语音服务端到端通过。
- 编译检查通过；人物提示词生成校验通过（24 个文件）。

## 仍未完成 / 需要用户本机确认

- 本次无法从历史发行 ZIP 恢复原始大黑塔图集，因为包内未包含图像/视频文件。
- 尚未对真实 `pet.json` 与真实 `spritesheet.webp` 执行帧布局解析，因为当前可用旧版 ZIP 不含这两个文件。
- 动画 WEBP 播放取决于用户安装的 Qt 图像插件；若素材实际是 sprite atlas，仍需依据上游 `pet.json` 中的帧布局实现切帧器，不能直接把整张图集当作动画。
- 用户运行 `python diagnose_character_assets.py` 后，应先将输出结果交由维护者确认；不要覆盖 `character_library.db` 或重置配置。

## 安全原则

不清理、不覆盖、不初始化任何用户数据库或角色配置。建议先备份 `%APPDATA%/StarPetFusion` 和项目目录，再执行任何后续资源导入。
