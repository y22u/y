"""Local character voice reference and sample studio.

Reference audio is accepted only after an explicit authorization attestation. This
module does not infer consent or clone a named real person's voice from scraped media.
"""
from __future__ import annotations
import hashlib, json, math, wave, struct
from datetime import date
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
REFERENCE_DIR = DATA_DIR / "character_voice_references"
SAMPLE_DIR = DATA_DIR / "character_voice_samples"
MANIFEST = DATA_DIR / "character_voice_references.json"
PROFILES = ROOT / "voice_profiles.json"


def _read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return fallback


def slugify(value: str) -> str:
    value = str(value).strip().lower()
    if not value or len(value) > 80 or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for c in value):
        raise ValueError("角色 ID 格式无效")
    return value


def character_ids() -> list[str]:
    profiles = _read_json(PROFILES, {})
    return sorted(k for k, v in profiles.items() if k != "default" and isinstance(v, dict)) if isinstance(profiles, dict) else []


def inspect_wav(raw: bytes, *, min_seconds: float = 1.0, max_seconds: float = 30.0) -> dict[str, Any]:
    if not raw or len(raw) > 20 * 1024 * 1024:
        raise ValueError("WAV 文件不能为空且不得超过 20 MB")
    import io
    try:
        with wave.open(io.BytesIO(raw), "rb") as wf:
            channels, width, rate, frames = wf.getnchannels(), wf.getsampwidth(), wf.getframerate(), wf.getnframes()
            duration = frames / float(rate or 1)
            if wf.getcomptype() != "NONE" or channels not in (1, 2) or width not in (1, 2, 3, 4) or rate < 8000 or rate > 192000:
                raise ValueError("WAV 参数不受支持；请使用 PCM、8–192 kHz、单声道或双声道")
            if duration < min_seconds or duration > max_seconds:
                raise ValueError(f"音频时长需在 {min_seconds:g}–{max_seconds:g} 秒之间，当前 {duration:.2f} 秒")
            frames_data = wf.readframes(min(frames, rate * 30))
            peak = 0
            sum_squares = 0.0
            sample_count = 0
            if width == 1:
                samples = (b - 128 for b in frames_data)
            elif width == 2:
                samples = (x[0] for x in struct.iter_unpack("<h", frames_data[:len(frames_data)//2*2]))
            elif width == 3:
                def _signed24(chunk):
                    value = int.from_bytes(chunk, "little", signed=False)
                    return value - (1 << 24) if value & (1 << 23) else value
                samples = (_signed24(frames_data[i:i+3]) for i in range(0, len(frames_data)-2, 3))
            else:
                samples = (x[0] for x in struct.iter_unpack("<i", frames_data[:len(frames_data)//4*4]))
            for sample in samples:
                peak = max(peak, abs(sample)); sum_squares += sample * sample; sample_count += 1
            full_scale = float((1 << (8 * width - 1)) - 1)
            rms = math.sqrt(sum_squares / sample_count) if sample_count else 0.0
            peak_dbfs = 20 * math.log10(max(peak / full_scale, 1e-8))
            rms_dbfs = 20 * math.log10(max(rms / full_scale, 1e-8))
            return {"duration_seconds": round(duration, 2), "sample_rate": rate, "channels": channels,
                    "sample_width_bytes": width, "peak_dbfs": round(peak_dbfs, 1), "rms_dbfs": round(rms_dbfs, 1),
                    "quality_flags": (["音量偏低或近似静音"] if rms_dbfs < -45 else []) + (["可能存在削波"] if peak_dbfs > -0.5 else [])}
    except (wave.Error, EOFError) as exc:
        raise ValueError("无法解析 PCM WAV；请转换为标准 WAV 后重试") from exc


def save_reference(character_id: str, raw: bytes, *, authorization_confirmed: bool, authorization_basis: str) -> dict[str, Any]:
    cid = slugify(character_id)
    if cid not in character_ids():
        raise ValueError("未知角色 ID")
    if not authorization_confirmed:
        raise ValueError("必须确认你拥有该参考音频的使用授权")
    basis = str(authorization_basis).strip()[:500]
    if len(basis) < 8:
        raise ValueError("请填写授权来源或同意依据（至少 8 个字符）")
    metrics = inspect_wav(raw, min_seconds=1.0, max_seconds=30.0)
    REFERENCE_DIR.mkdir(parents=True, exist_ok=True)
    path = REFERENCE_DIR / f"{cid}.wav"
    path.write_bytes(raw)
    manifest = _read_json(MANIFEST, {"version": 1, "items": {}})
    if not isinstance(manifest, dict): manifest = {"version": 1, "items": {}}
    items = manifest.get("items") if isinstance(manifest.get("items"), dict) else {}
    record = {"character_id": cid, "path": str(path.relative_to(ROOT)).replace("\\", "/"),
              "sha256": hashlib.sha256(raw).hexdigest(), "authorization_verified": True,
              "authorization_basis": basis, "authorization_recorded_at": date.today().isoformat(), **metrics}
    items[cid] = record
    manifest["items"] = items
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return record


def get_references() -> dict[str, dict[str, Any]]:
    data = _read_json(MANIFEST, {"items": {}})
    items = data.get("items", {}) if isinstance(data, dict) else {}
    result = {}
    if not isinstance(items, dict): return result
    for cid, item in items.items():
        try: cid = slugify(cid)
        except ValueError: continue
        if not isinstance(item, dict) or not item.get("authorization_verified"): continue
        path = (ROOT / str(item.get("path", ""))).resolve()
        try: path.relative_to(REFERENCE_DIR.resolve())
        except ValueError: continue
        if cid not in character_ids() or not path.is_file(): continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != str(item.get("sha256", "")).lower(): continue
        result[cid] = {**item, "exists": True}
    return result


def delete_reference(character_id: str) -> bool:
    cid = slugify(character_id)
    if cid not in character_ids(): raise ValueError("未知角色 ID")
    path = REFERENCE_DIR / f"{cid}.wav"
    existed = path.exists()
    path.unlink(missing_ok=True)
    data = _read_json(MANIFEST, {"version": 1, "items": {}})
    if isinstance(data, dict) and isinstance(data.get("items"), dict):
        data["items"].pop(cid, None)
        MANIFEST.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return existed


def get_sample_path(sample_id: str) -> Path:
    sid = str(sample_id).strip()
    if len(sid) != 32 or any(c not in "0123456789abcdef" for c in sid): raise ValueError("样本 ID 无效")
    path = (SAMPLE_DIR / f"{sid}.wav").resolve()
    try: path.relative_to(SAMPLE_DIR.resolve())
    except ValueError as exc: raise ValueError("样本路径无效") from exc
    if not path.is_file(): raise FileNotFoundError("试听样本不存在")
    return path
