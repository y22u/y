"""Validated, atomic backup/restore helpers for local productivity data.

This module intentionally handles only the workbench's todos and notes. It does
not export API keys, application configuration, or chat history.
"""
from __future__ import annotations
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

BACKUP_VERSION = 1
MAX_IMPORT_BYTES = 5 * 1024 * 1024


def normalize_data(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("备份内容必须是 JSON 对象")
    todos = value.get("todos", [])
    notes = value.get("notes", "")
    if not isinstance(todos, list) or not isinstance(notes, str):
        raise ValueError("备份格式无效：todos 必须是列表，notes 必须是文本")
    clean_todos = []
    for row in todos:
        if not isinstance(row, dict) or not isinstance(row.get("text", ""), str):
            raise ValueError("备份中存在无效的待办项目")
        text = row.get("text", "").strip()
        if not text:
            continue
        clean_todos.append({
            "text": text[:2000],
            "done": bool(row.get("done", False)),
            "created": str(row.get("created", ""))[:64],
        })
        if len(clean_todos) > 10000:
            raise ValueError("待办数量超过安全上限")
    if len(notes) > 2_000_000:
        raise ValueError("便签内容过大")
    return {"todos": clean_todos, "notes": notes}


def atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def export_backup(path: Path, data: dict[str, Any]) -> None:
    normalized = normalize_data(data)
    payload = {
        "app": "StarPetFusion",
        "kind": "productivity-backup",
        "version": BACKUP_VERSION,
        "exported_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        **normalized,
    }
    atomic_write_json(path, payload)


def read_backup(path: Path) -> dict[str, Any]:
    if not path.is_file() or path.stat().st_size > MAX_IMPORT_BYTES:
        raise ValueError("文件不存在或超过 5 MB，无法导入")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"无法读取 JSON 备份：{exc}") from exc
    if not isinstance(payload, dict) or payload.get("kind") != "productivity-backup":
        raise ValueError("这不是 StarPetFusion 日常工作台备份文件")
    if payload.get("version") != BACKUP_VERSION:
        raise ValueError("备份版本不受支持")
    return normalize_data(payload)


def merge_data(current: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
    """Keep existing data; append distinct todos and preserve existing notes."""
    current = normalize_data(current)
    incoming = normalize_data(incoming)
    existing = {(x["text"].casefold(), x["created"]) for x in current["todos"]}
    for task in incoming["todos"]:
        key = (task["text"].casefold(), task["created"])
        if key not in existing:
            current["todos"].append(task)
            existing.add(key)
    if incoming["notes"]:
        if current["notes"] and incoming["notes"] != current["notes"]:
            current["notes"] += "\n\n--- 导入备份：" + datetime.now().strftime("%Y-%m-%d %H:%M") + " ---\n" + incoming["notes"]
        elif not current["notes"]:
            current["notes"] = incoming["notes"]
    return current
