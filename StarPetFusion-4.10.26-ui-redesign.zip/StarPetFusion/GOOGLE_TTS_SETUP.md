# Google TTS Setup

## Gemini API (preview)
- Provider: `Gemini API · gemini-2.5-flash-preview-tts`
- Model: `gemini-2.5-flash-preview-tts`
- Environment variable default: `GEMINI_API_KEY`
- The app sends text to Google's Gemini API and writes the returned PCM audio to a WAV file.

## Google Cloud Text-to-Speech API
- Provider: `Google Cloud TTS API · gemini-2.5-flash-tts`
- Model: `gemini-2.5-flash-tts`
- Set up Google Application Default Credentials (ADC) for the Google account/service identity used by the app, enable the Cloud Text-to-Speech API, and configure the project/billing/quota as required.
- Optional project environment variable: `GOOGLE_CLOUD_PROJECT` (used as `x-goog-user-project` when set).
- Region defaults to `global`; use only regions currently supported for the selected model.
- `google-auth` is installed by `setup.bat` via requirements.txt.

## Notes
- Gemini API and Cloud TTS use different model IDs and authentication. Do not paste API keys into project files or screenshots.
- Voice names/language codes must be supported by the selected endpoint/model. An HTTP success is not guaranteed until credentials, API access, quota, and region are configured.
- The app has not been live-tested against Google endpoints in the build environment; use the UI's test voice flow on your machine.
