from __future__ import annotations
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QCheckBox, QComboBox,
                               QDialogButtonBox, QGroupBox, QMessageBox)
from access_control import PERMISSIONS, PRESETS, get_permissions

class PermissionsDialog(QDialog):
    """Edit feature-level permissions and privacy presets."""
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("StarPetFusion · 基本权限管理")
        self.resize(500, 650)
        layout = QVBoxLayout(self)
        intro = QLabel("控制本应用可使用的功能。文件查找仅扫描手动选择的目录；打开文件会再次确认。关闭联网权限后，远程模型请求和天气查询会被拦截。\n注意：这是应用功能开关，不是系统账户级安全隔离。")
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.preset = QComboBox()
        self.preset.addItems(list(PRESETS))
        layout.addWidget(QLabel("快速预设"))
        layout.addWidget(self.preset)
        self.checks = {}
        group = QGroupBox("权限列表")
        group_layout = QVBoxLayout(group)
        current = get_permissions(config)
        for key, label in PERMISSIONS.items():
            check = QCheckBox(label)
            check.setChecked(current[key])
            self.checks[key] = check
            group_layout.addWidget(check)
        layout.addWidget(group)
        self.preset.currentTextChanged.connect(self.apply_preset)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    def apply_preset(self, name):
        preset = PRESETS.get(name, {})
        for key, check in self.checks.items():
            check.setChecked(bool(preset.get(key, False)))
    def save(self):
        permissions = {key: check.isChecked() for key, check in self.checks.items()}
        if permissions["chat"] and not permissions["network"]:
            QMessageBox.information(self, "权限提示", "已关闭联网权限，因此远程模型聊天仍会被拦截。")
        self.config.set("permissions", permissions)
        self.accept()
