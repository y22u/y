"""Best-effort host resource telemetry and conservative concurrency advice.

This module never changes user-configured limits automatically. It reports the
current host budget and a transparent recommendation so operators can tune safely.
"""
from __future__ import annotations
import os
import platform
import shutil
import subprocess
from typing import Any

_GIB = 1024 ** 3


def _memory_bytes() -> tuple[int | None, int | None, str]:
    try:
        import psutil  # optional dependency; not required to run the service
        mem = psutil.virtual_memory()
        return int(mem.total), int(mem.available), "psutil"
    except Exception:
        pass
    if os.name == "nt":
        try:
            import ctypes
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            status = MEMORYSTATUSEX(); status.dwLength = ctypes.sizeof(status)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return int(status.ullTotalPhys), int(status.ullAvailPhys), "windows-api"
        except Exception:
            pass
    try:
        values: dict[str, int] = {}
        with open("/proc/meminfo", encoding="ascii") as stream:
            for line in stream:
                key, value = line.split(":", 1)
                if key in {"MemTotal", "MemAvailable", "MemFree", "Buffers", "Cached"}:
                    values[key] = int(value.strip().split()[0]) * 1024
        total = values.get("MemTotal")
        available = values.get("MemAvailable", values.get("MemFree", 0) + values.get("Buffers", 0) + values.get("Cached", 0))
        if total and available:
            return total, available, "proc-meminfo"
    except Exception:
        pass
    return None, None, "unavailable"


def _gpu_memory() -> dict[str, Any] | None:
    executable = shutil.which("nvidia-smi")
    if not executable:
        return None
    try:
        result = subprocess.run([executable, "--query-gpu=name,memory.total,memory.free,memory.used", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=1.5, check=True)
        devices = []
        for line in result.stdout.splitlines():
            parts = [part.strip() for part in line.split(",")]
            if len(parts) != 4:
                continue
            total, free, used = (int(parts[i]) * 1024**2 for i in (1, 2, 3))
            devices.append({"name": parts[0][:100], "total_bytes": total, "free_bytes": free, "used_bytes": used})
        if devices:
            return {"available": True, "source": "nvidia-smi", "devices": devices,
                "total_bytes": sum(d["total_bytes"] for d in devices), "free_bytes": sum(d["free_bytes"] for d in devices),
                "used_bytes": sum(d["used_bytes"] for d in devices)}
    except Exception:
        return {"available": False, "source": "nvidia-smi", "devices": [], "note": "显卡信息读取失败"}
    return None


def resource_snapshot() -> dict[str, Any]:
    total, available, source = _memory_bytes()
    gpu = _gpu_memory()
    ram_gib = round(total / _GIB, 2) if total else None
    available_gib = round(available / _GIB, 2) if available else None
    gpu_free_gib = round(gpu["free_bytes"] / _GIB, 2) if gpu and gpu.get("available") else None
    # Conservative guidance, not a guarantee: model KV cache/context and non-LLM
    # applications consume additional memory beyond the weight file size.
    if available is None:
        recommended = 1
        level = "unknown"
        reason = "无法读取可用内存，采用保守建议；请手动确认模型内存需求。"
    elif available < 3 * _GIB:
        recommended, level = 1, "critical"
        reason = "可用 RAM 低于 3 GiB，建议单任务串行，优先使用小模型。"
    elif available < 6 * _GIB:
        recommended, level = 1, "low"
        reason = "可用 RAM 低于 6 GiB，建议对话并发设为 1，避免同时加载大模型。"
    elif available < 12 * _GIB:
        recommended, level = 2, "moderate"
        reason = "可用 RAM 处于中等水平，建议对话并发不超过 2，并限制上下文长度。"
    else:
        recommended, level = 3, "healthy"
        reason = "可用 RAM 相对充足；仍需结合模型大小、KV Cache 和显存验证并发。"
    if gpu and gpu.get("available") and gpu_free_gib is not None and gpu_free_gib < 2:
        recommended = min(recommended, 1)
        reason += " 检测到 NVIDIA 可用显存低于 2 GiB，建议避免并行加载 GPU 模型。"
    return {"platform": platform.system(), "ram": {"total_bytes": total, "available_bytes": available,
                "total_gib": ram_gib, "available_gib": available_gib, "source": source},
            "gpu": gpu or {"available": False, "source": "not-detected", "devices": [], "note": "未检测到可用的 nvidia-smi；其他显卡/共享显存未纳入统计。"},
            "advice": {"level": level, "recommended_chat_concurrency": recommended, "reason": reason,
                "applied_automatically": False},
            "caveat": "这是基于主机可用内存的保守建议，不是模型显存需求预测；Ollama /api/ps 的实际驻留占用应优先参考。"}
