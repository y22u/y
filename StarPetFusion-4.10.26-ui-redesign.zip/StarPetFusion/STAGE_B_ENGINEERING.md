# 阶段 B：工程结构优化与服务治理

## 目标
把分散的外部服务检查、日志策略和异常边界收敛为可测试的模块，减少调试时对敏感数据的暴露，并保持现有角色、聊天、Agent、语音等功能的兼容性。

## 两次迭代记录

### 迭代 1：统一服务配置检查
- 新增 `service_health.py`。
- 统一校验 AI endpoint 的 HTTPS/本机回环策略、模型 ID、TTS provider 和 Agent 授权目录配置；可运行 `python service_health.py` 输出脱敏 JSON 报告。
- 检查为离线操作，不发起真实网络请求，也不读取或输出密钥值。
- 新增覆盖合法/非法 endpoint、缺失模型和原生 Google TTS 配置的单元测试。

### 迭代 2：统一日志与异常边界
- 新增 `app_logging.py`，日志写入用户数据目录 `logs/starpetfusion.log`，单文件 1 MB，保留 3 个轮转备份。
- 对常见 Authorization Bearer、API Key、access token、refresh token 形态执行脱敏。
- AI 服务记录超时、HTTP 状态及错误类型；不记录 prompt、完整响应或凭据。
- 外部 TTS 的服务商专属异常不会向 UI 线程传播，调用方可继续既有本地语音降级流程。
- 应用启动时初始化日志；日志目录不可用时仍允许应用继续启动。

## 验收标准
1. `python -m compileall -q .` 通过。
2. `python -m unittest discover -s tests -v` 通过。
3. 离线诊断不输出任何密钥或 token 值。
4. 无效远程 HTTP endpoint 被拒绝，本机回环 HTTP 和 HTTPS 被接受。
5. 日志文件采用轮转，服务失败日志不包含请求正文或密钥。
6. 在 Windows 目标机完成启动、AI 请求、TTS 播放、服务异常降级及角色/历史数据回归测试。

## 已知限制
- 此阶段仍未执行真实 Google API 请求或 Windows 桌面/音频测试。
- 通用日志脱敏是防误记日志的纵深防御，不替代对日志消息内容的最小化设计。
- 本轮未大规模拆分 `main.py`，避免在无 GUI 运行环境中进行高风险重构；后续可继续按 View / Controller / Service 分层拆解。
