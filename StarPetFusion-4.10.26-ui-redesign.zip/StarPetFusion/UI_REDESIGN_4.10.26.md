# StarPetFusion 4.10.26 — 工作台 UI 重设计

## 设计方向

本次基于现有 FastAPI + 原生 HTML/CSS/JavaScript 前端做渐进式重设计，不更换后端框架、不改 API 路径、不引入新的运行时依赖。整体采用深色星际控制台风格：深蓝灰背景、紫色主操作、青绿色状态提示、低对比网格与卡片层级。

## 变更内容

- 全面重写 `frontend/assets/app.css`，统一侧栏、顶部栏、按钮、表单、卡片、状态标签、连接器、角色库、自动任务、语音设置和安全页面的视觉规范。
- 优化宽屏、平板和手机布局；增加减少动态效果偏好支持；移除 Google Fonts 网络导入，页面字体不再依赖外部网络。
- 将总览的角色图片展示改为纯 CSS 的抽象星轨图形，避免把角色立绘误当成桌宠本体。
- 补齐缺失的 `agent` 页面。此前导航存在“Agent 对话”入口，但页面及聊天表单 DOM 不存在，脚本在绑定聊天事件时可能抛出异常并中断后续交互。
- Agent 页面包含本地 Ollama / 外部 Agent 选择、对话区域、建议提示和连接器/模型/自动任务快捷入口；复用既有 `POST /api/v1/chat` API。
- 修复 TTS 表单状态节点与总览指标重复使用 `tts-status` ID 的问题，表单现在使用 `tts-form-status`。
- 添加 Enter 发送、Shift+Enter 换行及建议提示快捷填入。
- 保留原有角色库图片预览、模型中心、TTS/ASR、连接器、安全页和自动任务的 DOM ID 与后端 API 约定。

## 验证

- JavaScript 语法检查：通过（`node --check frontend/assets/app.js`）。
- 全部 Python 测试：164 passed、1 skipped、33 subtests passed（重设计前基线）。
- 重设计后 UI 契约测试：检查页面导航目标、DOM ID 唯一性、Agent/TTS 表单绑定、响应式与减少动态效果样式。
- 本机服务、Ollama、ASR/TTS 推理仍需在目标 Windows 环境实测。
