"""Bounded concurrency controls for model inference and resource-heavy tasks."""
from __future__ import annotations
import os, threading
from contextlib import contextmanager

_LIMITS = {
    "chat": max(1, min(int(os.getenv("STAR_PET_CHAT_CONCURRENCY", "3")), 16)),
    "tts": max(1, min(int(os.getenv("STAR_PET_TTS_CONCURRENCY", "2")), 8)),
    "asr": max(1, min(int(os.getenv("STAR_PET_ASR_CONCURRENCY", "1")), 4)),
    "model_ops": max(1, min(int(os.getenv("STAR_PET_MODEL_OPS_CONCURRENCY", "2")), 4)),
}
_SEMAPHORES = {name: threading.BoundedSemaphore(value) for name, value in _LIMITS.items()}
_ACTIVE = {name: 0 for name in _LIMITS}
_REJECTED = {name: 0 for name in _LIMITS}
_WAITING = {name: 0 for name in _LIMITS}
_LOCK = threading.Lock()

@contextmanager
def slot(task: str, timeout: float = 2.0):
    if task not in _SEMAPHORES:
        raise ValueError(f"unknown task class: {task}")
    sem = _SEMAPHORES[task]
    with _LOCK:
        _WAITING[task] += 1
    acquired = sem.acquire(timeout=max(0.0, float(timeout)))
    with _LOCK:
        _WAITING[task] = max(0, _WAITING[task] - 1)
        if acquired:
            _ACTIVE[task] += 1
        else:
            _REJECTED[task] += 1
    if not acquired:
        raise TimeoutError(f"{task} concurrency limit reached")
    try:
        yield
    finally:
        with _LOCK:
            _ACTIVE[task] = max(0, _ACTIVE[task] - 1)
        sem.release()

def snapshot():
    with _LOCK:
        return {name: {"limit": _LIMITS[name], "active": _ACTIVE[name],
                       "waiting": _WAITING[name], "rejected": _REJECTED[name]}
                for name in _LIMITS}
