"""Local SQLite character, appearance and persona database for StarPetFusion."""
from __future__ import annotations
import sqlite3, shutil, hashlib
from pathlib import Path
from datetime import datetime, timezone
from config_store import app_data_dir

DB_PATH = app_data_dir() / "character_library.sqlite3"
ASSET_HOME = app_data_dir() / "character_assets"
DEFAULT_CHARACTERS = [
    ("dafeiyu", "大肥鱼", "DeepSeek 社区二创鲸鱼娘桌宠；温和、活泼、爱吐槽。", "温柔俏皮、简短有趣", "社区二创语气", "PC2005-cloud/dsh-pet", "https://github.com/PC2005-cloud/dsh-pet", "CC BY-NC-SA 4.0", "需本地联网下载；不随安装包再分发"),
    ("the-herta", "大黑塔", "天才俱乐部成员；理性、自信、重视效率，表达带有冷静的幽默感。", "聪明、从容、略带傲气", "清晰、从容", "Honkai: Star Rail", "https://hsr.hoyoverse.com/", "官方素材权利归原权利人；个人非商业同人使用须遵守规则", "未随包附带立绘"),
    ("aglaea", "阿格莱雅", "黄金裔角色；优雅、坚定，适合沉静而富有仪式感的表达。", "优雅、温和、坚定", "优雅、温和", "Honkai: Star Rail", "https://hsr.hoyoverse.com/", "官方素材权利归原权利人；个人非商业同人使用须遵守规则", "未随包附带立绘"),
    ("hysilens", "海瑟音", "崩铁角色资料占位档案；角色细节以本地导入的可信资料为准。", "沉静、细腻", "沉静、细腻", "Honkai: Star Rail", "https://hsr.hoyoverse.com/", "官方素材权利归原权利人；个人非商业同人使用须遵守规则", "未随包附带立绘"),
    ("march-7th", "三月七", "开朗、好奇、喜欢记录旅途。", "活泼、亲切", "活泼、亲切", "Honkai: Star Rail", "https://hsr.hoyoverse.com/", "官方素材权利归原权利人；个人非商业同人使用须遵守规则", "未随包附带立绘"),
    ("firefly", "流萤", "温柔而坚定，珍视同伴与平凡日常。", "温柔、真诚", "温柔、真诚", "Honkai: Star Rail", "https://hsr.hoyoverse.com/", "官方素材权利归原权利人；个人非商业同人使用须遵守规则", "未随包附带立绘"),
    ("acheron", "黄泉", "沉静、寡言，表达简洁且有思考感。", "克制、沉静", "克制、沉静", "Honkai: Star Rail", "https://hsr.hoyoverse.com/", "官方素材权利归原权利人；个人非商业同人使用须遵守规则", "未随包附带立绘"),
    ("robin", "知更鸟", "温和、礼貌，表达具有舞台感与鼓励性。", "温柔、明亮", "温柔、明亮", "Honkai: Star Rail", "https://hsr.hoyoverse.com/", "官方素材权利归原权利人；个人非商业同人使用须遵守规则", "未随包附带立绘"),
]

class CharacterDatabase:
    def __init__(self, path: Path | None = None):
        self.path = Path(path or DB_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self._schema(); self.seed()

    def _schema(self):
        self.conn.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS characters(
          slug TEXT PRIMARY KEY, name TEXT NOT NULL, setting TEXT NOT NULL DEFAULT '',
          personality TEXT NOT NULL DEFAULT '', voice_style TEXT NOT NULL DEFAULT '',
          source_name TEXT NOT NULL DEFAULT '', source_url TEXT NOT NULL DEFAULT '',
          license TEXT NOT NULL DEFAULT '', asset_status TEXT NOT NULL DEFAULT 'no_asset',
          updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS assets(
          id INTEGER PRIMARY KEY AUTOINCREMENT, character_slug TEXT NOT NULL,
          kind TEXT NOT NULL DEFAULT 'portrait', path TEXT NOT NULL UNIQUE,
          source_name TEXT NOT NULL DEFAULT '', source_url TEXT NOT NULL DEFAULT '',
          license TEXT NOT NULL DEFAULT 'user-provided', attribution TEXT NOT NULL DEFAULT '',
          sha256 TEXT NOT NULL DEFAULT '', is_active INTEGER NOT NULL DEFAULT 0,
          imported_at TEXT NOT NULL, FOREIGN KEY(character_slug) REFERENCES characters(slug) ON DELETE CASCADE);
        CREATE TABLE IF NOT EXISTS source_catalog(
          id INTEGER PRIMARY KEY AUTOINCREMENT, platform TEXT NOT NULL, title TEXT NOT NULL,
          url TEXT NOT NULL UNIQUE, source_type TEXT NOT NULL, license_note TEXT NOT NULL,
          download_state TEXT NOT NULL DEFAULT 'catalog_only', checked_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_assets_character ON assets(character_slug,kind);
        """)
        self.conn.commit()

    def seed(self):
        now = datetime.now(timezone.utc).isoformat()
        for row in DEFAULT_CHARACTERS:
            self.conn.execute("""INSERT INTO characters(slug,name,setting,personality,voice_style,source_name,source_url,license,asset_status,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(slug) DO NOTHING""", (*row[:8], 'no_asset', now))
        sources = [
          ('GitHub','dsh-pet 大肥鱼桌宠','https://github.com/PC2005-cloud/dsh-pet','community asset','CC BY-NC-SA 4.0; non-commercial; attribution and share-alike; verify current terms'),
          ('GitHub','大肥鱼跨平台桌宠参考','https://github.com/MerZlin/dsh-pet-indesktop','code and animation reference','Check repository LICENSE and THIRD_PARTY_NOTICES; not all assets share code license'),
          ('GitHub','StarRailRes 资源索引','https://github.com/Mar-7th/StarRailRes','game resource index','Game assets retain original rights; do not bundle/re-distribute without checking permissions'),
          ('Bilibili','崩铁同人作品创作指引','https://www.bilibili.com/opus/1089707102255972370','policy/reference','Official policy reference, not an image download license'),
          ('HoYoverse','官方同人创作指引','https://hsr.hoyoverse.com/en-us/news/111203?type=news','policy/reference','Personal non-commercial derivative use conditions apply; not blanket permission for simple re-upload'),
          ('Pixiv','崩铁 Q 版作品检索入口','https://www.pixiv.net/tags/%E5%B4%A9%E5%A3%8A%3A%E3%82%B9%E3%82%BF%E3%83%BC%E3%83%AC%E3%82%A4%E3%83%AB/artworks','search link','Catalog only; import only with creator permission or explicit reusable license'),
          ('X','崩铁 Q 版作品检索入口','https://x.com/search?q=Honkai%20Star%20Rail%20chibi&src=typed_query','search link','Catalog only; do not scrape; ask creator permission before importing'),
        ]
        for src in sources:
            self.conn.execute('INSERT OR IGNORE INTO source_catalog(platform,title,url,source_type,license_note,checked_at) VALUES(?,?,?,?,?,?)', (*src, now))
        self.conn.commit()

    def characters(self):
        return [dict(r) for r in self.conn.execute('SELECT * FROM characters ORDER BY name')]

    def get_character(self, slug):
        r = self.conn.execute('SELECT * FROM characters WHERE slug=?', (slug,)).fetchone()
        return dict(r) if r else None

    def update_profile(self, slug, setting, personality, voice_style):
        self.conn.execute('UPDATE characters SET setting=?,personality=?,voice_style=?,updated_at=? WHERE slug=?',
            (setting, personality, voice_style, datetime.now(timezone.utc).isoformat(), slug))
        self.conn.commit()

    def import_asset(self, slug, source_path, kind='portrait', source_name='user import', source_url='', license='user-provided', attribution=''):
        if not self.get_character(slug):
            raise ValueError(f'数据库中没有角色：{slug}')
        src = Path(source_path).expanduser().resolve()
        if not src.is_file(): raise FileNotFoundError(src)
        if src.suffix.lower() not in {'.png','.jpg','.jpeg','.webp','.bmp','.gif'}:
            raise ValueError('只支持 PNG/JPG/WEBP/BMP/GIF')
        dest_dir = ASSET_HOME / slug; dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / (kind + src.suffix.lower())
        if src != dest.resolve(): shutil.copy2(src, dest)
        h = hashlib.sha256(dest.read_bytes()).hexdigest()
        self.conn.execute('UPDATE assets SET is_active=0 WHERE character_slug=? AND kind=?', (slug, kind))
        self.conn.execute("""INSERT INTO assets(character_slug,kind,path,source_name,source_url,license,attribution,sha256,is_active,imported_at)
        VALUES(?,?,?,?,?,?,?,?,1,?) ON CONFLICT(path) DO UPDATE SET character_slug=excluded.character_slug,kind=excluded.kind,source_name=excluded.source_name,source_url=excluded.source_url,license=excluded.license,attribution=excluded.attribution,sha256=excluded.sha256,is_active=1,imported_at=excluded.imported_at""",
            (slug, kind, str(dest), source_name, source_url, license, attribution, h, datetime.now(timezone.utc).isoformat()))
        self.conn.execute('UPDATE characters SET asset_status=?,updated_at=? WHERE slug=?',
            ('ready' if kind == 'portrait' else 'has_animation', datetime.now(timezone.utc).isoformat(), slug))
        self.conn.commit()
        return str(dest)

    def active_asset(self, slug, kind='portrait'):
        r = self.conn.execute('SELECT path FROM assets WHERE character_slug=? AND kind=? AND is_active=1 ORDER BY id DESC LIMIT 1', (slug, kind)).fetchone()
        return r['path'] if r and Path(r['path']).is_file() else None

    def assets(self, slug=None):
        rows = self.conn.execute('SELECT * FROM assets WHERE character_slug=? ORDER BY kind,id DESC', (slug,)) if slug else self.conn.execute('SELECT * FROM assets ORDER BY character_slug,kind,id DESC')
        return [dict(r) for r in rows]

    def source_catalog(self):
        return [dict(r) for r in self.conn.execute('SELECT * FROM source_catalog ORDER BY platform,title')]

    def close(self): self.conn.close()
