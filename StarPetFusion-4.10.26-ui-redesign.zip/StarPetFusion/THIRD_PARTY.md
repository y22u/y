# 第三方项目、署名与许可说明

此整合项目默认不把上游仓库的源代码、角色资料或图像复制进发行 ZIP。运行 `python prepare.py` 时会从 GitHub 下载对应仓库到 `vendor/`。下载后请阅读各仓库内附带的 README、LICENSE 和素材归属说明。

| 上游仓库 | 本项目使用方式 | 许可 / 注意事项 |
|---|---|---|
| [UniquenlOvE/TheHerta-CodexPet](https://github.com/UniquenlOvE/TheHerta-CodexPet) | 下载其 `the-herta/pet.json` 与 `spritesheet.webp` 等内容，通过安装器放入 Codex 的宠物目录 | 上游原创脚本/文档许可为 MIT；上游 `ATTRIBUTION.md` 明确说明 MIT 不授予第三方角色、商标或原作素材权利。 |
| [gblw2233/hsr-skills](https://github.com/gblw2233/hsr-skills) | 在本地扫描角色目录并按选定角色读取所需 Markdown 资料 | 仓库声明 MIT；仓库同时声明角色设定、世界观及原作内容权利归 HoYoverse / miHoYo，并标注非官方、非商业粉丝创作。请自行核对完整条款。 |
| [1190fasheqi/dafeiyu-pet](https://github.com/1190fasheqi/dafeiyu-pet) | 下载桌宠素材；本项目提供独立 Qt 桌面窗口和交互实现 | 上游代码许可证为 MIT；仍应保留其许可证和署名。角色/形象权利不因代码许可自动转让。 |

## 分发建议

- 不要把 API Key、`config.json` 或个人对话数据库提交到版本控制。
- 对外发布整合版时，应为实际分发的每一份第三方代码/素材附带需要的许可证和署名。
- 对角色图片、游戏设定文本、商标和商业用途，MIT 代码许可不等同于角色/素材授权。


## 官方角色素材与语音
本发行包只包含原创的简要角色风格文字和官方资料链接，不包含官方游戏素材、音轨或角色模型。系统 TTS 使用用户操作系统已安装的通用声音；不克隆配音演员。请在分发前重新核对适用地区的官方粉丝创作指南与各依赖许可证。
