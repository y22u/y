"""Voice pipeline registry and compact persona-profile distillation.

This module does not train or copy proprietary model weights. It normalizes local
ASR/TTS backends and compresses delivery hints for consistent role-aware speech.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class BackendInfo:
    key: str
    label: str
    purpose: str
    optional_packages: tuple[str, ...]
    privacy: str

ASR_BACKENDS = {
    "faster-whisper": BackendInfo("faster-whisper", "Whisper 本地识别", "多语言语音转文字", ("faster-whisper", "sounddevice", "numpy"), "音频留在本机"),
    "system": BackendInfo("system", "系统语音识别", "由操作系统提供识别能力", (), "依系统设置而定"),
}
TTS_BACKENDS = {
    "pyttsx3": BackendInfo("pyttsx3", "系统 TTS", "文字转语音，依赖系统安装的声音", ("pyttsx3",), "通常在本机合成"),
    "external": BackendInfo("external", "授权的外部 TTS", "通过用户自行配置的服务合成", (), "音频文本可能发送至所配置服务"),
}

# Short, non-imitative delivery descriptors; they guide pacing, not identity/voice cloning.
STYLE_HINTS = {
    "neutral": "自然清晰，停顿适中",
    "elegant": "柔和优雅，语速稍慢，停顿清楚",
    "lyrical": "清澈平稳，节奏有韵律但不过度夸张",
    "warm": "温暖明亮，亲切自然",
    "precise": "吐字清楚，节奏利落，自信克制",
    "composed": "从容沉稳，语速偏慢，表达清楚",
    "cheerful": "轻快明亮，节奏活泼但保持清晰",
    "gentle": "柔和真诚，语速适中，避免过度煽情",
    "calm": "沉静克制，语速较慢，留有停顿",
    "cool": "冷静简练，节奏稳定",
    "playful": "机敏轻快，适度俏皮，不影响可懂度",
    "mysterious": "低起伏、柔和，带有叙述感",
    "assertive": "清楚坚定，有条理，不生硬",
    "professional": "务实利落，语调友好",
    "measured": "平静理性，语速均匀",
    "melodic": "柔和清晰，节奏自然，不刻意唱腔",
}

def distilled_voice_profile(profile: dict[str, Any] | None) -> dict[str, Any]:
    """Return a bounded, normalized speech profile suitable for any TTS adapter."""
    p = profile if isinstance(profile, dict) else {}
    style = str(p.get("style", "neutral")).strip().lower()
    hint = str(p.get("voice_hint", "")).strip()
    if style not in STYLE_HINTS:
        style = "neutral"
    return {
        "language": str(p.get("language", "zh-CN"))[:16],
        "rate": max(0.5, min(1.5, float(p.get("rate", 1.0)))),
        "volume": max(0.0, min(1.0, float(p.get("volume", 0.9)))),
        "style": style,
        "delivery": (hint or STYLE_HINTS[style])[:120],
    }

def backend_summary() -> dict[str, list[dict[str, str]]]:
    def pack(items: dict[str, BackendInfo]) -> list[dict[str, str]]:
        return [{"key": x.key, "label": x.label, "purpose": x.purpose,
                 "packages": ", ".join(x.optional_packages) or "无需额外依赖", "privacy": x.privacy}
                for x in items.values()]
    return {"asr": pack(ASR_BACKENDS), "tts": pack(TTS_BACKENDS)}
