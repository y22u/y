# StarPetFusion 4.10.26 — 本地智能体自动任务部署说明（已核验版）

## 运行方式（Windows，手动启动）

1. 解压本项目到有写入权限的目录，保留完整的 `StarPetFusion` 文件夹。
2. 首次安装依赖时运行 `setup.bat`；也可在项目目录执行 `python -m pip install -r requirements-service.txt`。
3. 双击 `start_service.bat` 启动本地网页服务。它绑定 `127.0.0.1:8765`，不会配置 Windows 服务或开机自启，也不应改为监听局域网。
4. 浏览器访问 `http://127.0.0.1:8765/`，打开左侧“自动任务”。
5. 点击“启动执行器”。如需定时巡检，选择“开启（每 30 分钟）”；定时任务仅在网页服务进程与执行器运行期间有效。
6. 建议先运行“服务与硬件巡检”，再运行“Ollama 模型盘点”。语音试听需要对应的本机 TTS 服务可用。

## 任务类型（固定白名单）

- `health_check`：检查本地网关、Ollama、IndexTTS、Qwen3-TTS 的就绪状态和资源概况。只记录问题，不会自动重启服务。
- `ollama_inventory`：读取本机 Ollama 版本、已安装模型和驻留模型；只允许有效的本机 loopback HTTP URL，不下载、删除或推送模型。
- `voice_sample`：每批 1–5 个角色，调用现有角色音色 API 生成试听；仅允许 `indextts` 或 `qwen3`。IndexTTS 要求角色已登记授权参考音频。
- `release_check`：先创建项目备份，再运行 `quality_gate.py`；只有质量门禁通过才生成 ZIP 与 SHA-256。不会自动安装依赖或修改源代码。
- `code_patch`：提交项目内文本文件相对路径和完整内容后进入 `needs_approval`。用户必须在工作台检查目标路径及内容并明确批准；已有文件先备份再写入。拒绝审批不会修改目标文件。

## 任务记录与恢复

- SQLite 数据库：`data/automation/tasks.sqlite3`
- 自动任务日志：`data/automation/automation.log`
- 项目备份、质量报告和发布包：`data/automation/backups/`、`data/automation/artifacts/`
- 主要任务状态：`queued`、`running`、`needs_approval`、`completed`、`failed`、`cancelled`。
- 若服务进程在任务执行中中断，残留的 `running` 任务会在下次模块初始化时标记为 `failed`，不会自动重放。检查错误与事件后，应重新创建任务；代码变更需要再次提交并审批。
- `health_check`、`ollama_inventory` 和 `voice_sample` 的未捕获异常最多进行 3 次尝试；质量门禁与代码写入不会自动重试。

## HTTP API

- `GET /api/v1/automation/status`
- `POST /api/v1/automation/runner/start`，JSON：`{"periodic_audit": false}`
- `POST /api/v1/automation/runner/stop`
- `GET /api/v1/automation/tasks?limit=50`
- `POST /api/v1/automation/tasks`，JSON 示例：`{"task_type":"health_check","payload":{},"title":"手动巡检"}`
- `POST /api/v1/automation/tasks/{task_id}/approval`，JSON：`{"approved": true}` 或 `false`
- `GET /api/v1/automation/events?limit=100`

注意：当前版本没有单独的任务重试 API；中断任务需要检查后重新创建。

## 安全边界与发布包

- 执行器只接受上面列出的任务类型，不提供任意 Shell、PowerShell 或 Python 命令执行端点。
- 代码变更路径必须位于项目目录内，限制文件扩展名、路径和内容大小；禁止修改凭据、数据库及受保护目录。
- 发布包排除虚拟环境、缓存、自动任务数据库/日志/备份/产物、角色参考音频/试听样本、模型分配本地配置、`.env` 凭据文件和数据库文件。
- 这属于应用层权限控制，并非抵御同一 Windows 用户下恶意程序的操作系统沙箱。不要将服务暴露到公网或局域网。
- 请先复制整个项目目录作为版本级回滚点。不要让智能体自动删除模型、批量清理文件、安装依赖或修改系统权限。

## 验收范围与限制

本次质量门禁包括 Python 编译、单元测试、服务配置健康检查和角色提示词生成校验。当前环境通过了 4/4 项，单元测试为 160 项通过、1 项跳过。该结果不代表 Windows、GPU、Ollama、IndexTTS 或 Qwen3-TTS 的真实本机服务已完成验收；请在目标电脑启动后实际检查并试听。
