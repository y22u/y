"""Validate restored voice-review assets without changing character settings."""
from __future__ import annotations
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "review_manifest.csv"
AUDIO_DIR = ROOT / "audio_mp3_16k"

def main() -> int:
    errors: list[str] = []
    with MANIFEST.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 36:
        errors.append(f"manifest rows expected 36, got {len(rows)}")
    seen: set[str] = set()
    for row in rows:
        audio = row.get("audio_file", "").strip()
        if not audio:
            errors.append(f"row {row.get('index', '?')}: empty audio_file")
            continue
        # Manifest paths are constrained to the audio folder; reject traversal.
        candidate = (ROOT / audio).resolve()
        if not candidate.is_relative_to(AUDIO_DIR.resolve()):
            errors.append(f"row {row.get('index', '?')}: unsafe audio path")
            continue
        if not candidate.is_file() or candidate.stat().st_size == 0:
            errors.append(f"row {row.get('index', '?')}: missing/empty audio {audio}")
        if audio in seen:
            errors.append(f"duplicate audio reference: {audio}")
        seen.add(audio)
    files = list(AUDIO_DIR.glob("*.mp3"))
    if len(files) != 36:
        errors.append(f"expected 36 mp3 files, got {len(files)}")
    pending = sum(1 for r in rows if "pending" in (r.get("review_status", "").lower()))
    if errors:
        print("FAIL")
        print("\n".join(f"- {e}" for e in errors))
        return 1
    print(f"PASS: manifest={len(rows)}, audio_files={len(files)}, pending_review={pending}")
    print("NOTE: pending annotations are not verified character/voice labels.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
