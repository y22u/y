from __future__ import annotations
"""OpenAI-compatible gateway for mature external agent applications.

The connector only forwards chat messages to an explicitly configured endpoint.
It does not execute remote tool calls locally. API credentials are read from an
environment variable, and only HTTPS or loopback HTTP endpoints are accepted.
"""
import os
from typing import Any
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter

# Reuse TCP/TLS connections across turns to reduce handshake latency.
_SESSION = requests.Session()
_ADAPTER = HTTPAdapter(pool_connections=8, pool_maxsize=16, max_retries=0, pool_block=False)
_SESSION.mount("https://", _ADAPTER)
_SESSION.mount("http://", _ADAPTER)

from integrations import integration_config, _allowed_url


class ExternalAgentError(RuntimeError):
    pass


def agent_config() -> dict[str, Any]:
    cfg = integration_config().get("external_agent", {})
    return cfg if isinstance(cfg, dict) else {}


class ExternalAgentClient:
    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config if config is not None else agent_config()

    @property
    def enabled(self) -> bool:
        return bool(self.config.get("enabled", False))

    def _prepare_messages(self, messages: list[dict[str, str]]) -> list[dict[str, str]]:
        """Normalize prompt and apply an explicit latency/quality profile."""
        clean = [{"role": str(m.get("role", "user")), "content": str(m.get("content", ""))}
                 for m in messages if m.get("role") in {"system", "user", "assistant"}]
        mode = str(self.config.get("latency_mode", "balanced")).lower()
        if mode not in {"fast", "balanced", "deep"}:
            mode = "balanced"
        # Bound context size in fast mode; always retain system instructions and the newest turns.
        if mode == "fast":
            system = [m for m in clean if m["role"] == "system"][:1]
            turns = [m for m in clean if m["role"] != "system"]
            keep = max(2, min(int(self.config.get("max_history_messages", 8)), 24))
            clean = system + turns[-keep:]
            max_chars = max(1000, min(int(self.config.get("max_message_chars", 5000)), 20000))
            clean = [{"role": m["role"], "content": m["content"][:max_chars]} for m in clean]
        if self.config.get("thinking_enabled", True):
            if mode == "fast":
                guidance = ("\n\n回答要求：优先直接回答用户当前问题，先给结论和可执行步骤；" 
                            "只在确有必要时简短分析，避免重复上下文和冗长铺垫。" 
                            "明确不确定性，不要声称完成未实际执行的操作；不要输出隐藏的逐字思维链。")
            else:
                guidance = ("\n\n回答质量要求：先识别用户目标和约束；对复杂任务在内部拆解步骤、检查关键假设与边界情况，"
                            "必要时比较方案并核对结论；信息不足时明确指出不确定性。最终给出清晰结论、关键依据和可执行步骤。"
                            "不要输出隐藏的逐字思维链；用简洁的推理摘要说明结论依据。")
            system_index = next((i for i, m in enumerate(clean) if m["role"] == "system"), None)
            if system_index is None:
                clean.insert(0, {"role": "system", "content": guidance.strip()})
            else:
                clean[system_index]["content"] += guidance
        return clean

    def _payload(self, model: str, messages: list[dict[str, str]]) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": float(self.config.get("temperature", 0.4)),
            "stream": False,
        }
        # Optional generation cap reduces long-tail latency when supported by the provider.
        try:
            max_tokens = int(self.config.get("max_tokens", 0))
        except (TypeError, ValueError):
            max_tokens = 0
        if 16 <= max_tokens <= 8192:
            payload["max_tokens"] = max_tokens
        effort = str(self.config.get("reasoning_effort", "auto")).strip().lower()
        if effort in {"low", "medium", "high"}:
            payload["reasoning_effort"] = effort
        return payload

    def chat(self, messages: list[dict[str, str]], timeout: int | None = None) -> str:
        cfg = self.config
        if not cfg.get("enabled"):
            raise ExternalAgentError("外部智能体连接未启用。请在桌宠右键菜单中配置连接。")
        endpoint = str(cfg.get("endpoint", "")).strip().rstrip("/")
        if not _allowed_url(endpoint):
            raise ExternalAgentError("外部智能体地址无效。仅允许 HTTPS 或本机回环 HTTP 地址。")
        model = str(cfg.get("model", "")).strip()
        if not model:
            raise ExternalAgentError("请填写外部智能体服务提供的模型或 Agent ID。")
        env_name = str(cfg.get("api_key_env", "STAR_PET_EXTERNAL_AGENT_KEY")).strip()
        if not env_name.isidentifier() or len(env_name) > 100:
            raise ExternalAgentError("API Key 环境变量名称无效。")
        key = os.environ.get(env_name, "").strip()
        host = (urlparse(endpoint).hostname or "").lower()
        if not key and host not in {"localhost", "127.0.0.1", "::1"}:
            raise ExternalAgentError(f"请先设置环境变量 {env_name}，不要把密钥写进项目文件。")
        url = endpoint if endpoint.endswith("/chat/completions") else endpoint + "/chat/completions"
        clean_messages = self._prepare_messages(messages)
        payload = self._payload(model, clean_messages)
        try:
            response = _SESSION.post(
                url,
                headers=({"Authorization": f"Bearer {key}"} if key else {}) | {"Content-Type": "application/json"},
                json=payload,
                timeout=(max(3, min(int(cfg.get("connect_timeout", 10)), 60)),
                        max(5, min(int(timeout or cfg.get("read_timeout", cfg.get("timeout", 240))), 600))),
            )
            response.raise_for_status()
            body = response.json()
            answer = body["choices"][0]["message"]["content"]
            if isinstance(answer, list):
                answer = "\n".join(str(p.get("text", "")) for p in answer if isinstance(p, dict))
            answer = str(answer).strip()
            if not answer:
                raise ExternalAgentError("外部智能体返回了空内容。")
            return answer
        except requests.Timeout as exc:
            raise ExternalAgentError("外部智能体请求超时。请检查 endpoint/模型 ID/服务是否在线；若连接建立慢，调高 connect_timeout；若模型生成慢，调高 read_timeout（建议 120–300 秒），并确认前端/反向代理没有更短的超时限制。") from exc
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "?"
            # Avoid exposing raw provider response bodies, which may contain private metadata.
            raise ExternalAgentError(f"外部智能体请求失败（HTTP {status}）。请检查服务状态、模型和凭据配置。") from exc
        except (requests.RequestException, ValueError, KeyError, IndexError, TypeError) as exc:
            raise ExternalAgentError(f"无法读取外部智能体响应（{type(exc).__name__}）。请检查接口是否返回 OpenAI 兼容 JSON。") from exc

    def test_connection(self) -> str:
        return self.chat([
            {"role": "system", "content": "你是连接测试助手。请简短回复中文。"},
            {"role": "user", "content": "只回复：外部智能体连接成功。"},
        ], timeout=max(30, min(int(self.config.get("read_timeout", self.config.get("timeout", 240))), 600)))

    def chat_with_tools(self, messages: list[dict[str, str]], gateway, timeout: int | None = None) -> str:
        """Bounded OpenAI-compatible tool loop; only gateway-registered tools are exposed."""
        cfg=self.config
        if not cfg.get("enabled"):
            raise ExternalAgentError("外部智能体连接未启用。")
        endpoint=str(cfg.get("endpoint","")).strip().rstrip("/")
        if not _allowed_url(endpoint): raise ExternalAgentError("外部智能体地址无效。")
        model=str(cfg.get("model","")).strip()
        env_name=str(cfg.get("api_key_env","STAR_PET_EXTERNAL_AGENT_KEY")).strip()
        if not env_name.isidentifier(): raise ExternalAgentError("API Key 环境变量名称无效。")
        key=os.environ.get(env_name,"").strip(); host=(urlparse(endpoint).hostname or "").lower()
        if not key and host not in {"localhost","127.0.0.1","::1"}: raise ExternalAgentError(f"请先设置环境变量 {env_name}。")
        url=endpoint if endpoint.endswith("/chat/completions") else endpoint+"/chat/completions"
        headers=({"Authorization":f"Bearer {key}"} if key else {})|{"Content-Type":"application/json"}
        conversation=self._prepare_messages(messages)
        tools=gateway.schemas(); max_rounds=max(1,min(int(cfg.get("tool_rounds",4)),6))
        for _ in range(max_rounds):
            payload=self._payload(model, conversation)
            payload.update({"tools":tools,"tool_choice":"auto"})
            try:
                r=_SESSION.post(url,headers=headers,json=payload,timeout=(max(3,min(int(cfg.get("connect_timeout",10)),60)), max(5,min(int(timeout or cfg.get("read_timeout",cfg.get("timeout",240))),600)))); r.raise_for_status(); body=r.json()
                msg=body["choices"][0]["message"]
            except requests.Timeout as exc: raise ExternalAgentError("外部 Agent 工具调用超时。请分别检查 connect_timeout 与 read_timeout，并确认服务端/代理没有更短的请求时限。") from exc
            except requests.HTTPError as exc:
                # Some OpenAI-compatible endpoints do not implement tools; fall back to normal chat once.
                if exc.response is not None and exc.response.status_code in (400,404,422): return self.chat(messages,timeout=timeout)
                raise ExternalAgentError(f"外部 Agent 请求失败：HTTP {exc.response.status_code if exc.response else '?'}") from exc
            except (requests.RequestException,ValueError,KeyError,IndexError,TypeError) as exc: raise ExternalAgentError(f"外部 Agent 响应无效：{exc}") from exc
            calls=msg.get("tool_calls") or []
            if not calls:
                content=msg.get("content","")
                if isinstance(content,list): content="\n".join(str(x.get("text","")) for x in content if isinstance(x,dict))
                return str(content).strip() or "外部智能体没有返回文本内容。"
            conversation.append({"role":"assistant","content":msg.get("content") or "","tool_calls":calls})
            for call in calls[:8]:
                fn=call.get("function",{}); name=str(fn.get("name","")); args=fn.get("arguments", "{}")
                result=gateway.execute(name,args)
                conversation.append({"role":"tool","tool_call_id":str(call.get("id","")),"content":__import__('json').dumps(result,ensure_ascii=False)[:12000]})
                if result.get("requires_confirmation"):
                    return "STAR_PET_PENDING_WRITE:"+__import__('json').dumps(result,ensure_ascii=False)
        return "已达到本轮工具调用次数上限。请查看已返回的结果，或缩小任务范围后重试。"
