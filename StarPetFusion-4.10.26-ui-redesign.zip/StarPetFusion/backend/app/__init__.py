"""StarPetFusion service backend."""
