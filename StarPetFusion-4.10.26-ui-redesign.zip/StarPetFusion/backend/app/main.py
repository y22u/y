from __future__ import annotations
import os, sys, tempfile, uuid, json, threading
from pathlib import Path
from typing import Any
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi import Request
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
app = FastAPI(title="StarPetFusion Service", version="4.10.26", description="Local-first desktop pet AI service gateway")
# Bind the service to loopback by default; do not expose this unauthenticated local API to LAN.
app.add_middleware(CORSMiddleware, allow_origins=["http://127.0.0.1:8765", "http://localhost:8765", "null"], allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["Content-Type", "Authorization"])

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    system_prompt: str = Field(default="你是 StarPetFusion 的中文桌宠助手。", max_length=12000)
    history: list[dict[str, str]] = Field(default_factory=list, max_length=30)
    provider: str = "external_agent"
    model: str = ""

class TTSRequest(BaseModel):
    text: str = Field(min_length=1, max_length=8000)
    provider: str = "system"
    voice: str = "Kore"
    language: str = "zh-CN"
    speed: float = Field(default=1.0, ge=0.5, le=2.0)



MODEL_HUB_FILE = ROOT / "data" / "model_hub_assignments.json"
MODEL_HUB_LOCK = threading.Lock()
MODEL_PULL_JOBS: dict[str, dict[str, Any]] = {}
MODEL_PULL_LOCK = threading.Lock()

class ModelHubPullRequest(BaseModel):
    base_url: str = "http://127.0.0.1:11434"
    name: str = Field(min_length=1, max_length=200)

class ModelHubDeleteRequest(BaseModel):
    base_url: str = "http://127.0.0.1:11434"
    name: str = Field(min_length=1, max_length=200)

class ModelHubAssignmentsRequest(BaseModel):
    assignments: dict[str, str] = Field(default_factory=dict)



class CharacterVoiceSampleRequest(BaseModel):
    character_ids: list[str] = Field(min_length=1, max_length=5)
    text: str = Field(min_length=1, max_length=300)
    provider: str = Field(default="indextts", pattern="^(indextts|qwen3)$")

class AutomationTaskRequest(BaseModel):
    task_type: str = Field(min_length=1, max_length=40)
    title: str = Field(default="", max_length=120)
    payload: dict[str, Any] = Field(default_factory=dict)

class AutomationRunnerRequest(BaseModel):
    periodic_audit: bool | None = None

class AutomationApprovalRequest(BaseModel):
    approved: bool

@app.get("/api/v1/character-voices")
def character_voice_list() -> dict[str, Any]:
    """List character voice profiles and authorization-backed reference status."""
    from character_voice_studio import PROFILES, character_ids, get_references
    try: profiles = json.loads(PROFILES.read_text(encoding="utf-8"))
    except (OSError, ValueError): profiles = {}
    refs = get_references()
    items = []
    for cid in character_ids():
        profile = profiles.get(cid, {}) if isinstance(profiles, dict) else {}
        items.append({"id": cid, "name": cid, "style": str(profile.get("delivery_prompt", profile.get("voice_hint", "")))[:240],
                      "rate": profile.get("rate", 1.0), "reference_ready": cid in refs,
                      "reference": {k: refs[cid].get(k) for k in ("duration_seconds", "sample_rate", "channels", "authorization_recorded_at", "quality_flags")} if cid in refs else None})
    try:
        import requests
        endpoint = os.environ.get("STAR_PET_INDEXTTS_ENDPOINT", "http://127.0.0.1:8767")
        health = requests.get(endpoint.rstrip("/") + "/health", timeout=1.0)
        indextts_ready = health.ok and health.json().get("provider") == "indextts"
    except Exception: indextts_ready = False
    try:
        import requests
        endpoint = os.environ.get("STAR_PET_QWEN3_TTS_ENDPOINT", "http://127.0.0.1:8766")
        health = requests.get(endpoint.rstrip("/") + "/health", timeout=1.0)
        qwen3_ready = health.ok and health.json().get("provider") == "qwen3"
    except Exception: qwen3_ready = False
    return {"characters": items, "providers": {"indextts": {"ready": bool(indextts_ready), "requires_reference": True},
            "qwen3": {"ready": bool(qwen3_ready), "requires_reference": False}},
            "authorization_note": "仅上传你拥有使用授权的参考音频；授权记录保存在本机。"}

@app.post("/api/v1/character-voices/{character_id}/reference")
async def character_voice_upload_reference(character_id: str, request: Request,
        authorization_confirmed: bool = False, authorization_basis: str = "") -> dict[str, Any]:
    """Upload a locally owned/authorized PCM WAV; raw request body avoids multipart dependency."""
    ctype = request.headers.get("content-type", "").lower()
    if ctype not in {"audio/wav", "audio/x-wav", "application/octet-stream"}:
        raise HTTPException(status_code=415, detail="请上传 WAV 音频，Content-Type 使用 audio/wav")
    raw = await request.body()
    if len(raw) > 20 * 1024 * 1024: raise HTTPException(status_code=413, detail="参考音频不能超过 20 MB")
    try:
        from character_voice_studio import save_reference
        record = save_reference(character_id, raw, authorization_confirmed=authorization_confirmed, authorization_basis=authorization_basis)
        return {"saved": True, "character_id": character_id, "reference": record}
    except ValueError as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.delete("/api/v1/character-voices/{character_id}/reference")
def character_voice_delete_reference(character_id: str) -> dict[str, Any]:
    from character_voice_studio import delete_reference
    try: return {"deleted": delete_reference(character_id), "character_id": character_id}
    except ValueError as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.post("/api/v1/character-voices/samples")
def character_voice_generate_samples(req: CharacterVoiceSampleRequest) -> dict[str, Any]:
    """Generate up to five audition samples and attach objective WAV quality metrics."""
    from character_voice_studio import PROFILES, SAMPLE_DIR, ROOT as VOICE_ROOT, get_references, inspect_wav, character_ids
    refs = get_references()
    known = set(character_ids())
    ids = list(dict.fromkeys(req.character_ids))
    if len(ids) > 5: raise HTTPException(status_code=400, detail="每次最多生成 5 个角色样本")
    if any(cid not in known for cid in ids): raise HTTPException(status_code=400, detail="包含未知角色 ID")
    if req.provider == "indextts" and any(cid not in refs for cid in ids):
        missing = [cid for cid in ids if cid not in refs]
        raise HTTPException(status_code=400, detail="以下角色缺少已授权参考音频：" + ", ".join(missing))
    endpoint = os.environ.get("STAR_PET_INDEXTTS_ENDPOINT" if req.provider == "indextts" else "STAR_PET_QWEN3_TTS_ENDPOINT",
                              "http://127.0.0.1:8767" if req.provider == "indextts" else "http://127.0.0.1:8766")
    try:
        import requests
        health = requests.get(endpoint.rstrip("/") + "/health", timeout=1.0)
        if not health.ok or health.json().get("provider") != req.provider:
            raise HTTPException(status_code=503, detail=f"{req.provider} 隔离语音服务未就绪")
    except HTTPException: raise
    except Exception as exc: raise HTTPException(status_code=503, detail=f"{req.provider} 隔离语音服务不可用") from exc
    try: profiles = json.loads(PROFILES.read_text(encoding="utf-8"))
    except (OSError, ValueError): profiles = {}
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    from tts_adapters import IsolatedTTSAdapter
    adapter = IsolatedTTSAdapter(endpoint, timeout=300)
    for cid in ids:
        profile = profiles.get(cid, {}) if isinstance(profiles, dict) else {}
        voice = str((VOICE_ROOT / refs[cid]["path"]).resolve() if req.provider == "indextts" else (profile.get("engine_voices", {}).get("qwen3") or "Vivian"))
        target_id = uuid.uuid4().hex
        target = SAMPLE_DIR / f"{target_id}.wav"
        try:
            generated = adapter.synthesize(req.text, target, voice=voice,
                language=str(profile.get("language", "zh-CN")), style=str(profile.get("delivery_prompt", profile.get("voice_hint", "")))[:200],
                speed=max(.5, min(float(profile.get("rate", 1.0)), 1.5)))
            raw = generated.read_bytes()
            metrics = inspect_wav(raw, min_seconds=0.1, max_seconds=600)
            results.append({"character_id": cid, "sample_id": target_id, "audio_url": f"/api/v1/character-voices/samples/{target_id}",
                            "provider": req.provider, "text": req.text, "quality": metrics, "status": "generated"})
        except Exception as exc:
            target.unlink(missing_ok=True)
            results.append({"character_id": cid, "status": "failed", "error": f"合成或 WAV 质检失败（{type(exc).__name__}）"})
    return {"provider": req.provider, "results": results, "generated": sum(1 for r in results if r["status"] == "generated"),
            "failed": sum(1 for r in results if r["status"] != "generated"),
            "quality_note": "自动检查 WAV 时长、采样率、声道、峰值和 RMS；不能代替人工试听与角色相似度评估。"}

@app.get("/api/v1/character-voices/samples/{sample_id}")
def character_voice_sample_file(sample_id: str) -> Any:
    from character_voice_studio import get_sample_path
    try: path = get_sample_path(sample_id)
    except ValueError as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileNotFoundError as exc: raise HTTPException(status_code=404, detail=str(exc)) from exc
    return FileResponse(path, media_type="audio/wav", filename=f"starpetfusion-sample-{sample_id}.wav")

@app.get("/api/v1/model-hub/models")
def model_hub_models(base_url: str = "http://127.0.0.1:11434") -> dict[str, Any]:
    try:
        from ollama_manager import OllamaManager
        manager = OllamaManager(base_url)
        models = manager.list_models()
        result = []
        for m in models:
            size = int(m.get("size") or 0)
            result.append({"name": str(m.get("name", "")), "size": size,
                "size_human": (f"{size / (1024**3):.2f} GB" if size >= 1024**3 else f"{size / (1024**2):.1f} MB"),
                "family": str((m.get("details") or {}).get("family", "Ollama")),
                "modified_at": str(m.get("modified_at", ""))})
        return {"connected": True, "models": result}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Ollama 不可用或地址无效（{type(exc).__name__}）") from exc

@app.get("/api/v1/model-hub/running")
def model_hub_running(base_url: str = "http://127.0.0.1:11434") -> dict[str, Any]:
    """Return Ollama's actual resident models and runtime version."""
    try:
        from ollama_manager import OllamaManager
        manager = OllamaManager(base_url)
        return {"connected": True, "version": manager.version(), "models": manager.list_running_models()}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"无法读取 Ollama 运行中模型（{type(exc).__name__}）") from exc

@app.get("/api/v1/model-hub/assignments")
def model_hub_get_assignments() -> dict[str, Any]:
    defaults = {"agent": os.environ.get("STAR_PET_OLLAMA_MODEL", "qwen2.5:7b"), "tts": "", "asr": "", "asr_provider": "sidecar", "asr_endpoint": "http://127.0.0.1:8768"}
    try:
        if MODEL_HUB_FILE.exists():
            saved = json.loads(MODEL_HUB_FILE.read_text(encoding="utf-8"))
            if isinstance(saved, dict): defaults.update({k: str(saved.get(k, defaults[k])) for k in defaults})
    except (OSError, ValueError, TypeError):
        pass
    return {"assignments": defaults}

@app.post("/api/v1/model-hub/assignments")
def model_hub_save_assignments(req: ModelHubAssignmentsRequest) -> dict[str, Any]:
    allowed = {"agent", "tts", "asr", "asr_provider", "asr_endpoint"}
    assignments = {k: str(req.assignments.get(k, "")).strip()[:300] for k in allowed}
    # Empty TTS/ASR means route to existing dedicated adapters, not pretend Ollama supports these tasks.
    MODEL_HUB_FILE.parent.mkdir(parents=True, exist_ok=True)
    with MODEL_HUB_LOCK:
        temp = MODEL_HUB_FILE.with_suffix(".tmp")
        temp.write_text(json.dumps(assignments, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(MODEL_HUB_FILE)
    return {"saved": True, "assignments": assignments}

@app.post("/api/v1/model-hub/pull")
def model_hub_pull(req: ModelHubPullRequest) -> dict[str, Any]:
    name = req.name.strip()
    if not name or any(c in name for c in "\r\n"):
        raise HTTPException(status_code=400, detail="模型名称无效")
    job_id = str(uuid.uuid4())
    with MODEL_PULL_LOCK:
        MODEL_PULL_JOBS[job_id] = {"id": job_id, "name": name, "status": "queued", "error": ""}
    def worker():
        try:
            from ollama_manager import OllamaManager
            with MODEL_PULL_LOCK: MODEL_PULL_JOBS[job_id]["status"] = "running"
            OllamaManager(req.base_url, timeout=30).pull_model(name)
            with MODEL_PULL_LOCK: MODEL_PULL_JOBS[job_id]["status"] = "completed"
        except Exception as exc:
            with MODEL_PULL_LOCK:
                MODEL_PULL_JOBS[job_id]["status"] = "failed"
                MODEL_PULL_JOBS[job_id]["error"] = type(exc).__name__
    threading.Thread(target=worker, name=f"ollama-pull-{job_id[:8]}", daemon=True).start()
    return {"job_id": job_id, "name": name, "status": "queued"}

@app.get("/api/v1/model-hub/jobs/{job_id}")
def model_hub_job(job_id: str) -> dict[str, Any]:
    with MODEL_PULL_LOCK:
        job = MODEL_PULL_JOBS.get(job_id)
        if not job: raise HTTPException(status_code=404, detail="部署任务不存在或服务重启后已清理")
        return dict(job)

@app.post("/api/v1/model-hub/delete")
def model_hub_delete(req: ModelHubDeleteRequest) -> dict[str, Any]:
    try:
        from ollama_manager import OllamaManager
        manager = OllamaManager(req.base_url)
        running = manager.list_running_models()
        if any(str(m.get("name")) == req.name for m in running):
            raise HTTPException(status_code=409, detail="该模型当前仍驻留在内存中。请先停止相关推理或等待 Ollama 卸载，再删除模型。")
        manager.delete_model(req.name)
        return {"deleted": True, "name": req.name}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"删除模型失败（{type(exc).__name__}）") from exc

@app.get("/api/v1/automation/status")
def automation_status() -> dict[str, Any]:
    from autonomous_tasks import runner_status
    return {"status": "ok", **runner_status()}

@app.post("/api/v1/automation/runner/start")
def automation_runner_start(req: AutomationRunnerRequest) -> dict[str, Any]:
    from autonomous_tasks import start_runner
    return {"status": "ok", **start_runner(req.periodic_audit)}

@app.post("/api/v1/automation/runner/stop")
def automation_runner_stop() -> dict[str, Any]:
    from autonomous_tasks import stop_runner
    return {"status": "ok", **stop_runner()}

@app.get("/api/v1/automation/tasks")
def automation_tasks(limit: int = 50) -> dict[str, Any]:
    from autonomous_tasks import list_tasks
    return {"tasks": list_tasks(limit)}

@app.get("/api/v1/automation/events")
def automation_events(limit: int = 100) -> dict[str, Any]:
    from autonomous_tasks import list_events
    return {"events": list_events(limit)}

@app.post("/api/v1/automation/tasks")
def automation_create_task(req: AutomationTaskRequest) -> dict[str, Any]:
    from autonomous_tasks import create_task
    try:
        task = create_task(req.task_type, req.payload, req.title)
        return {"task": task, "message": "任务已创建；代码变更需先审批，其余任务将在执行器运行时处理。"}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.post("/api/v1/automation/tasks/{task_id}/approval")
def automation_approve_task(task_id: str, req: AutomationApprovalRequest) -> dict[str, Any]:
    from autonomous_tasks import approve_task
    try:
        return {"task": approve_task(task_id, req.approved)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@app.get("/api/v1/health")
def health() -> dict[str, Any]:
    return {"status":"ok", "service":"starpetfusion", "version":"4.10.26", "mode":"local-loopback"}

@app.get("/api/v1/connectors")
def connectors() -> dict[str, Any]:
    """Return real readiness signals without exposing credentials or making paid calls."""
    import importlib.util
    import requests
    from integrations import integration_config
    cfg = integration_config()
    agent = cfg.get("external_agent", {}) if isinstance(cfg, dict) else {}
    agent_ready = bool(agent.get("enabled") and agent.get("endpoint") and agent.get("model"))
    ollama_endpoint = os.environ.get("STAR_PET_OLLAMA_ENDPOINT", "http://127.0.0.1:11434/v1").rstrip("/")
    ollama_model = os.environ.get("STAR_PET_OLLAMA_MODEL", "qwen2.5:7b")
    def probe(url: str) -> bool:
        try:
            return requests.get(url, timeout=(0.5, 1.0)).status_code < 500
        except requests.RequestException:
            return False
    qwen_endpoint = os.environ.get("STAR_PET_QWEN3_TTS_ENDPOINT", "http://127.0.0.1:8766").rstrip("/")
    index_endpoint = os.environ.get("STAR_PET_INDEXTTS_ENDPOINT", "http://127.0.0.1:8767").rstrip("/")
    edge_installed = importlib.util.find_spec("edge_tts") is not None
    tts_cfg = cfg.get("tts", {}) if isinstance(cfg, dict) else {}
    gemini_configured = bool(os.environ.get("GEMINI_API_KEY"))
    google_adc_configured = bool(os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")) or bool(os.environ.get("GOOGLE_CLOUD_PROJECT"))
    items = [
      {"id":"external_agent", "name":"外部 Agent（默认连接）", "provider":"external_agent", "configured":bool(agent.get("endpoint") and agent.get("model")), "enabled":bool(agent.get("enabled")), "ready":agent_ready, "endpoint":str(agent.get("endpoint", "")), "model":str(agent.get("model", "")), "auth":"密钥从环境变量读取；需启用并提供兼容接口"},
      {"id":"ollama", "name":"Ollama 本地模型", "configured":bool(ollama_model), "enabled":True, "ready":probe(ollama_endpoint.rsplit("/v1",1)[0] + "/api/tags"), "endpoint":ollama_endpoint, "model":ollama_model, "auth":"本地服务，无云端 API Key"},
      {"id":"edge_tts", "name":"Microsoft Edge TTS（在线免 API Key）", "configured":edge_installed, "enabled":True, "ready":edge_installed, "auth":"需要 edge-tts 依赖和互联网；免费在线服务，不是离线模型"},
      {"id":"qwen3_tts", "name":"Qwen3-TTS（本地开源模型）", "configured":True, "enabled":True, "ready":probe(qwen_endpoint + "/health"), "endpoint":qwen_endpoint, "auth":"需独立环境、模型权重；服务就绪才可推理"},
      {"id":"indextts", "name":"IndexTTS（本地开源模型）", "configured":True, "enabled":True, "ready":probe(index_endpoint + "/health"), "endpoint":index_endpoint, "auth":"需独立环境、模型权重和授权使用的参考 WAV"},
      {"id":"google_cloud_tts", "name":"Google Cloud TTS", "configured":google_adc_configured, "enabled":bool(tts_cfg.get("enabled") and tts_cfg.get("provider")=="google_cloud"), "ready":google_adc_configured, "auth":"Google ADC；可能产生费用，不能视作免费本地模型"},
      {"id":"gemini_tts", "name":"Gemini TTS API", "configured":gemini_configured, "enabled":bool(tts_cfg.get("enabled") and tts_cfg.get("provider")=="gemini_api"), "ready":gemini_configured, "auth":"GEMINI_API_KEY；免费层/额度依 Google 当前政策，超额可能收费"},
    ]
    profiles = cfg.get("agent_profiles", {}) if isinstance(cfg, dict) else {}
    if isinstance(profiles, dict):
        for profile_id, profile in profiles.items():
            if not isinstance(profile, dict) or not str(profile_id).replace("_", "").replace("-", "").isalnum():
                continue
            endpoint = str(profile.get("endpoint", "")).strip()
            model = str(profile.get("model", "")).strip()
            enabled = bool(profile.get("enabled", True))
            items.append({"id":"agent_profile:" + str(profile_id), "name":str(profile.get("label", profile_id))[:80],
                "provider":"agent_profile:" + str(profile_id), "configured":bool(endpoint and model),
                "enabled":enabled, "ready":bool(enabled and endpoint and model), "endpoint":endpoint,
                "model":model, "auth":"独立环境变量密钥；需 OpenAI 兼容 /chat/completions 接口"})
    return {"items":items}

@app.get("/api/v1/diagnostics")
def diagnostics() -> dict[str, Any]:
    """Runtime readiness and concurrency diagnostics; no paid test calls are made."""
    items = connectors()["items"]
    safe_items = [{"id":x["id"], "name":x["name"], "configured":x.get("configured",False), "ready":x.get("ready",False), "enabled":x.get("enabled",False)} for x in items]
    try:
        from asr_runtime import readiness as asr_readiness
        asr = asr_readiness()
    except Exception as exc:
        asr = {"provider":"faster-whisper", "configured":True, "ready":False, "note":type(exc).__name__}
    safe_items.append({"id":"local_asr", "name":"本地 ASR（faster-whisper）", "configured":asr.get("configured", False), "ready":asr.get("ready", False), "enabled":True, "note":asr.get("note", "")})
    try:
        from runtime_control import snapshot as concurrency_snapshot
        concurrency = concurrency_snapshot()
    except Exception:
        concurrency = {}
    try:
        from resource_monitor import resource_snapshot
        resources = resource_snapshot()
    except Exception as exc:
        resources = {"advice": {"level": "unknown", "recommended_chat_concurrency": 1,
            "reason": "资源检测失败，建议保守串行运行。", "applied_automatically": False},
            "error": type(exc).__name__}
    return {"status":"ok", "version":"4.10.26", "items":safe_items, "checks":safe_items, "asr":asr, "concurrency":concurrency, "resources":resources,
        "notes":["ASR 音频通过本地接口执行实际推理。", "Qwen3/IndexTTS 仍需独立服务与模型权重。", "资源感知只提供透明建议，不会擅自覆盖用户并发设置。", "诊断不会发起收费合成或向云服务发送测试文本。"]}

@app.post("/api/v1/chat")
def chat(req: ChatRequest) -> dict[str, Any]:
    messages = [{"role":"system", "content":req.system_prompt}]
    for item in req.history[-30:]:
        role = item.get("role", "")
        content = item.get("content", "")
        if role in {"user", "assistant"} and isinstance(content, str): messages.append({"role":role, "content":content[:12000]})
    messages.append({"role":"user", "content":req.message})
    try:
        from runtime_control import slot
        with slot("chat", timeout=2.0):
            return _chat_dispatch(req, messages)
    except TimeoutError as exc:
        raise HTTPException(status_code=429, detail="当前对话模型并发已满，请稍后重试") from exc
    except HTTPException: raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Agent 请求失败（{type(exc).__name__}）。请检查连接设置和服务日志。") from exc

def _chat_dispatch(req: ChatRequest, messages: list[dict[str, str]]) -> dict[str, Any]:
    try:
        if req.provider == "ollama":
            import requests
            url = os.environ.get("STAR_PET_OLLAMA_ENDPOINT", "http://127.0.0.1:11434/v1").rstrip("/") + "/chat/completions"
            model = (req.model or model_hub_get_assignments()["assignments"].get("agent") or os.environ.get("STAR_PET_OLLAMA_MODEL", "qwen2.5:7b"))
            r = requests.post(url, json={"model":model,"messages":messages,"stream":False}, timeout=90)
            r.raise_for_status(); data=r.json(); answer=data["choices"][0]["message"]["content"]
        elif req.provider == "external_agent":
            from external_agent import ExternalAgentClient
            answer = ExternalAgentClient().chat(messages)
        elif req.provider.startswith("agent_profile:"):
            from integrations import integration_config
            from external_agent import ExternalAgentClient
            profile_id = req.provider.split(":", 1)[1]
            profiles = integration_config().get("agent_profiles", {})
            profile = profiles.get(profile_id) if isinstance(profiles, dict) else None
            if not isinstance(profile, dict) or not profile.get("enabled", True):
                raise HTTPException(status_code=400, detail="该 Agent 配置不存在或未启用")
            answer = ExternalAgentClient({**profile, "enabled": True}).chat(messages)
        else:
            raise HTTPException(status_code=400, detail="不支持的 Agent 提供方")
        return {"reply":str(answer), "provider":req.provider, "request_id":str(uuid.uuid4())}
    except HTTPException: raise
    except Exception as exc:
        # Provider exception messages are intentionally not returned to the browser.
        raise HTTPException(status_code=502, detail=f"Agent 请求失败（{type(exc).__name__}）。请检查连接设置和服务日志。") from exc

@app.post("/api/v1/tts")
def tts(req: TTSRequest) -> Any:
    try:
        from runtime_control import slot
        with slot("tts", timeout=2.0):
            return _tts_dispatch(req)
    except TimeoutError as exc:
        raise HTTPException(status_code=429, detail="TTS 并发已满，请稍后重试") from exc

def _tts_dispatch(req: TTSRequest) -> Any:
    out = Path(tempfile.gettempdir()) / "starpetfusion-audio" / f"{uuid.uuid4().hex}.wav"
    try:
        if req.provider == "edge":
            from tts_adapters import EdgeTTSAdapter
            path = EdgeTTSAdapter().synthesize(req.text, out.with_suffix(".mp3"), voice=req.voice or "zh-CN-XiaoxiaoNeural", language=req.language, speed=req.speed)
            return FileResponse(path, media_type="audio/mpeg", filename="starpetfusion-tts.mp3")
        elif req.provider in {"qwen3", "indextts"}:
            from tts_adapters import IsolatedTTSAdapter
            env_name = "STAR_PET_QWEN3_TTS_ENDPOINT" if req.provider == "qwen3" else "STAR_PET_INDEXTTS_ENDPOINT"
            default_endpoint = "http://127.0.0.1:8766" if req.provider == "qwen3" else "http://127.0.0.1:8767"
            path = IsolatedTTSAdapter(os.environ.get(env_name, default_endpoint)).synthesize(req.text, out, voice=req.voice or ("Vivian" if req.provider == "qwen3" else ""), language=req.language, speed=req.speed)
            media = "audio/mpeg" if path.suffix.lower() == ".mp3" else "audio/wav"
            return FileResponse(path, media_type=media, filename="starpetfusion-tts" + path.suffix)
        elif req.provider == "gemini":
            from tts_adapters import GoogleGeminiTTSAdapter
            GoogleGeminiTTSAdapter().synthesize(req.text, out, voice=req.voice, language=req.language, speed=req.speed)
        elif req.provider == "google_cloud":
            from tts_adapters import GoogleCloudTTSAdapter
            GoogleCloudTTSAdapter().synthesize(req.text, out, voice=req.voice, language=req.language, speed=req.speed)
        elif req.provider == "external":
            from integrations import integration_config
            from tts_adapters import ExternalTTSAdapter
            cfg = integration_config().get("external_tts", {})
            if not cfg.get("endpoint"): raise ValueError("尚未配置外部 TTS endpoint")
            ExternalTTSAdapter(cfg["endpoint"], cfg.get("api_key_env", "STAR_PET_TTS_API_KEY"), cfg.get("mode", "openai_compatible"), cfg.get("model", ""), cfg.get("timeout",45)).synthesize(req.text,out,voice=req.voice,language=req.language,speed=req.speed)
        else:
            raise HTTPException(status_code=400, detail="系统 TTS 暂由桌面端语音模块处理；请选择已配置的云端提供方")
        return FileResponse(out, media_type="audio/wav", filename="starpetfusion-tts.wav", background=None)
    except HTTPException: raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"TTS 合成失败（{type(exc).__name__}）。请检查服务凭据、模型和配额。") from exc

@app.get("/api/v1/asr/status")
def asr_status() -> dict[str, Any]:
    from asr_runtime import readiness
    return {**readiness(), "concurrency": __import__("runtime_control").snapshot()["asr"]}

@app.post("/api/v1/asr/transcribe")
async def asr_transcribe(request: Request, model: str = "base", language: str = "auto") -> dict[str, Any]:
    """Transcribe raw audio bytes locally. Send WAV/MP3/WebM bytes as request body."""
    content_type = request.headers.get("content-type", "application/octet-stream").lower()
    if not any(x in content_type for x in ("audio/", "application/octet-stream")):
        raise HTTPException(status_code=415, detail="请发送音频文件内容，Content-Type 使用 audio/wav、audio/webm 或 application/octet-stream")
    raw = await request.body()
    if not raw: raise HTTPException(status_code=400, detail="音频内容为空")
    if len(raw) > 25 * 1024 * 1024: raise HTTPException(status_code=413, detail="音频文件不能超过 25 MB")
    suffix = ".webm" if "webm" in content_type else ".mp3" if "mpeg" in content_type or "mp3" in content_type else ".wav"
    target = Path(tempfile.gettempdir()) / "starpetfusion-asr" / f"{uuid.uuid4().hex}{suffix}"
    target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
    try:
        from runtime_control import slot
        from asr_runtime import transcribe_file
        with slot("asr", timeout=1.0):
            import concurrent.futures
            loop = __import__("asyncio").get_running_loop()
            result = await loop.run_in_executor(None, lambda: transcribe_file(target, model, language))
        if not result.get("text"): raise HTTPException(status_code=422, detail="未识别到语音，请检查音频清晰度")
        return result
    except TimeoutError as exc:
        raise HTTPException(status_code=429, detail="ASR 正在处理其他音频，请稍后重试") from exc
    except HTTPException: raise
    except ValueError as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc: raise HTTPException(status_code=503, detail=f"本地 ASR 推理失败（{type(exc).__name__}）。请检查依赖、模型下载与运行环境。") from exc
    finally:
        try: target.unlink(missing_ok=True)
        except OSError: pass

FRONTEND = ROOT / "frontend"
if FRONTEND.exists():
    app.mount("/assets", StaticFiles(directory=FRONTEND / "assets"), name="assets")
    @app.get("/")
    def home(): return FileResponse(FRONTEND / "index.html")
