"""Optional local push-to-talk ASR adapter.

Requires optional packages: sounddevice, numpy, faster-whisper. No audio is uploaded.
"""
from __future__ import annotations

import threading


_MODEL_CACHE: dict[tuple[str, str, str], object] = {}
_MODEL_LOCK = threading.Lock()

def record_and_transcribe(seconds: int = 5, model_size: str = "base", language: str = "zh") -> str:
    """Record a short microphone clip and transcribe locally with faster-whisper."""
    try:
        import numpy as np
        import sounddevice as sd
    except ImportError as exc:
        raise RuntimeError("语音输入依赖未安装。请运行：pip install sounddevice numpy faster-whisper") from exc
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError("缺少 faster-whisper。请运行：pip install faster-whisper") from exc
    seconds = max(2, min(15, int(seconds)))
    sample_rate = 16000
    try:
        audio = sd.rec(int(seconds * sample_rate), samplerate=sample_rate, channels=1, dtype="float32")
        sd.wait()
    except Exception as exc:
        raise RuntimeError(f"无法访问麦克风，请检查系统麦克风权限和输入设备：{exc}") from exc
    if audio.size == 0 or float(np.max(np.abs(audio))) < 0.003:
        raise RuntimeError("没有检测到清晰语音，请靠近麦克风后重试。")
    try:
        # Reuse the loaded model between recordings; first load can take longer.
        key = (str(model_size), "cpu", "int8")
        with _MODEL_LOCK:
            model = _MODEL_CACHE.get(key)
            if model is None:
                model = WhisperModel(model_size, device="cpu", compute_type="int8")
                _MODEL_CACHE[key] = model
        lang = None if str(language).lower() in {"auto", "detect", ""} else str(language)[:8]
        segments, _info = model.transcribe(audio.reshape(-1), language=lang, vad_filter=True, beam_size=3)
        text = "".join(segment.text for segment in segments).strip()
    except Exception as exc:
        raise RuntimeError(f"本地语音识别失败：{exc}") from exc
    if not text:
        raise RuntimeError("没有识别出文字，请重试或缩短背景噪声。")
    return text
