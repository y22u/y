"""Small local-first productivity panel: notes, todos and scoped read-only file search."""
from __future__ import annotations
import json
import os
from datetime import datetime
from pathlib import Path
from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QListWidget,
    QListWidgetItem, QLineEdit, QPlainTextEdit, QFileDialog, QMessageBox,
    QTabWidget, QWidget, QCheckBox
)
from config_store import app_data_dir
from productivity_data import export_backup, read_backup, merge_data, atomic_write_json

DATA_PATH = app_data_dir() / "productivity.json"


def _load_data() -> dict:
    try:
        data = json.loads(DATA_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            data.setdefault("todos", [])
            data.setdefault("notes", "")
            return data
    except (OSError, json.JSONDecodeError):
        pass
    return {"todos": [], "notes": ""}


def _save_data(data: dict) -> None:
    # Keep a small rolling safety copy before replacing the current workbench file.
    if DATA_PATH.is_file():
        backup = DATA_PATH.with_suffix(".previous.json")
        try:
            backup.write_text(DATA_PATH.read_text(encoding="utf-8"), encoding="utf-8")
        except OSError:
            pass
    atomic_write_json(DATA_PATH, data)


class ProductivityDialog(QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.data = _load_data()
        self.setWindowTitle("StarPetFusion · 日常工作台")
        self.resize(650, 560)
        root = QVBoxLayout(self)
        intro = QLabel("本地待办与便签保存在本机。文件搜索仅扫描你主动选择的目录，不会自动上传文件。")
        intro.setWordWrap(True)
        root.addWidget(intro)
        tabs = QTabWidget()
        root.addWidget(tabs)

        todo_tab = QWidget(); todo_layout = QVBoxLayout(todo_tab)
        self.todo_list = QListWidget(); todo_layout.addWidget(self.todo_list)
        add_row = QHBoxLayout(); self.todo_input = QLineEdit(); self.todo_input.setPlaceholderText("输入待办事项…")
        add_btn = QPushButton("添加"); add_btn.clicked.connect(self.add_todo)
        add_row.addWidget(self.todo_input); add_row.addWidget(add_btn); todo_layout.addLayout(add_row)
        todo_actions = QHBoxLayout()
        done_btn = QPushButton("标记完成/未完成"); done_btn.clicked.connect(self.toggle_todo)
        delete_btn = QPushButton("删除选中项"); delete_btn.clicked.connect(self.delete_todo)
        todo_actions.addWidget(done_btn); todo_actions.addWidget(delete_btn); todo_layout.addLayout(todo_actions)
        tabs.addTab(todo_tab, "待办清单")

        note_tab = QWidget(); note_layout = QVBoxLayout(note_tab)
        self.notes = QPlainTextEdit(); self.notes.setPlaceholderText("随手记录想法、会议要点或学习计划…")
        self.notes.setPlainText(str(self.data.get("notes", "")))
        save_note = QPushButton("保存便签"); save_note.clicked.connect(self.save_notes)
        note_layout.addWidget(self.notes); note_layout.addWidget(save_note)
        tabs.addTab(note_tab, "便签")

        files_tab = QWidget(); files_layout = QVBoxLayout(files_tab)
        folder_row = QHBoxLayout(); self.folder = QLineEdit(); self.folder.setPlaceholderText("选择要搜索的文件夹")
        browse = QPushButton("选择目录…"); browse.clicked.connect(self.choose_folder)
        folder_row.addWidget(self.folder); folder_row.addWidget(browse); files_layout.addLayout(folder_row)
        query_row = QHBoxLayout(); self.query = QLineEdit(); self.query.setPlaceholderText("文件名关键词，例如 report 或 .pdf")
        self.search_button = QPushButton("搜索"); self.search_button.clicked.connect(self.search_files)
        query_row.addWidget(self.query); query_row.addWidget(self.search_button); files_layout.addLayout(query_row)
        self.results = QListWidget(); self.results.itemDoubleClicked.connect(self.open_result)
        files_layout.addWidget(self.results)
        files_layout.addWidget(QLabel("双击结果可打开文件；此功能不执行脚本或程序。"))
        tabs.addTab(files_tab, "文件查找")

        backup_tab = QWidget(); backup_layout = QVBoxLayout(backup_tab)
        backup_layout.addWidget(QLabel("导出/导入仅包含本工作台的待办与便签，不包含 API Key、应用设置或聊天记录。导入时默认合并，不覆盖现有内容。"))
        export_btn = QPushButton("导出待办与便签备份…"); export_btn.clicked.connect(self.export_data)
        import_btn = QPushButton("导入并合并备份…"); import_btn.clicked.connect(self.import_data)
        backup_layout.addWidget(export_btn); backup_layout.addWidget(import_btn)
        backup_layout.addStretch(1)
        tabs.addTab(backup_tab, "数据备份")
        self.refresh_todos()

    def export_data(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出工作台备份", "StarPetFusion-workbench-backup.json", "JSON 备份 (*.json)")
        if not path: return
        try:
            export_backup(Path(path), self.data)
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "导出失败", str(exc)); return
        QMessageBox.information(self, "导出成功", "待办与便签已导出。此文件可能包含私人记录，请妥善保管。")

    def import_data(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入工作台备份", "", "JSON 备份 (*.json)")
        if not path: return
        try:
            incoming = read_backup(Path(path))
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "导入失败", str(exc)); return
        answer = QMessageBox.question(self, "合并备份", f"备份包含 {len(incoming['todos'])} 条待办和 {len(incoming['notes'])} 个便签字符。\n\n将合并待办，并把备份便签追加到现有便签后面，不会清空当前数据。是否继续？")
        if answer != QMessageBox.StandardButton.Yes: return
        self.data = merge_data(self.data, incoming)
        _save_data(self.data)
        self.notes.setPlainText(str(self.data.get("notes", "")))
        self.refresh_todos()
        QMessageBox.information(self, "导入完成", "已合并备份；导入前的本地数据也保留了安全副本。")

    def refresh_todos(self):
        self.todo_list.clear()
        for i, task in enumerate(self.data.get("todos", [])):
            done = bool(task.get("done"))
            item = QListWidgetItem(("✓ " if done else "○ ") + str(task.get("text", "")))
            item.setData(256, i)
            self.todo_list.addItem(item)

    def add_todo(self):
        text = self.todo_input.text().strip()
        if not text: return
        self.data.setdefault("todos", []).append({"text": text, "done": False, "created": datetime.now().isoformat(timespec="minutes")})
        _save_data(self.data); self.todo_input.clear(); self.refresh_todos()

    def toggle_todo(self):
        item = self.todo_list.currentItem()
        if not item: return
        i = item.data(256); self.data["todos"][i]["done"] = not self.data["todos"][i].get("done", False)
        _save_data(self.data); self.refresh_todos()

    def delete_todo(self):
        item = self.todo_list.currentItem()
        if not item: return
        self.data["todos"].pop(item.data(256)); _save_data(self.data); self.refresh_todos()

    def save_notes(self):
        self.data["notes"] = self.notes.toPlainText(); _save_data(self.data)
        QMessageBox.information(self, "已保存", "便签已保存在本机 StarPetFusion 配置目录。")

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "选择搜索目录", str(Path.home()))
        if folder: self.folder.setText(folder)

    def search_files(self):
        if not self.controller.has_permission("file_search", self): return
        base = Path(self.folder.text()).expanduser()
        term = self.query.text().strip().casefold()
        self.results.clear()
        if not base.is_dir():
            QMessageBox.information(self, "请选择目录", "请先选择一个有效的文件夹。")
            return
        count = 0
        scanned = 0
        try:
            for path in base.rglob("*"):
                scanned += 1
                if scanned > 20000: break
                if path.is_file() and (not term or term in path.name.casefold()):
                    item = QListWidgetItem(str(path)); item.setData(256, str(path)); self.results.addItem(item)
                    count += 1
                    if count >= 500: break
        except (OSError, PermissionError) as exc:
            QMessageBox.warning(self, "搜索受限", f"部分目录无法读取：{exc}")

    def open_result(self, item):
        if not self.controller.has_permission("open_files", self): return
        path = Path(item.data(256))
        if not path.is_file(): return
        blocked = {".exe", ".com", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".msi", ".scr", ".reg", ".lnk", ".sh", ".bash"}
        if path.suffix.casefold() in blocked:
            QMessageBox.warning(self, "不支持打开", "为避免误启动程序，工作台不会直接打开可执行文件或脚本。")
            return
        if QMessageBox.question(self, "打开文件", f"是否使用系统默认程序打开？\n{path}") != QMessageBox.StandardButton.Yes:
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
