"""Ollama HTTP management client for local LLM models.

Uses Ollama's native HTTP API (/api/tags, /api/show, /api/pull, /api/delete).
Only loopback HTTP is accepted by default so local model management cannot
silently send prompts or model operations to an arbitrary remote host.
"""
from __future__ import annotations

import json
from typing import Any, Callable
from urllib.parse import urlparse

import requests


def normalize_ollama_url(base_url: str = "http://127.0.0.1:11434") -> str:
    value = str(base_url or "http://127.0.0.1:11434").strip().rstrip("/")
    # Accept OpenAI-compatible URLs stored by older settings.
    for suffix in ("/v1/chat/completions", "/chat/completions", "/v1"):
        if value.endswith(suffix):
            value = value[:-len(suffix)].rstrip("/")
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "http" or host not in {"localhost", "127.0.0.1", "::1"}:
        raise ValueError("Ollama 管理接口仅允许本机 HTTP：例如 http://127.0.0.1:11434")
    return value


class OllamaManager:
    def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: int = 15):
        self.base_url = normalize_ollama_url(base_url)
        self.timeout = max(3, min(int(timeout), 60))

    def _request(self, method: str, path: str, **kwargs):
        response = requests.request(method, self.base_url + path, timeout=self.timeout, **kwargs)
        response.raise_for_status()
        return response

    def list_models(self) -> list[dict[str, Any]]:
        data = self._request("GET", "/api/tags").json()
        models = data.get("models", []) if isinstance(data, dict) else []
        return [m for m in models if isinstance(m, dict) and m.get("name")]

    def show_model(self, name: str) -> dict[str, Any]:
        name = str(name).strip()
        if not name or len(name) > 200:
            raise ValueError("模型名称无效")
        data = self._request("POST", "/api/show", json={"name": name}).json()
        return data if isinstance(data, dict) else {}

    def pull_model(self, name: str, progress: Callable[[dict[str, Any]], None] | None = None) -> None:
        name = str(name).strip()
        if not name or len(name) > 200 or any(c in name for c in "\r\n"):
            raise ValueError("请填写有效的 Ollama 模型名称，例如 qwen2.5:3b")
        # Stream Ollama's newline-delimited JSON progress events.
        with requests.post(self.base_url + "/api/pull", json={"name": name, "stream": True},
                           stream=True, timeout=(10, 1800)) as response:
            response.raise_for_status()
            for line in response.iter_lines(decode_unicode=True):
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except (ValueError, TypeError):
                    continue
                if progress:
                    progress(event)
                if event.get("error"):
                    raise RuntimeError(str(event["error"])[:400])

    def delete_model(self, name: str) -> None:
        name = str(name).strip()
        if not name or len(name) > 200:
            raise ValueError("模型名称无效")
        self._request("DELETE", "/api/delete", json={"name": name})

    def list_running_models(self) -> list[dict[str, Any]]:
        """Return models currently resident in Ollama memory (/api/ps)."""
        data = self._request("GET", "/api/ps").json()
        models = data.get("models", []) if isinstance(data, dict) else []
        result = []
        for model in models:
            if not isinstance(model, dict) or not model.get("name"):
                continue
            size = int(model.get("size") or 0)
            vram = int(model.get("size_vram") or 0)
            result.append({
                "name": str(model["name"]),
                "size": size,
                "size_vram": vram,
                "size_human": f"{size / (1024**3):.2f} GB" if size >= 1024**3 else f"{size / (1024**2):.1f} MB",
                "vram_human": f"{vram / (1024**3):.2f} GB" if vram >= 1024**3 else f"{vram / (1024**2):.1f} MB",
                "expires_at": str(model.get("expires_at") or ""),
                "context_length": int(model.get("context_length") or 0),
                "details": model.get("details") if isinstance(model.get("details"), dict) else {},
            })
        return result

    def version(self) -> str:
        data = self._request("GET", "/api/version").json()
        return str(data.get("version", "unknown")) if isinstance(data, dict) else "unknown"

    def health(self) -> bool:
        self._request("GET", "/api/tags")
        return True
